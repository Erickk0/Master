-- Selbstpruefende Testbench fuer edgeDetect(moore) (VHDL-93):
--   Referenzmodell: d1, d2 = Werte von data an den letzten beiden
--   steigenden Flanken (0 nach Reset). Der Moore-Automat ist genau dann im
--   Zustand edge, wenn d1 = '1' und d2 = '0'; tick = d1 and not d2 ist also
--   taktsynchron und immer genau einen Takt lang.
--   1. 300 zufaellige Wechsel von data zu beliebigen Zeitpunkten (nie genau
--      auf der steigenden Flanke).
--   2. Ein kurzer Puls von data zwischen zwei Flanken (Glitch) erzeugt
--      keinen tick.
--   3. Asynchroner Reset mitten im Takt.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_edgeDetect is
end tb_edgeDetect;

architecture Test of tb_edgeDetect is
  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal data  : std_logic := '0';
  signal tick  : std_logic;
  signal d1    : std_logic := '0'; -- Referenzmodell
  signal d2    : std_logic := '0';
  signal done  : boolean := false;
begin
  dut : entity work.edgeDetect(moore)
    port map (clk => clk, reset => reset, data => data, tick => tick);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  model : process(clk, reset)
  begin
    if reset = '1' then
      d1 <= '0';
      d2 <= '0';
    elsif rising_edge(clk) then
      d1 <= data;
      d2 <= d1;
    end if;
  end process;

  stimulus : process
    variable lfsr : std_logic_vector(15 downto 0) := x"ACE1";
    variable d    : integer;
  begin
    wait until falling_edge(clk);
    reset <= '0';

    -- 1. Zufaellige Wechsel
    for i in 1 to 300 loop
      d := 1 + to_integer(unsigned(lfsr(2 downto 0))); -- 1..8 ns nach der
      if d = 5 then                                    -- fallenden Flanke, nie
        d := 4;                                        -- genau auf der steigenden
      end if;
      wait for d * 1 ns;
      if lfsr(3) = '1' then
        data <= not data;
      end if;
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      wait for 500 ps;
      assert tick = (d1 and not d2)
        report "FEHLER nach Wechsel, Schritt " & integer'image(i) severity failure;
      wait until falling_edge(clk);
      assert tick = (d1 and not d2)
        report "FEHLER an fallender Flanke, Schritt " & integer'image(i) severity failure;
    end loop;
    report "ok: 300 zufaellige Wechsel, tick = d1 and not d2 (synchron)" severity note;

    -- 2. Glitch zwischen zwei Flanken
    data <= '0';
    for k in 1 to 3 loop
      wait until falling_edge(clk);
    end loop;
    wait for 1 ns;
    data <= '1';
    wait for 2 ns;
    data <= '0';
    for k in 1 to 2 loop
      wait until falling_edge(clk);
      assert tick = '0' report "FEHLER: Glitch erzeugt einen tick" severity failure;
    end loop;
    report "ok: Glitch zwischen zwei Flanken erzeugt keinen tick" severity note;

    -- 3. Reset mitten im Takt
    data <= '1';
    wait until falling_edge(clk);
    assert tick = '1' report "FEHLER: kein tick nach steigender Flanke von data"
      severity failure;
    wait for 2 ns;
    reset <= '1';
    wait for 1 ns;
    assert tick = '0' report "FEHLER: Reset im Betrieb" severity failure;
    report "ok: Reset mitten im Takt wirkt sofort" severity note;
    wait until falling_edge(clk);
    reset <= '0';

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
