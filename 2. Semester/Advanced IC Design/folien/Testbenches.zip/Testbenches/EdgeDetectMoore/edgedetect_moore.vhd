-- Flankenerkennung als Moore-Automat (teil7.typ, Folien "Die
-- Flankenerkennung mit einem Moore-Automat" bis "(III)"). Der Prozess
-- transition ist auf den Folien nur erwaehnt ("wie im Mealy-Fall").
library ieee;
use ieee.std_logic_1164.all;

entity edgeDetect is
  port (clk   : in  std_logic;
        reset : in  std_logic;
        data  : in  std_logic;
        tick  : out std_logic);
end edgeDetect;

architecture moore of edgeDetect is
  type state_t is (low, edge, high);
  signal state_reg  : state_t;
  signal state_next : state_t;
begin
  -- Prozess stateHandler wie im Mealy-Fall
  transition : process (clk, reset)
  begin
    if (reset = '1') then
      state_reg <= low;
    elsif (rising_edge(clk)) then
      state_reg <= state_next;
    end if;
  end process;

  next_state_proc : process(state_reg, data)
  begin

    -- Set default values
    state_next <= state_reg;
    tick <= '0';

    case state_reg is

      when low =>
        if (data = '1') then
          state_next <= edge;
        end if;

     when edge =>
        tick <= '1';
        if (data = '1') then
          state_next <= high;
        else
         state_next <= low;
        end if;

      when high =>
        if (data = '0') then
          state_next <= low;
        end if;
    end case;
  end process;
end architecture;
