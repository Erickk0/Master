// Selbstpruefende Testbench fuer edgedetect_moore:
//   Referenzmodell: d1, d2 = Werte von data an den letzten beiden
//   steigenden Flanken (0 nach Reset). Der Moore-Automat ist genau dann im
//   Zustand EDGE, wenn d1 = 1 und d2 = 0; tick = d1 & ~d2 ist also
//   taktsynchron und immer genau einen Takt lang.
//   1. 300 zufaellige Wechsel von data zu beliebigen Zeitpunkten (nie genau
//      auf der steigenden Flanke); tick wird nach jedem Wechsel und an der
//      fallenden Flanke geprueft. Jede Flanke von data, die an zwei
//      Taktflanken gesehen wird, erzeugt genau einen tick.
//   2. Ein kurzer Puls von data zwischen zwei Flanken (Glitch) erzeugt
//      keinen tick.
//   3. Asynchroner Reset mitten im Takt.

module tb_edgedetect_moore;

  reg     clk   = 1'b0;
  reg     reset = 1'b1;
  reg     data  = 1'b0;
  wire    tick;
  reg     d1 = 1'b0, d2 = 1'b0;   // Referenzmodell
  reg     [15 : 0] lfsr = 16'hACE1;
  integer i, d, errors = 0;

  edgedetect_moore dut (.clk(clk), .reset(reset), .data(data), .tick(tick));

  always #5 clk = ~clk;

  always @(posedge clk or posedge reset)
    if (reset) begin d1 <= 1'b0; d2 <= 1'b0; end
    else       begin d1 <= data; d2 <= d1;   end

  task check(input [8*24 : 1] what);
    if (tick !== (d1 & ~d2)) begin
      $display("FEHLER (%0s): t=%0t  d1=%b d2=%b tick=%b", what, $time, d1, d2, tick);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_edgedetect_moore.vcd"); // laeuft im Verzeichnis build/
    $dumpvars(0, tb_edgedetect_moore);

    @(negedge clk);
    reset = 1'b0;

    // 1. Zufaellige Wechsel
    for (i = 0; i < 300; i = i + 1) begin
      d = 1 + lfsr[2 : 0];                // 1..8 ns nach der fallenden Flanke,
      if (d == 5) d = 4;                  // nie genau auf der steigenden Flanke
      #(d);
      if (lfsr[3]) data = ~data;
      lfsr = {lfsr[14 : 0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      #0.5 check("nach Wechsel");
      @(negedge clk);
      check("fallende Flanke");
    end
    $display("ok     300 zufaellige Wechsel, tick = d1 & ~d2 (synchron)");

    // 2. Glitch zwischen zwei Flanken
    data = 1'b0;
    repeat (3) @(negedge clk);            // d1 = d2 = 0
    #1 data = 1'b1;
    #2 data = 1'b0;                       // vor der steigenden Flanke wieder 0
    repeat (2) begin
      @(negedge clk);
      if (tick !== 1'b0) begin
        $display("FEHLER: Glitch erzeugt einen tick");
        errors = errors + 1;
      end
    end
    $display("ok     Glitch zwischen zwei Flanken erzeugt keinen tick");

    // 3. Reset mitten im Takt
    data = 1'b1;
    @(negedge clk);                       // Zustand EDGE, tick = 1
    if (tick !== 1'b1) begin
      $display("FEHLER: kein tick nach steigender Flanke von data");
      errors = errors + 1;
    end
    #2 reset = 1'b1;                      // Zustand sofort LOW
    #1 check("Reset");
    $display("ok     Reset mitten im Takt wirkt sofort");
    @(negedge clk);
    reset = 1'b0;

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
