// Flankenerkennung als Moore-Automat, Verilog-Fassung (teil7.typ, Folien
// "Die Flankenerkennung mit einem Moore-Automat" bis "(III)"). Verilog
// kennt keine Architekturen, daher ein eigenes Modul mit derselben
// Schnittstelle wie edgedetect_mealy.
module edgedetect_moore
  (input  wire clk,
   input  wire reset,
   input  wire data,
   output reg  tick);

  localparam [1:0] LOW = 2'd0, EDGE = 2'd1, HIGH = 2'd2;

  reg [1:0] state, stateN;

  // Register-Block wie im Mealy-Fall
  always @(posedge clk or posedge reset) begin
    if (reset)
      state <= LOW;
    else
      state <= stateN;
  end

  always @(*) begin
    // Set default values
    stateN = state;
    tick   = 1'b0;

    case (state)

      LOW:
        if (data)
          stateN = EDGE;

      EDGE: begin
        tick = 1'b1;
        if (data)
          stateN = HIGH;
        else
          stateN = LOW;
      end

      HIGH:
        if (!data)
          stateN = LOW;

      default:            // 2'd3 kommt nicht vor
        stateN = LOW;

    endcase
  end

endmodule
