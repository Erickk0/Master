// Selbstprüfende Testbench für prienc (beide Varianten): alle 16 Eingaben
// gegen eine unabhängig formulierte Referenz (Index der höchsten Eins).

module tb_prienc;

  reg  [4 : 1] req;
  wire [2 : 0] idx;
  integer      i;
  integer      errors = 0;

  prienc dut (.req(req), .idx(idx));

  function [2 : 0] expected(input [4 : 1] r);
    integer k;
    begin
      expected = 3'd0;
      for (k = 1; k <= 4; k = k + 1)
        if (r[k]) expected = k;           // spätere (höhere) Eins gewinnt
    end
  endfunction

  initial begin
    $dumpfile("tb_prienc.vcd");          // läuft im Verzeichnis build/
    $dumpvars(0, tb_prienc);

    for (i = 0; i < 16; i = i + 1) begin
      req = i;
      #10;
      if (idx !== expected(req)) begin
        $display("FEHLER: req=%b  idx=%b  erwartet=%b", req, idx, expected(req));
        errors = errors + 1;
      end else
        $display("ok     req=%b  idx=%b", req, idx);
    end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
