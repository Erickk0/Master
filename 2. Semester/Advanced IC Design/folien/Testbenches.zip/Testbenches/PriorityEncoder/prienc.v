// Prioritätsencoder mit assign (teil5.typ, Folie "Prioritätsendcoder")
module prienc (input  wire [4 : 1] req,
               output wire [2 : 0] idx);

   assign idx = (req[4] == 1'b1) ? 3'b100 :
                (req[3] == 1'b1) ? 3'b011 :
                (req[2] == 1'b1) ? 3'b010 :
                (req[1] == 1'b1) ? 3'b001 :
                3'b000;

endmodule
