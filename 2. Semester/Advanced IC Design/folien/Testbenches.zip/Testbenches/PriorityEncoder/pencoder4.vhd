-- Prioritaetsencoder aus Teil 5 (VHDL), teil5.typ, Folie "Prioritaetsencoder".
-- Die library/use-Zeilen fehlen auf der Folie und sind hier ergaenzt.
library ieee;
use ieee.std_logic_1164.all;

entity pEncoder4 is
port (req : in std_logic_vector(4 downto 1);
      idx : out std_logic_vector(2 downto 0));
end pEncoder4;

architecture Behavioral of pEncoder4 is
begin
  idx <= "100" when (req(4)='1') else
         "011" when (req(3)='1') else
         "010" when (req(2)='1') else
         "001" when (req(1)='1') else
         "000";
end architecture;
