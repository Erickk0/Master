-- Selbstpruefende Testbench fuer pEncoder4 (VHDL-93): alle 16 Eingaben gegen
-- eine Referenz (Index der hoechsten Eins). Ein Fehler beendet die Simulation
-- mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_pEncoder4 is
end tb_pEncoder4;

architecture Test of tb_pEncoder4 is
  signal req : std_logic_vector(4 downto 1);
  signal idx : std_logic_vector(2 downto 0);

  function expected(r : std_logic_vector(4 downto 1)) return natural is
  begin
    for k in 4 downto 1 loop
      if r(k) = '1' then
        return k;
      end if;
    end loop;
    return 0;
  end function;
begin
  dut : entity work.pEncoder4 port map (req => req, idx => idx);

  stimulus : process
  begin
    for i in 0 to 15 loop
      req <= std_logic_vector(to_unsigned(i, 4));
      wait for 10 ns;
      assert to_integer(unsigned(idx)) = expected(req)
        report "FEHLER bei req = " & integer'image(i)
        severity failure;
    end loop;
    report "PASS" severity note;
    wait;
  end process;
end architecture;
