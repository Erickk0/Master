// Prioritätsencoder mit casez (teil5.typ, Folie "Prioritätsendcoder (Alternative)")
module prienc (input  [4 : 1] req,
               output reg [2 : 0] idx);

  always @(*) begin
    casez (req) // casez erlaubt don't-care
       4'b1???: idx = 3'b100; // Auch: idx = 4;
       4'b01??: idx = 3'b011;
       4'b001?: idx = 3'b010;
       4'b0001: idx = 3'b001;
       default: idx = 3'b000;
    endcase
  end

endmodule
