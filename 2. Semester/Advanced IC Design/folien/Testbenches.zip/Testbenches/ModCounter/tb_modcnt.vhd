-- Selbstpruefende Testbench fuer modCnt (VHDL-93) mit den Parametern von der
-- Folie (W = 10, M = 800, hsMin = 656, hsMax = 751, VGA-HSYNC):
--   1. Nach dem Reset: q = 0, sync = 0.
--   2. 2 * M + 5 Takte zaehlen. In jedem Takt muss q dem Referenzmodell
--      entsprechen (0, 1, ..., M - 1, 0, ...) und sync genau dann 1 sein,
--      wenn hsMin <= q <= hsMax.
--   3. In dieser Zeit kommen genau zwei sync-Pulse mit je
--      hsMax - hsMin + 1 = 96 Takten.
-- Geprueft wird immer an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_modCnt is
end tb_modCnt;

architecture Test of tb_modCnt is
  constant W     : integer := 10;
  constant M     : integer := 800;
  constant HSMIN : integer := 656;
  constant HSMAX : integer := 751;

  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal sync  : std_logic;
  signal q     : std_logic_vector(W - 1 downto 0);
  signal done  : boolean := false;
begin
  dut : entity work.modCnt
    generic map (W => W, M => M, hsMin => HSMIN, hsMax => HSMAX)
    port map (clk => clk, reset => reset, sync => sync, q => q);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable expected   : natural;
    variable expSync    : std_logic;
    variable syncOld    : std_logic;
    variable pulses     : natural := 0;
    variable syncCycles : natural := 0;
  begin
    -- 1. Reset ueber zwei steigende Flanken halten (dazu auf zwei fallende
    --    Flanken warten)
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    assert unsigned(q) = 0 and sync = '0'
      report "FEHLER: nach Reset" severity failure;
    reset    <= '0';
    expected := 0;
    syncOld  := sync;

    -- 2. Zaehlen, q und sync in jedem Takt pruefen
    for i in 1 to 2 * M + 5 loop
      wait until falling_edge(clk);
      if expected = M - 1 then expected := 0; else expected := expected + 1; end if;
      if expected >= HSMIN and expected <= HSMAX then
        expSync := '1';
      else
        expSync := '0';
      end if;
      assert to_integer(unsigned(q)) = expected and sync = expSync
        report "FEHLER bei Takt " & integer'image(i) & ": q = "
               & integer'image(to_integer(unsigned(q))) & ", erwartet "
               & integer'image(expected)
        severity failure;
      if sync = '1' then syncCycles := syncCycles + 1; end if;
      if sync = '1' and syncOld = '0' then
        pulses := pulses + 1;
        report "ok: sync-Puls beginnt bei Takt " & integer'image(i) severity note;
      end if;
      syncOld := sync;
    end loop;

    -- 3. Anzahl und Laenge der sync-Pulse
    assert pulses = 2 and syncCycles = 2 * (HSMAX - HSMIN + 1)
      report "FEHLER: " & integer'image(pulses) & " sync-Pulse mit zusammen "
             & integer'image(syncCycles) & " Takten"
      severity failure;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
