// Selbstprüfende Testbench für modcnt mit den Parametern von der Folie
// (WIDTH = 10, MODULO = 800, hsMin = 656, hsMax = 751, VGA-HSYNC):
//   1. Nach dem Reset: value = 0, sync = 0.
//   2. 2 * MODULO + 5 Takte zählen. In jedem Takt muss value dem
//      Referenzmodell entsprechen (0, 1, ..., MODULO - 1, 0, ...) und sync
//      genau dann 1 sein, wenn hsMin <= value <= hsMax.
//   3. In dieser Zeit kommen genau zwei sync-Pulse mit je
//      hsMax - hsMin + 1 = 96 Takten.
// Geprüft wird immer an der fallenden Flanke, damit es keine Races gibt.
// Ausgegeben werden nur die ersten 10 Fehler.

module tb_modcnt;

  localparam WIDTH  = 10,
             MODULO = 800,
             HSMIN  = 656,
             HSMAX  = 751;

  reg                clk   = 1'b0;
  reg                reset = 1'b1;
  wire [WIDTH-1 : 0] value;
  wire               sync;
  reg  [WIDTH-1 : 0] expected;
  reg                syncOld;
  integer            cycle;
  integer            pulses = 0;
  integer            syncCycles = 0;
  integer            errors = 0;

  modcnt #(.WIDTH(WIDTH), .MODULO(MODULO), .hsMin(HSMIN), .hsMax(HSMAX))
    dut (.value(value), .clk(clk), .reset(reset), .sync(sync));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  // Vergleicht value und sync mit dem Referenzmodell.
  task check;
    reg expSync;
    begin
      expSync = (expected >= HSMIN) && (expected <= HSMAX);
      if (value !== expected || sync !== expSync) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  value=%0d  sync=%b  erwartet value=%0d  sync=%b",
                   $time, value, sync, expected, expSync);
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_modcnt.vcd");           // läuft im Verzeichnis build/
    $dumpvars(0, tb_modcnt);

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten)
    @(negedge clk); @(negedge clk);
    expected = 0;
    check;
    reset   = 1'b0;
    syncOld = sync;

    // 2. Zählen, value und sync in jedem Takt prüfen
    for (cycle = 1; cycle <= 2 * MODULO + 5; cycle = cycle + 1) begin
      @(negedge clk);
      expected = (expected == MODULO - 1) ? 0 : expected + 1;
      check;
      if (sync === 1'b1) syncCycles = syncCycles + 1;
      if (sync === 1'b1 && syncOld === 1'b0) begin
        pulses = pulses + 1;
        $display("ok     sync-Puls beginnt bei Takt %0d (value=%0d)", cycle, value);
      end
      syncOld = sync;
    end

    // 3. Anzahl und Länge der sync-Pulse
    if (pulses != 2 || syncCycles != 2 * (HSMAX - HSMIN + 1)) begin
      $display("FEHLER: %0d sync-Pulse mit zusammen %0d Takten, erwartet 2 mit %0d",
               pulses, syncCycles, 2 * (HSMAX - HSMIN + 1));
      errors = errors + 1;
    end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
