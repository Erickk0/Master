-- Modulo-Zaehler aus Teil 5 (VHDL), teil5.typ, Folien "Ein Modulo-Counter"
-- (Entity) und "Ein Modulo-Counter (II)" (Architecture).
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity modCnt is

  generic(W : integer := 10; -- Width
          M : integer := 800; -- Modulo
          hsMin : integer := 656;
          hsMax : integer := 751);

  port(clk   : in std_logic;
       reset : in std_logic;
       sync  : out std_logic;
       q     : out std_logic_vector(W - 1 downto 0));

end modCnt;

architecture Behavioural of modCnt is
  signal cnt_r : unsigned(W - 1 downto 0);
  signal cnt_n : unsigned(W - 1 downto 0);
begin
  process (clk, reset)
  begin
    if (reset = '1') then
      cnt_r <= (others => '0');
    elsif (rising_edge(clk)) then
      cnt_r <= cnt_n; -- Change state on rising edge
    end if;
  end process;

  -- Next state logic
  cnt_n <= (others => '0') when (cnt_r = M - 1) else cnt_r + 1;

  -- Output logic
  q <= std_logic_vector(cnt_r);
  sync <= '1' when ((cnt_r >= hsMin) and (cnt_r <= hsMax)) else '0';

end architecture;
