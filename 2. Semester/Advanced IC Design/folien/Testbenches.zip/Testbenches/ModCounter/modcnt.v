// Modulo-Zähler (teil5.typ, Folie "Ein Modulo-Zähler")
module modcnt
  #(parameter WIDTH  = 10,
              MODULO = 800,
              hsMin  = 656,
              hsMax  = 751)
   (input  wire clk, reset,
    output wire [WIDTH - 1 : 0] value,
    output wire sync);

  wire [WIDTH - 1 : 0] valN;
  reg  [WIDTH - 1 : 0] val;

  always @(posedge clk) begin

    if (reset) begin // Synchron reset
      val <= {WIDTH{1'b0}};
    end else begin
      val <= valN;
    end

  end

  // Nextstate logic
  assign valN = (val == MODULO - 1) ? 0 : val + 1;

  // Output logic
  assign value = val;
  assign sync = ((val >= hsMin) && (val <= hsMax)) ? 1 : 0;

endmodule
