// Kontrollpfad des Fibonacci-Prozessors (teil8.typ, Folie "Schnittstellen
// des Kontrollpfads")
module controlpath
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    input  wire [DWIDTH - 1 : 0] n,
    output wire [DWIDTH - 1 : 0] value,
    output wire                  adr,
    output wire                  loadReg,
    output wire                  writeEnable,
    input  wire                  start,
    output wire                  ready);

  wire loadIC;   // Load the iteration counter
  wire decIC;    // Decrement the iteration counter
  wire isZero;   // The iteration counter is zero

  ic  #(.DWIDTH(DWIDTH)) ic_i  (.reset(reset), .clk(clk), .loadIC(loadIC),
                                .iCnt(n), .decIC(decIC), .isZero(isZero));
  fsm #(.DWIDTH(DWIDTH)) fsm_i (.reset(reset), .clk(clk), .loadIC(loadIC),
                                .decIC(decIC), .value(value), .adr(adr),
                                .loadReg(loadReg), .writeEnable(writeEnable),
                                .start(start), .isZero(isZero), .ready(ready));

endmodule
