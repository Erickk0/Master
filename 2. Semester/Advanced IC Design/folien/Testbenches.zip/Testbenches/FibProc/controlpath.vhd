----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    ControlPath - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: ControlPath.vhd 181 2014-04-18 08:46:17Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity ControlPath is

  port (reset       : in  std_logic;
        clk         : in  std_logic;
        n           : in  word_t;
        value       : out word_t;
        adr         : out std_logic;
        loadReg     : out std_logic;
        writeEnable : out std_logic;
        start       : in  std_logic;
        ready       : out std_logic);

end ControlPath;

architecture Structural of ControlPath is

  signal loadIC : std_logic;            -- Load the instruction counter
  signal decIC  : std_logic;            -- Decrement the instruction counter
  signal isZero : std_logic;  -- Indicates that the instruction counter is zero

begin

  ic : entity work.IC(Behavioral)
    port map (reset  => reset,
              clk    => clk,
              loadIC => loadIC,
              iCnt   => n,
              decIC  => decIC,
              isZero => isZero);

  fsm : entity work.FSM(Behavioral)
    port map (reset       => reset,
              clk         => clk,
              loadIC      => loadIC,
              decIC       => decIC,
              value       => value,
              adr         => adr,
              loadReg     => loadReg,
              writeEnable => writeEnable,
              start       => start,
              isZero      => isZero,
              ready       => ready);

end architecture;
