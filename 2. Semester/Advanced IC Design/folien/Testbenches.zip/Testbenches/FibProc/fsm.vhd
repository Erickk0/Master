----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    FSM - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: FSM.vhd 184 2014-04-18 09:47:22Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity FSM is

  port (reset       : in  std_logic;
        clk         : in  std_logic;
        loadIC      : out std_logic;
        decIC       : out std_logic;
        value       : out word_t;
        adr         : out std_logic;
        loadReg     : out std_logic;
        writeEnable : out std_logic;
        start       : in  std_logic;
        isZero      : in  std_logic;
        ready       : out std_logic);

end FSM;

architecture Behavioral of FSM is

  -- All possible states of the FSM
  type state_t is (idle,
                   load1, load2, load3,
                   calc1, calc2,
                   output1, output2,
                   crash);

  -- FSM states signals
  signal state_reg  : state_t;
  signal state_next : state_t;

begin

  state_handler : process (reset, clk)
  begin

    -- Asynchronous reset
    if (reset = '1') then

      -- Set FSM to inital state
      state_reg <= idle;

    elsif (rising_edge(clk)) then

      -- Goto next state
      state_reg <= state_next;

    end if;

  end process;

  transition : process(state_reg, start, isZero)
  begin

    -- Set defaults for registers
    state_next <= state_reg;

    -- Set the default values
    loadIC      <= '0';
    value       <= (others => '0');
    adr         <= '0';
    loadReg     <= '0';
    decIC       <= '0';
    ready       <= '0';
    writeEnable <= '1';

    -- Handle all possible states
    case (state_reg) is

      when idle =>

        -- Do not write to the register file
        writeEnable <= '0';
        
        -- Check for start signal
        if (start = '1') then

          -- Next load the number of iterations
          state_next <= load1;

        else

          -- Wait for the start signal
          state_next <= idle;

        end if;

      when load1 =>

        -- Do not write to the register file
        writeEnable <= '0';

        -- Load the instruction counter
        loadIC <= '1';

        -- Next load the registers
        state_next <= load2;

      when load2 =>

        -- Load the first register with one
        loadReg <= '1';
        adr     <= '0';
        value   <= OneWord;

        -- Next load second register
        state_next <= load3;

      when load3 =>

        -- Load the second register with one
        loadReg <= '1';
        adr     <= '1';
        value   <= OneWord;

        -- Decrement instruction register (done in calc1)
        decIC <= '1';

        -- Next calculate first sum
        state_next <= calc1;

      when calc1 =>

        -- Write result to first register
        adr <= '0';

        -- Check if calculation is done
        if (isZero = '1') then

          -- Do not update the register file
          writeEnable <= '0';

          -- Output the result
          state_next <= output1;

        else

          -- Decrement instruction register (done in calc2)
          decIC <= '1';

          -- Next calculate sum
          state_next <= calc2;

        end if;

      when calc2 =>

        -- Write result to second register
        adr <= '1';

        -- Check if calculation is done
        if (isZero = '1') then

          -- Do not update the register file
          writeEnable <= '0';

          -- Output the result
          state_next <= output2;

        else

          -- Decrement instruction register (done in calc1)
          decIC <= '1';

          -- Next calculate sum
          state_next <= calc1;

        end if;

      when output1 =>

        -- Hold the address for the output multiplexer
        adr <= '0';
        
        -- Indicate that output is ready
        ready <= '1';

        -- Do not update the register file anymore
        writeEnable <= '0';

        -- Wait for next input
        state_next <= idle;

      when output2 =>

        -- Hold the address for the output multiplexer
        adr <= '1';
        
        -- Indicate that output is ready
        ready <= '1';

        -- Do not update the register file anymore
        writeEnable <= '0';

        -- Wait for next input
        state_next <= idle;

      when crash =>

        -- Stay a while stay forever
        state_next <= crash;

      when others =>

        -- Should not happen
        state_next <= crash;

    end case;

  end process;

end architecture;
