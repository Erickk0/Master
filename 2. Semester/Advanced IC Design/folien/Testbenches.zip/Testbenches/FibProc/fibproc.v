// Fibonacci-Prozessor: Kontrollpfad und Datenpfad (teil8.typ)
module fibproc
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    input  wire [DWIDTH - 1 : 0] n,
    input  wire                  start,
    output wire [DWIDTH - 1 : 0] result,
    output wire                  ready);

  wire [DWIDTH - 1 : 0] value;   // Used for loading values to the register file
  wire adr;                      // Select the register to be written
  wire loadReg;                  // Load the register by the control path
  wire writeEnable;              // Write to the register file

  controlpath #(.DWIDTH(DWIDTH)) cp (.reset(reset), .clk(clk), .n(n),
                                     .value(value), .adr(adr), .loadReg(loadReg),
                                     .writeEnable(writeEnable), .start(start),
                                     .ready(ready));
  datapath    #(.DWIDTH(DWIDTH)) dp (.reset(reset), .clk(clk), .value(value),
                                     .loadReg(loadReg), .adr(adr),
                                     .writeEnable(writeEnable), .out(result));

endmodule
