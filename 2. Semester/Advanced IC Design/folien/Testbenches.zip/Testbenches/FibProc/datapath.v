// Datenpfad des Fibonacci-Prozessors (teil8.typ, Folie "Schnittstellen des
// Datenpfads")
module datapath
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    input  wire [DWIDTH - 1 : 0] value,
    input  wire                  loadReg,
    input  wire                  adr,
    input  wire                  writeEnable,
    output wire [DWIDTH - 1 : 0] out);

  wire [DWIDTH - 1 : 0] dataI;   // Input port of register file
  wire [DWIDTH - 1 : 0] dataA;   // First output port of register file
  wire [DWIDTH - 1 : 0] dataB;   // Second output port of register file
  wire [DWIDTH - 1 : 0] result;  // Result of operation (addition)

  au      #(.DWIDTH(DWIDTH)) au_i     (.portA(dataA), .portB(dataB), .result(result));
  mux2to1 #(.DWIDTH(DWIDTH)) outmux   (.a0(dataA), .a1(dataB), .sel(adr), .b(out));
  mux2to1 #(.DWIDTH(DWIDTH)) regmux   (.a0(result), .a1(value), .sel(loadReg), .b(dataI));
  regfile #(.DWIDTH(DWIDTH)) regfile_i (.reset(reset), .clk(clk), .adr(adr),
                                        .writeEnable(writeEnable), .dataI(dataI),
                                        .dataA(dataA), .dataB(dataB));

endmodule
