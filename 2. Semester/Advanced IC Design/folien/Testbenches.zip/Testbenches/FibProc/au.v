// Arithmetische Einheit des Fibonacci-Prozessors (teil8.typ, Folie "Die
// arithmetische Einheit"): addiert einfach die beiden Eingaenge.
module au
  #(parameter DWIDTH = 32)
   (input  wire [DWIDTH - 1 : 0] portA,
    input  wire [DWIDTH - 1 : 0] portB,
    output wire [DWIDTH - 1 : 0] result);

  assign result = portA + portB;

endmodule
