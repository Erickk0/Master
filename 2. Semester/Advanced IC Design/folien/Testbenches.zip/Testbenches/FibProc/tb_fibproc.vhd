-- Selbstpruefende Testbench fuer FibProc (VHDL-93, 32 Bit):
--   1. Fuer n = 1 .. 47 wird F(n) berechnet (F(1) = F(2) = 1, F(47) ist die
--      groesste Fibonacci-Zahl, die in 32 Bit passt) und mit einem
--      Referenzmodell verglichen. ready kommt nach genau n + 4 Takten und
--      ist genau einen Takt lang.
--   2. Ein asynchroner Reset mitten in der Rechnung bricht sie ab; die
--      naechste Rechnung ist wieder korrekt.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library FibLib;
use FibLib.FTypes.all;

entity tb_FibProc is
end tb_FibProc;

architecture Test of tb_FibProc is
  type fib_t is array (1 to 47) of unsigned(31 downto 0);

  signal clk    : std_logic := '0';
  signal reset  : std_logic := '1';
  signal n      : word_t := (others => '0');
  signal start  : std_logic := '0';
  signal result : word_t;
  signal ready  : std_logic;
  signal done   : boolean := false;

  function fibs return fib_t is
    variable f : fib_t;
  begin
    f(1) := to_unsigned(1, 32);
    f(2) := to_unsigned(1, 32);
    for k in 3 to 47 loop
      f(k) := f(k - 1) + f(k - 2);
    end loop;
    return f;
  end function;

  constant FIB : fib_t := fibs;
begin
  dut : entity work.FibProc(Structural)
    port map (reset => reset, clk => clk, n => n, start => start,
              result => result, ready => ready);

  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable cyc : integer;

    procedure run(m : integer) is
    begin
      n     <= std_logic_vector(to_unsigned(m, 32));
      start <= '1';
      wait until falling_edge(clk);
      start <= '0';
      cyc := 1;
      while ready /= '1' and cyc < 100 loop
        wait until falling_edge(clk);
        cyc := cyc + 1;
      end loop;
      assert unsigned(result) = FIB(m) and cyc = m + 4
        report "FEHLER: n=" & integer'image(m) & ", " & integer'image(cyc) & " Takte"
        severity failure;
      wait until falling_edge(clk);
      assert ready = '0'
        report "FEHLER: ready laenger als einen Takt" severity failure;
    end procedure;
  begin
    wait for 12 ns;
    reset <= '0';
    wait until falling_edge(clk);

    -- 1. Alle Fibonacci-Zahlen bis F(47)
    for k in 1 to 47 loop
      run(k);
    end loop;
    report "ok: F(1) .. F(47), ready nach n + 4 Takten fuer einen Takt" severity note;

    -- 2. Reset mitten in der Rechnung
    n     <= std_logic_vector(to_unsigned(30, 32));
    start <= '1';
    wait until falling_edge(clk);
    start <= '0';
    for k in 1 to 10 loop
      wait until falling_edge(clk);
    end loop;
    wait for 2 ns;
    reset <= '1';
    wait for 1 ns;
    assert ready = '0' and unsigned(result) = 0
      report "FEHLER: Reset im Betrieb" severity failure;
    wait until falling_edge(clk);
    reset <= '0';
    run(20);
    report "ok: Reset mitten in der Rechnung, danach F(20) korrekt" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
