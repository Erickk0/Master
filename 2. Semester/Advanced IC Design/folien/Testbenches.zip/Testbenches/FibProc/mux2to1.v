// 2:1-Multiplexer des Fibonacci-Prozessors
module mux2to1
  #(parameter DWIDTH = 32)
   (input  wire [DWIDTH - 1 : 0] a0,
    input  wire [DWIDTH - 1 : 0] a1,
    input  wire                  sel,
    output wire [DWIDTH - 1 : 0] b);

  // Simply choose either a0 or a1
  assign b = sel ? a1 : a0;

endmodule
