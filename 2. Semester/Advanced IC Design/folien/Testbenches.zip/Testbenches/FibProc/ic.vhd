----------------------------------------------------------------------------------
-- Author: Steffen Reith <Steffen.Reith@hs-rm.de>
--
-- Create Date:    22:49:58 11/17/2013
-- Design Name: 
-- Module Name:    IC - Behavioral
-- Project Name:   Fibonacci Processor 
--
-- Revision: $Id: IC.vhd 179 2014-04-17 22:01:36Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library FibLib;
use FibLib.FTypes.all;

entity IC is

  port (reset  : in  std_logic;
        clk    : in  std_logic;
        loadIC : in  std_logic;
        iCnt   : in  word_t;
        decIC  : in  std_logic;
        isZero : out std_logic);

end IC;

architecture Behavioral of IC is

  signal icReg : word_t;

begin

  process(reset, clk, loadIC, iCnt, decIC)
  begin

    -- Asynchronous reset
    if (reset = '1') then

      -- Init the instruction counter;
      icReg <= (others => '0');

    elsif (rising_edge(clk)) then       -- Wait for a rising edge

      -- Check if the instruction counter has to be loaded
      if (loadIC = '1') then

        -- Load the instruction counter
        icReg <= iCnt;

      end if;

      -- Check if the IC has to be incremented
      if (decIC = '1') then

        -- Increment PC for next instruction (4 bytes aligned)
        icReg <= std_logic_vector(unsigned(icReg) - 1);

      end if;

    end if;

  end process;

  -- Set output flag if counter is zero
  isZero <= '1' when (icReg = ZeroWord)
            else '0';

end Behavioral;

