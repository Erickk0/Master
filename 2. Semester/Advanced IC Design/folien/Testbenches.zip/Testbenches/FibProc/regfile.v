// Registerfile mit zwei Registern (Fibonacci-Prozessor)
module regfile
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    input  wire                  adr,
    input  wire                  writeEnable,
    input  wire [DWIDTH - 1 : 0] dataI,
    output wire [DWIDTH - 1 : 0] dataA,
    output wire [DWIDTH - 1 : 0] dataB);

  reg [DWIDTH - 1 : 0] reg0, reg1;

  always @(posedge clk or posedge reset)
    if (reset) begin            // Asynchronous reset
      reg0 <= 0;
      reg1 <= 0;
    end else if (writeEnable) begin
      if (!adr)
        reg0 <= dataI;          // Write to first register
      else
        reg1 <= dataI;          // Write to second register
    end

  // Output ports for the two registers
  assign dataA = reg0;
  assign dataB = reg1;

endmodule
