----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    MUX2to1 - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: MUX2to1.vhd 183 2014-04-18 09:46:42Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity MUX2to1 is

  port (a0  : in  word_t;
        a1  : in  word_t;
        sel : in  std_logic;
        b   : out word_t);

end MUX2to1;

architecture Behavioral of MUX2to1 is

begin

  -- Simply choose either a0 or a1
  b <= a0 when (sel = '0')
          else a1;

end Behavioral;
