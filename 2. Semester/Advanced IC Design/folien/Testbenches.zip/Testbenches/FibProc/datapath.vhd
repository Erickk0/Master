----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    AU - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: DataPath.vhd 181 2014-04-18 08:46:17Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity DataPath is

  port (reset   : in  std_logic;
        clk     : in  std_logic;
        value   : in  word_t;
        loadReg : in  std_logic;
        adr     : in  std_logic;
        writeEnable : in  std_logic;
        output  : out word_t);

end DataPath;

architecture Structural of DataPath is

  signal portA  : word_t;               -- First input port of AU
  signal dataI  : word_t;               -- Input port of register file
  signal dataA  : word_t;               -- First output port of register file
  signal dataB  : word_t;               -- Second output port of register file
  signal result : word_t;               -- Result of operation (addition)

begin

  au : entity work.AU(Behavioral)
    port map (portA  => dataA,
              portB  => dataB,
              result => result);

  outmux : entity work.MUX2to1(Behavioral)
    port map (a0  => dataA,
              a1  => dataB,
              sel => adr,
              b   => output);  

  regmux : entity work.MUX2to1(Behavioral)
    port map (a0  => result,
              a1  => value,
              sel => loadReg,
              b   => dataI);

  regfile : entity work.RegFile(Behavioral)
    port map (reset => reset,
              clk   => clk,
              adr   => adr,
              writeEnable => writeEnable,
              dataI => dataI,
              dataA => dataA,
              dataB => dataB);

end Structural;
