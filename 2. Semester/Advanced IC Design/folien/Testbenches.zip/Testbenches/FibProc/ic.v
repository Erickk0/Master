// Iterationszaehler des Fibonacci-Prozessors: laden, herunterzaehlen,
// isZero melden
module ic
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    input  wire                  loadIC,
    input  wire [DWIDTH - 1 : 0] iCnt,
    input  wire                  decIC,
    output wire                  isZero);

  reg [DWIDTH - 1 : 0] icReg;

  always @(posedge clk or posedge reset)
    if (reset)
      icReg <= 0;               // Asynchronous reset
    else begin
      if (loadIC)
        icReg <= iCnt;          // Load the counter
      if (decIC)
        icReg <= icReg - 1;     // Decrement (the last assignment wins)
    end

  // Set output flag if counter is zero
  assign isZero = (icReg == 0);

endmodule
