----------------------------------------------------------------------------------
--
-- Package: FTypes 
--
-- Purpose: This package defines types, subtypes and constants for the Fibonacci
--          processor
--
-- Revision: $Id: FTypes.vhd 178 2014-04-17 19:41:59Z streit $
--
----------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

package FTypes is

  -- Data width (size of register)
  constant dWidth : integer := 32;

  -- Processor word
  subtype word_t is std_logic_vector(dWidth - 1 downto 0);

  -- Constant zero
  constant ZeroWord : word_t := (others => '0');

  -- Constant One
  constant OneWord : word_t := (0 => '1', others => '0');

  -- Number of registers
  constant NumOfRegs : integer := 2;
  
end FTypes;
