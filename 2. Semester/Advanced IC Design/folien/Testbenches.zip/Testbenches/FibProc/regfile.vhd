----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    AU - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: RegFile.vhd 181 2014-04-18 08:46:17Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity RegFile is

  port (reset       : in  std_logic;
        clk         : in  std_logic;
        adr         : in  std_logic;
        writeEnable : in  std_logic;
        dataI       : in  word_t;
        dataA       : out word_t;
        dataB       : out word_t);

end RegFile;

architecture Behavioral of RegFile is

  -- The type for the register file
  type regs_t is array (NumOfRegs - 1 downto 0) of word_t;

  -- The register file (Array inits are synthesized by XST)
  signal regs : regs_t := (others => (others => '0'));

begin

  process(clk, reset)
  begin

    -- Asynchronous reset
    if (reset = '1') then

      -- Init the register file
      regs <= (others => (others => '0'));

    -- Wait for the rising edge
    elsif (rising_edge(clk)) then

      -- Check if we are allowed to write into the registers
      if (writeEnable = '1') then
        
        -- Check which which register we will write
        if (adr = '0') then

          -- Write to first register
          regs(0) <= dataI;

        else
          
          -- Write to second register
          regs(1) <= dataI;

        end if;

      end if;

    end if;

  end process;

  -- Output ports for the two registers
  dataA <= regs(0);
  dataB <= regs(1);

end architecture;
