----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    AU - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: AU.vhd 178 2014-04-17 19:41:59Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library FibLib;
use FibLib.FTypes.all;

entity AU is

  port (portA  : in  word_t;
        portB  : in  word_t;
        result : out word_t);

end AU;

architecture Behavioral of AU is

begin

  -- Simply add the inputs
  result <= std_logic_vector(unsigned(portA) + unsigned(portB));

end architecture;
