// Steuerautomat des Fibonacci-Prozessors (teil8.typ, Folien "Erzeugung der
// Steuersignale" bis "(III)")
module fsm
  #(parameter DWIDTH = 32)
   (input  wire                  reset,
    input  wire                  clk,
    output reg                   loadIC,
    output reg                   decIC,
    output reg  [DWIDTH - 1 : 0] value,
    output reg                   adr,
    output reg                   loadReg,
    output reg                   writeEnable,
    input  wire                  start,
    input  wire                  isZero,
    output reg                   ready);

  // All possible states of the FSM
  localparam [3:0] IDLE    = 4'd0, LOAD1   = 4'd1, LOAD2 = 4'd2,
                   LOAD3   = 4'd3, CALC1   = 4'd4, CALC2 = 4'd5,
                   OUTPUT1 = 4'd6, OUTPUT2 = 4'd7, CRASH = 4'd8;

  reg [3:0] state, stateN;

  // State handler
  always @(posedge clk or posedge reset)
    if (reset)                // Asynchron reset
      state <= IDLE;            // Set FSM to initial state
    else
      state <= stateN;          // Goto next state

  // Transition and output logic
  always @(*) begin
    // Set defaults
    stateN = state; writeEnable = 1'b1;
    loadIC = 1'b0;  value       = 0;
    adr    = 1'b0;  loadReg     = 1'b0;
    decIC  = 1'b0;  ready       = 1'b0;

    case (state)               // Handle all possible states

      IDLE: begin
        writeEnable = 1'b0;     // Do not write to the register file
        if (start)              // Check for start signal
          stateN = LOAD1;
        else
          stateN = IDLE;        // Wait for start
      end

      LOAD1: begin
        writeEnable = 1'b0;     // Do not write to the register file
        loadIC      = 1'b1;     // Load the iteration counter
        stateN      = LOAD2;
      end

      LOAD2: begin              // Load the first register with one
        loadReg = 1'b1;
        adr     = 1'b0;
        value   = 1;
        stateN  = LOAD3;
      end

      LOAD3: begin              // Load the second register with one
        loadReg = 1'b1;
        adr     = 1'b1;
        value   = 1;
        decIC   = 1'b1;         // Decrement the counter (done in CALC1)
        stateN  = CALC1;
      end

      CALC1: begin
        adr = 1'b0;             // Write result to first register
        if (isZero) begin       // Calculation done?
          writeEnable = 1'b0;
          stateN      = OUTPUT1;
        end else begin
          decIC  = 1'b1;
          stateN = CALC2;
        end
      end

      CALC2: begin
        adr = 1'b1;             // Write result to second register
        if (isZero) begin
          writeEnable = 1'b0;
          stateN      = OUTPUT2;
        end else begin
          decIC  = 1'b1;
          stateN = CALC1;
        end
      end

      OUTPUT1: begin
        adr         = 1'b0;     // Hold the address for the output multiplexer
        ready       = 1'b1;
        writeEnable = 1'b0;
        stateN      = IDLE;
      end

      OUTPUT2: begin
        adr         = 1'b1;
        ready       = 1'b1;
        writeEnable = 1'b0;
        stateN      = IDLE;
      end

      CRASH:
        stateN = CRASH;         // Stay a while, stay forever

      default:
        stateN = CRASH;         // Should not happen

    endcase
  end

endmodule
