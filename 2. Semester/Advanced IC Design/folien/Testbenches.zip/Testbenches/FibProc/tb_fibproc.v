// Selbstpruefende Testbench fuer fibproc (32 Bit):
//   1. Fuer n = 1 .. 47 wird F(n) berechnet (F(1) = F(2) = 1, F(47) ist die
//      groesste Fibonacci-Zahl, die in 32 Bit passt) und mit einem
//      Referenzmodell verglichen. ready kommt nach genau n + 4 Takten und
//      ist genau einen Takt lang.
//   2. Ein asynchroner Reset mitten in der Rechnung bricht sie ab; die
//      naechste Rechnung ist wieder korrekt.
// Stimuli werden an der fallenden Flanke gesetzt und geprueft.

module tb_fibproc;

  reg           clk   = 1'b0;
  reg           reset = 1'b1;
  reg  [31 : 0] n     = 0;
  reg           start = 1'b0;
  wire [31 : 0] result;
  wire          ready;

  reg  [31 : 0] fib [1 : 47];     // Referenzmodell
  integer       k, cyc, errors = 0;

  fibproc dut (.reset(reset), .clk(clk), .n(n), .start(start),
               .result(result), .ready(ready));

  always #5 clk = ~clk;

  task run(input integer m);
    begin
      n = m; start = 1'b1;
      @(negedge clk);
      start = 1'b0;
      cyc = 1;
      while (ready !== 1'b1 && cyc < 100) begin
        @(negedge clk);
        cyc = cyc + 1;
      end
      if (result !== fib[m] || cyc != m + 4) begin
        $display("FEHLER: n=%0d result=%0d erwartet=%0d, %0d Takte statt %0d",
                 m, result, fib[m], cyc, m + 4);
        errors = errors + 1;
      end
      @(negedge clk);
      if (ready !== 1'b0) begin
        $display("FEHLER: n=%0d ready laenger als einen Takt", m);
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_fibproc.vcd");          // laeuft im Verzeichnis build/
    $dumpvars(0, tb_fibproc);

    fib[1] = 1; fib[2] = 1;
    for (k = 3; k <= 47; k = k + 1) fib[k] = fib[k - 1] + fib[k - 2];

    #12 reset = 1'b0;
    @(negedge clk);

    // 1. Alle Fibonacci-Zahlen bis F(47)
    for (k = 1; k <= 47; k = k + 1) run(k);
    $display("ok     F(1) .. F(47), ready nach n + 4 Takten fuer einen Takt");

    // 2. Reset mitten in der Rechnung
    n = 30; start = 1'b1;
    @(negedge clk);
    start = 1'b0;
    repeat (10) @(negedge clk);
    #2 reset = 1'b1;
    #1 if (ready !== 1'b0 || result !== 0) begin
      $display("FEHLER: Reset im Betrieb, ready=%b result=%0d", ready, result);
      errors = errors + 1;
    end
    @(negedge clk);
    reset = 1'b0;
    run(20);
    $display("ok     Reset mitten in der Rechnung, danach F(20) = %0d", result);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
