----------------------------------------------------------------------------------
-- Company: Hochschule RheinMain
-- Engineer: Steffen Reith <Steffen.Reith@hs-rm.de>
-- 
-- create Date:    16:10:58 04/17/2014 
-- Design Name: 
-- Module Name:    FibProc - Behavioral 
-- Project Name:   Fibonacci Processor
--
-- Revision: $Id: FibProc.vhd 181 2014-04-18 08:46:17Z streit $
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

library FibLib;
use FibLib.FTypes.all;

entity FibProc is

  port (reset  : in  std_logic;
        clk    : in  std_logic;
        n      : in  word_t;
        start  : in  std_logic;
        result : out word_t;
        ready  : out std_logic);

end FibProc;

architecture Structural of FibProc is

  signal value       : word_t;          -- Used for loading value to the RegFile
  signal adr         : std_logic;       -- select the register to be written
  signal loadReg     : std_logic;       -- Load the register by the control path
  signal writeEnable : std_logic;       -- Write to the register file

begin

  cp : entity work.ControlPath(Structural)
    port map (reset       => reset,
              clk         => clk,
              n           => n,
              value       => value,
              adr         => adr,
              loadReg     => loadReg,
              writeEnable => writeEnable,
              start       => start,
              ready       => ready);

  dp : entity work.DataPath(Structural)
    port map(reset       => reset,
             clk         => clk,
             value       => value,
             loadReg     => loadReg,
             adr         => adr,
             writeEnable => writeEnable,
             output      => result);

end Structural;
