-- Selbstpruefende Testbench fuer uniCounter (VHDL-93), N = 4:
--   1. Nach dem Reset: value = 0.
--   2. Gezielte Abschnitte: 20 Takte vorwaerts (mit Ueberlauf), 20 Takte
--      rueckwaerts (mit Unterlauf), anhalten, laden, und enable zusammen mit
--      load (enable hat Vorrang).
--   3. 200 Takte mit pseudozufaelligen Steuersignalen aus einem LFSR
--      (dieselbe Folge wie in der Verilog-Testbench).
-- In jedem Takt wird value gegen ein Referenzmodell geprueft. Eingaenge
-- werden an der fallenden Flanke gesetzt und eine fallende Flanke spaeter
-- geprueft. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_uniCounter is
end tb_uniCounter;

architecture Test of tb_uniCounter is
  constant N : integer := 4;

  signal clk    : std_logic := '0';
  signal reset  : std_logic := '1';
  signal enable : std_logic := '0';
  signal up     : std_logic := '0';
  signal load   : std_logic := '0';
  signal data   : std_logic_vector(N - 1 downto 0) := (others => '0');
  signal value  : std_logic_vector(N - 1 downto 0);
  signal done   : boolean := false;
begin
  dut : entity work.uniCounter
    generic map (N => N)
    port map (clk => clk, reset => reset, enable => enable, up => up,
              load => load, data => data, value => value);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable expected : unsigned(N - 1 downto 0);
    variable lfsr     : std_logic_vector(15 downto 0) := x"ACE1";
    variable nUp, nDown, nLoad, nHold : natural := 0;

    -- Setzt die Steuersignale, rechnet das Referenzmodell einen Takt weiter
    -- und prueft nach der naechsten steigenden Flanke.
    procedure step(e, u, l : std_logic; d : std_logic_vector(N - 1 downto 0)) is
    begin
      enable <= e; up <= u; load <= l; data <= d;
      if e = '1' and u = '1' then
        expected := expected + 1; nUp := nUp + 1;
      elsif e = '1' and u = '0' then
        expected := expected - 1; nDown := nDown + 1;
      elsif l = '1' then
        expected := unsigned(d); nLoad := nLoad + 1;
      else
        nHold := nHold + 1;
      end if;
      wait until falling_edge(clk);
      assert unsigned(value) = expected
        report "FEHLER: value = " & integer'image(to_integer(unsigned(value)))
               & ", erwartet " & integer'image(to_integer(expected))
        severity failure;
    end procedure;

    constant ZERO : std_logic_vector(N - 1 downto 0) := (others => '0');
  begin
    -- 1. Reset ueber zwei steigende Flanken halten (dazu auf zwei fallende
    --    Flanken warten)
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    assert unsigned(value) = 0 report "FEHLER: nach Reset" severity failure;
    reset    <= '0';
    expected := (others => '0');

    -- 2. Gezielte Abschnitte
    for i in 1 to 20 loop step('1', '1', '0', ZERO); end loop;  -- vorwaerts
    for i in 1 to 20 loop step('1', '0', '0', ZERO); end loop;  -- rueckwaerts
    for i in 1 to 5  loop step('0', '1', '0', ZERO); end loop;  -- anhalten
    step('0', '0', '1', "1001");                                -- laden (9)
    for i in 1 to 3  loop step('0', '0', '0', ZERO); end loop;  -- halten
    step('1', '1', '1', "0011");                    -- enable vor load
    report "ok: gezielte Abschnitte geprueft" severity note;

    -- 3. Pseudozufaellige Steuersignale
    for i in 1 to 200 loop
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      step(lfsr(0), lfsr(1), lfsr(2), lfsr(6 downto 3));
    end loop;
    report "ok: Takte: " & integer'image(nUp) & " vorwaerts, "
           & integer'image(nDown) & " rueckwaerts, "
           & integer'image(nLoad) & " laden, "
           & integer'image(nHold) & " halten" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
