-- Universeller Zaehler aus Teil 5 (VHDL), teil5.typ, Folie "Ein universeller
-- Counter". Auf der Folie steht nur die Next State Logic; Entity, Register
-- und Ausgabe sind wie beim freeBinCounter (asynchroner Reset) ergaenzt.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity uniCounter is

  generic(N : integer := 8);

  port (clk    : in  std_logic;
        reset  : in  std_logic;
        enable : in  std_logic;
        up     : in  std_logic;
        load   : in  std_logic;
        data   : in  std_logic_vector(N - 1 downto 0);
        value  : out std_logic_vector(N - 1 downto 0));

end entity;

architecture Behavioral of uniCounter is

signal cnt_reg  : std_logic_vector(N - 1 downto 0);
signal cnt_next : std_logic_vector(N - 1 downto 0);

begin
 process (clk, reset)
 begin
   -- Asynchronous reset
   if (reset = '1') then
     cnt_reg <= (others => '0');
   elsif (rising_edge(clk)) then
     cnt_reg <= cnt_next; -- Change state on rising edge
   end if;
 end process;

 -- Next state logic (von der Folie)
 cnt_next <= std_logic_vector(unsigned(cnt_reg) + 1)
               when ((enable = '1') and (up = '1')) else

             std_logic_vector(unsigned(cnt_reg) - 1)
               when ((enable = '1') and (up = '0')) else

             data when (load = '1') else

             cnt_reg;

 -- Output logic
 value <= cnt_reg;
end architecture;
