// Selbstprüfende Testbench für unicnt, WIDTH = 4:
//   1. Nach dem Reset: value = 0.
//   2. Gezielte Abschnitte: 20 Takte vorwärts (mit Überlauf), 20 Takte
//      rückwärts (mit Unterlauf), anhalten, laden, und enable zusammen mit
//      load (enable hat Vorrang).
//   3. 200 Takte mit pseudozufälligen Steuersignalen aus einem LFSR.
// In jedem Takt wird value gegen ein Referenzmodell geprüft. Eingänge werden
// an der fallenden Flanke gesetzt und eine fallende Flanke später geprüft.
// Ausgegeben werden nur die ersten 10 Fehler.

module tb_unicnt;

  localparam W = 4;

  reg            clk    = 1'b0;
  reg            reset  = 1'b1;
  reg            enable = 1'b0;
  reg            up     = 1'b0;
  reg            load   = 1'b0;
  reg  [W-1 : 0] data   = 0;
  wire [W-1 : 0] value;
  reg  [W-1 : 0] expected;
  reg  [15 : 0]  lfsr   = 16'hACE1;
  integer        nUp = 0, nDown = 0, nLoad = 0, nHold = 0;
  integer        errors = 0;

  unicnt #(.WIDTH(W)) dut (.value(value), .clk(clk), .reset(reset),
                           .enable(enable), .up(up), .load(load), .data(data));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  task check;
    begin
      if (value !== expected) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  value=%0d  erwartet=%0d", $time, value, expected);
        errors = errors + 1;
      end
    end
  endtask

  // Setzt die Steuersignale, rechnet das Referenzmodell einen Takt weiter
  // und prüft nach der nächsten steigenden Flanke.
  task step(input e, input u, input l, input [W-1 : 0] d);
    begin
      enable = e; up = u; load = l; data = d;
      if (e && u) begin
        expected = expected + 1; nUp = nUp + 1;
      end else if (e && !u) begin
        expected = expected - 1; nDown = nDown + 1;
      end else if (l) begin
        expected = d; nLoad = nLoad + 1;
      end else
        nHold = nHold + 1;
      @(negedge clk);
      check;
    end
  endtask

  initial begin
    $dumpfile("tb_unicnt.vcd");           // läuft im Verzeichnis build/
    $dumpvars(0, tb_unicnt);

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten)
    @(negedge clk); @(negedge clk);
    expected = 0;
    check;
    reset = 1'b0;

    // 2. Gezielte Abschnitte
    repeat (20) step(1, 1, 0, 0);         // vorwärts, 15 -> 0
    repeat (20) step(1, 0, 0, 0);         // rückwärts, 0 -> 15
    repeat (5)  step(0, 1, 0, 0);         // anhalten
    step(0, 0, 1, 4'd9);                  // laden
    repeat (3)  step(0, 0, 0, 0);         // Wert halten
    step(1, 1, 1, 4'd3);                  // enable hat Vorrang vor load
    $display("ok     gezielte Abschnitte geprueft, value=%0d", value);

    // 3. Pseudozufällige Steuersignale
    repeat (200) begin
      lfsr = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      step(lfsr[0], lfsr[1], lfsr[2], lfsr[6:3]);
    end
    $display("ok     Takte: %0d vorwaerts, %0d rueckwaerts, %0d laden, %0d halten",
             nUp, nDown, nLoad, nHold);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
