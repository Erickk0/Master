// Universeller Zähler: vorwärts/rückwärts zählen, anhalten, laden
// (teil5.typ, Folie "Ein universeller Zähler")
module unicnt (value, clk, reset,
               enable, up, load, data);

  parameter WIDTH = 8;

  input  wire clk, reset;
  input  wire enable, up, load;
  input  wire [WIDTH - 1 : 0] data;
  output wire [WIDTH - 1 : 0] value;

  wire [WIDTH - 1 : 0] valN;
  reg  [WIDTH - 1 : 0] val;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      val <= {WIDTH{1'b0}};
    end else begin
      val <= valN;
    end
  end

  // Nextstate logic
  assign valN = (enable &&  up) ? val + 1 :
                (enable && !up) ? val - 1 :
                load            ? data    :
                                  val;

  // Output logic
  assign value = val;

endmodule
