# Tests der Basisschaltkreise

Dieses Verzeichnis enthält den Code der Basisschaltkreise aus dem Skript
zusammen mit selbstprüfenden Testbenches. Jede Schaltung gibt es in zwei
Fassungen, VHDL und Verilog; beide stehen in Teil 5 (`teil5.typ`), die
Verilog-Fassung jeweils direkt hinter der VHDL-Fassung (bis 2026-11-09 standen
sie in `teil4.typ` und `teil9.typ`). Der Code ist wörtlich von den Folien übernommen, damit die
Tests genau das prüfen, was auf den Folien steht.

## Voraussetzungen

- [OSS CAD Suite](https://github.com/YosysHQ/oss-cad-suite-build) unter
  `/usr/local/oss-cad-suite` (anderer Ort: `make OSS_CAD=/pfad/zur/suite`).
  Die Makefiles rufen die Werkzeuge mit absolutem Pfad auf, die Suite muss
  also nicht im `PATH` stehen.
- Verwendet werden Verilator (Lint), Icarus Verilog (Simulation), GHDL
  (VHDL: Lint, Simulation, Synthese nach Verilog) und Yosys (Synthese,
  Latch-Test, Äquivalenzprüfung, Schaltbilder).

## Aufruf

In einem der Verzeichnisse:

```sh
cd src/PriorityEncoder
make
```

| Ziel | Wirkung |
|---|---|
| `make` | Lint, Latch-Test, Simulation und, wo sinnvoll, Äquivalenzprüfung |
| `make lint` | Verilator `-Wall` für Verilog, `ghdl -a -Wall` für VHDL |
| `make latch` | Synthese mit Yosys; bricht ab, wenn ein Latch entsteht (bei rein kombinatorischen Schaltungen auch bei einem Flip-Flop) |
| `make sim` | Simulation mit Icarus Verilog bzw. GHDL; die Testbench meldet `PASS` oder bricht mit einem Fehler ab |
| `make equiv` | formaler Beweis mit Yosys, dass VHDL- und Verilog-Fassung dieselbe Funktion haben |
| `make show` | Schaltbilder auf Gatterebene (`build/*_gates.svg`) |
| `make show-rtl` | Schaltbilder auf RTL-Ebene nach `proc` (`build/*_rtl.svg`) |
| `make clean` | löscht `build/` |

Für einzelne Teile gibt es die Ziele auch je Sprache (`lint-v`, `sim-vhd`,
…) und je Verilog-Variante (`sim-v-prienc_casez`, `show-v-tickcnt_reduce`,
…). Bilder als PNG oder PDF: `make show SHOW_FORMAT=png`.

Alle erzeugten Dateien (Logs, Statistiken, Wellenformen `*.vcd`, Bilder)
landen in `build/` und stehen nicht in git. Die Wellenformen lassen sich mit
`gtkwave build/tb_….vcd` ansehen.

## Die Schaltungen

| Verzeichnis | Schaltung | Äquivalenz | Besonderheiten der Testbench |
|---|---|---|---|
| `Decoder` | Decoder 3 → 8 | ja | alle 8 Eingaben gegen eine Tabelle |
| `PriorityEncoder` | Prioritätsencoder, Verilog mit `?:` und mit `casez` | ja | alle 16 Eingaben, eine Testbench für beide Varianten |
| `BinCounter` | frei laufender Binärzähler | nein | Überlauf, synchroner vs. asynchroner Reset |
| `MaxTick` | Binärzähler mit Überlauf-Flag, Verilog mit `?:` und mit `&` | nein | Flag in jedem Takt, Anzahl der Ticks |
| `UniCounter` | universeller Zähler (vorwärts, rückwärts, halten, laden) | nein | `task`/`procedure` `step`, Steuersignale aus einem LFSR |
| `LookAhead` | Zähler mit „Blick in die Zukunft“ | nein | Ausgabe ist immer Register + 1, auch während des Resets |
| `ModCounter` | Modulo-Zähler mit VGA-HSYNC | nein | zwei volle Perioden, Lage und Länge der sync-Pulse |
| `ShiftReg` | universelles Schieberegister | nein | Serialisieren, Füllen, Modi aus einem LFSR |
| `Debounce` | Entprellung mit Schieberegister und `alarm`, zusätzlich SystemVerilog-Fassung nur mit `logic` (`debounce_logic.sv`) | nein (VHDL), ja (`.sv` gegen `.v`) | prellende Abtastwerte, Wechsel und `alarm`-Pulse zählen, VHDL ohne Reset |
| `Debouncer` | Entprellung mit Zähler | nein | Störimpulse 1 bis 7 Takte, Takte bis zur Übernahme messen, VHDL ohne Reset |
| `Memory` | Dual-Port-BlockRAM (A lesen, B schreiben/lesen) | nein | alle Adressen, Zufallszugriffe mit Kollisionen, zusätzlich `make demo` |
| `GrayCnt` | Gray-Zähler: Binärzähler mit Umwandlung (Teil 11) | ja | Referenzmodell `k xor k/2`, `enable` aus einem LFSR, Hammingdistanz 1, alle 32 Codewörter |
| `GrayCntNative` | Gray-Zähler ohne Addierer mit Toggle-Bit `hBit` (Teil 11), zusätzlich SystemVerilog-Fassung nur mit `logic` (`graycnt_native_logic.sv`) | ja (mit `EQUIV_RENAME`), `.sv` auch gegen `.v` | wie `GrayCnt`, dieselbe Folge bei anderer Zustandscodierung |
| `Latch` | Latch-Beispiel, falsche und korrigierte Fassung | ja (korrigiert) | alle 16 Übergänge, zusätzlich `make demo` |
| `Synchronizer` | Synchronizer mit zwei Flip-Flops, asynchroner Reset (Teil 12) | ja (mit `EQUIV_RENAME`) | `async` wechselt zu zufälligen Zeitpunkten (nie genau auf der Flanke), Referenzmodell mit zwei Registern, Latenz zwei Takte, Reset mitten im Takt |
| `Adder` | Volladdierer (Teil 2, Folie „EDA-Tools“) | ja | alle 8 Eingaben gegen `a + b + cin` |
| `Lights` | Lauflicht als Moore-Automat (Teil 7), alle acht Zustände ausgeschrieben | ja (mit `EQUIV_RENAME`) | asynchroner Reset, 20 Takte Lauflicht mit Umlauf, Reset mitten im Takt |
| `EdgeDetectMealy` | Flankenerkennung als Mealy-Automat (Teil 7) | ja (mit `EQUIV_RENAME`) | `tick = data & ~d1` nach jedem zufälligen Wechsel von `data`, Glitch zwischen zwei Flanken erscheint an `tick`, Reset im Takt |
| `EdgeDetectMoore` | Flankenerkennung als Moore-Automat (Teil 7), Verilog mit `default` für den unbenutzten Zustand | ja (mit `EQUIV_RENAME`) | `tick = d1 & ~d2` (taktsynchron, genau ein Takt), Glitch erzeugt keinen `tick`, Reset im Takt |
| `AsyncFifo` | Asynchroner FIFO mit zwei Clock-Domains (Teil 12), Quelle aus `Material/aFifo.zip`, Gray-Zähler aus `GrayCntNative` (`V_SUB`), gewolltes Latch `exCase` (`LATCH_OK`) | nein (GHDL schreibt das Latch fehlerhaft in die Netzliste, siehe Makefile) | Scoreboard über beide Takte (10/26 ns): Füllen bis `isFull` bei 32 Worten, Leeren bis `isEmpty`, zufällig schreiben/lesen, Reihenfolge der Daten |
| `FibProc` | Fibonacci-Prozessor, Automat mit Datenpfad (Teil 8), Quelle aus `Material/fibproc.zip`, acht Module, VHDL-Paket `FibLib` (`VHD_LIBS`), Verilog mit Parameter `DWIDTH` (`V_SUB`) | ja (mit `EQUIV_RENAME` und `EQUIV_GOLD`) | F(1) bis F(47) gegen ein Referenzmodell, `ready` nach n + 4 Takten für einen Takt, Reset mitten in der Rechnung |
| `RCAdder` | Halbaddierer, Volladdierer und generischer Ripple-Carry-Addierer (Teil 9): VHDL `for … generate`, Verilog `generate for` mit `genvar` | ja | alle 8192 Kombinationen von `a`, `b`, `cin` (6 Bit) |
| `PriEncGen` | Generischer Prioritätsencoder, rekursiv (Teil 9): VHDL `if … generate`, Verilog `generate if` mit rekursiver Modulinstanz | ja | `src = 0`, alle Einer-Muster, Prioritätsmuster, 5000 Zufallsmuster (32 Bit); Verilator-Lint meldet bei der Rekursion falsche Warnungen, siehe Makefile |
| `ORn` | Oder über alle Bits mit Schleife (Teil 9), Verilog zusätzlich mit Reduktionsoperator `\|` (`orn_reduce.v`) | ja, `.v` auch gegen `orn_reduce.v` | alle 256 Eingaben |
| `BMult` | 5-Bit-Multiplizierer ohne Pipeline, Verilog-Fassung (Teil 14), bewusst redundante Signale als Vorstufe zu `PMult`; die Folien zeigen nur einen Ausschnitt | ja | alle 1024 Produkte |
| `PMult` | 5-Bit-Multiplizierer mit Pipeline, SystemVerilog-Fassung (Teil 14); die Folien zeigen nur einen Ausschnitt, hier die vollständige Fassung | ja (mit `EQUIV_RENAME`) | Folge aus dem Timingdiagramm (10..14 · 20), alle 1024 Produkte bei voller Pipeline gegen ein Schieberegister-Referenzmodell (Latenz 4), Reset im Betrieb |
| `MultiDriver` | Zwei `assign` auf dasselbe Signal, mit `wire` und mit `logic` (Teil 4) | nein | `wire`: keine Meldung, `y` wird X bei `a != b`; `logic`: Icarus-Fehler, Verilator `MULTIDRIVEN` (eigenes Makefile ohne rules.mk) |

**Keine Äquivalenzprüfung** bei den sequentiellen Schaltungen: Die
VHDL-Fassungen in Teil 5 setzen asynchron zurück, die Verilog-Fassungen
synchron (`Debounce`, `Debouncer`: VHDL ganz ohne Reset, nur Startwerte). Die beiden Schaltungen sind also absichtlich verschieden;
die Testbenches prüfen jeweils das eigene Reset-Verhalten. Gesteuert wird
das im Makefile mit `EQUIV := 0`.

**Register für die Äquivalenzprüfung zuordnen.** Yosys `equiv_make` ordnet
Register nur über gleiche Namen zu. GHDL schreibt sie klein (`hbit_reg`),
in Verilog heißen sie oft anders (`hBit`). Solange der ganze Zustand am
Ausgang sichtbar ist, schadet das nicht. Beim Gray-Zähler ohne Addierer ist
das Toggle-Bit aber versteckt, und die Induktion scheitert. Abhilfe schafft
`EQUIV_RENAME := hBit:hbit_reg val:val_reg` (Verilog-Name:VHDL-Name) im
Makefile, siehe `GrayCntNative`.

**SystemVerilog und Vergleich von Varianten.** Dateien mit der Endung `.sv`
werden als SystemVerilog gelesen (Icarus `-g2012`, Yosys `read_verilog -sv`).
Mit `EQUIV_V := 1` vergleicht `make` zusätzlich jede weitere Datei in `V_SRC`
formal mit der ersten (`make equiv-v`). In `Debounce` beweist das, dass
`debounce_logic.sv` und `debounce.v` dieselbe Schaltung beschreiben.

### `make demo` in `Latch`

`ll.v` und `ll.vhd` sind absichtlich falsch (unvollständige
Sensitivitätsliste, fehlende Zuweisungen, kein `else`). `make demo` prüft,
dass die falsche Fassung genau die erwarteten Probleme zeigt: Yosys findet
zwei Latches (`Latch inferred for signal \ll.\eq`), Verilator und Icarus
warnen nicht, GHDL warnt vor der Sensitivitätsliste und verweigert die
Synthese, und beide Simulationen fallen durch. `make` ruft `demo` in diesem
Verzeichnis mit auf. In den anderen Verzeichnissen gibt es kein `demo`, weil
der Code dort richtig ist.

### `make demo` in `Memory`

GHDL simuliert Port B des BlockRAMs als „write first“: Die `shared variable`
wird erst beschrieben und dann gelesen, `dOutB` liefert also den neuen Wert.
`ghdl --synth` erzeugt aber eine Netzliste mit „read first“. `make demo`
lässt die Verilog-Testbench gegen diese Netzliste laufen und prüft, dass
sie genau beim Schreiben an `dOutB` scheitert. Simulation und Synthese
derselben VHDL-Quelle verhalten sich hier also verschieden.

Das Package `CPUTypes` liegt in der Bibliothek `cpu`. Solche Bibliotheken
gibt das Makefile mit `VHD_LIBS := cpu:cputypes.vhd` an; `rules.mk`
übersetzt sie vorher nach `build/`.

### Gegenproben

Beim Erstellen wurde jede Testbench mit absichtlich verfälschten Fassungen
geprüft (z. B. vertauschte Priorität, Zähler um 2, fehlender `case`-Zweig),
um sicherzugehen, dass sie Fehler auch findet. Diese Varianten stehen nicht
im Repository.

## Eine neue Schaltung hinzufügen

1. Neues Verzeichnis anlegen, Code der Folien als `.v` und `.vhd`
   übernehmen, dazu je eine Testbench `tb_<modul>.v` und `tb_<entity>.vhd`.
2. Ein kleines `Makefile` schreiben, z. B.:

   ```make
   V_TOP   := modcnt          # Verilog-Topmodul
   V_SRC   := modcnt.v        # mehrere Dateien = Varianten desselben Moduls
   V_TB    := tb_modcnt.v

   VHD_TOP := modCnt          # Schreibweise wie im VHDL-Quelltext
   VHD_SRC := modcnt.vhd
   VHD_TB  := tb_modcnt.vhd

   VHD_LIBS := cpu:cputypes.vhd # optional: weitere Bibliotheken (bibliothek:datei)
   COMB    := 0               # 1 = rein kombinatorisch (keine Flip-Flops erlaubt)
   EQUIV   := 0               # 0 = ohne Äquivalenzprüfung
   EQUIV_V := 1               # optional: Varianten in V_SRC untereinander vergleichen

   include ../rules.mk
   ```

3. Konventionen für die Testbenches:
   - Verilog gibt am Ende `PASS` oder `FAIL (…)` aus und schreibt die
     Wellenform nach `tb_<modul>.vcd` (die Simulation läuft in `build/`).
   - VHDL bricht bei einem Fehler mit `severity failure` ab und meldet am
     Ende `PASS` mit `severity note`.
   - Eingänge an der fallenden Taktflanke setzen und dort auch prüfen,
     damit es keine Races mit der steigenden Flanke gibt.

## Bekannte Eigenheiten der Werkzeuge

- **VHDL-Dateien nur in ASCII.** GHDL liest VHDL-93 als Latin-1; ein UTF-8-„Ü“
  enthält ein dort ungültiges Steuerzeichen. Deshalb stehen in den
  `.vhd`-Dateien ae, oe, ue statt Umlauten.
- **GHDL-Plugin für Yosys.** `yosys -m ghdl` stürzt in der Suite vom
  2027-11-07 bei jedem Flip-Flop ab. VHDL wird deshalb mit
  `ghdl --synth --out=verilog` in eine Verilog-Netzliste übersetzt, die
  Yosys dann einliest.
- **Indizes in VHDL-Netzlisten.** GHDL nummeriert Vektoren ab 0; aus
  `req(4 downto 1)` wird `req[3:0]`. In Schaltbildern der VHDL-Fassung sind
  die Bitnummern deshalb verschoben.
- Ältere Suite (2026-01-05) unter macOS 27: Das GHDL-Binary startete wegen
  eines doppelten `LC_RPATH` nicht. Abhilfe: dreimal
  `install_name_tool -delete_rpath @executable_path/../lib/` und
  `codesign -f -s -` auf `libexec/ghdl`.
