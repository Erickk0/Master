// Selbstpruefende Testbench fuer adder: alle 8 Eingaben gegen a + b + cin.
module tb_adder;

  reg     a, b, cin;
  wire    s, cout;
  integer i, errors = 0;

  adder dut (.a(a), .b(b), .cin(cin), .s(s), .cout(cout));

  initial begin
    $dumpfile("tb_adder.vcd");            // laeuft im Verzeichnis build/
    $dumpvars(0, tb_adder);
    for (i = 0; i < 8; i = i + 1) begin
      {a, b, cin} = i;
      #1;
      if ({cout, s} !== a + b + cin) begin
        $display("FEHLER: %b + %b + %b = %b%b", a, b, cin, cout, s);
        errors = errors + 1;
      end
    end
    $display("ok     alle 8 Eingaben");
    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
