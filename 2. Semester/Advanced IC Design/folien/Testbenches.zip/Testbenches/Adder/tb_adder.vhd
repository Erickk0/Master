-- Selbstpruefende Testbench fuer Adder (VHDL-93): alle 8 Eingaben gegen
-- a + b + cin. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_Adder is
end tb_Adder;

architecture Test of tb_Adder is
  signal a, b, cin, s, cout : std_logic;
begin
  dut : entity work.Adder
    port map (a => a, b => b, cin => cin, s => s, cout => cout);

  stimulus : process
    variable v : unsigned(2 downto 0);
  begin
    for i in 0 to 7 loop
      v   := to_unsigned(i, 3);
      a   <= v(2);
      b   <= v(1);
      cin <= v(0);
      wait for 1 ns;
      assert unsigned'(cout & s) = ("0" & v(2)) + ("0" & v(1)) + ("0" & v(0))
        report "FEHLER bei Eingabe " & integer'image(i) severity failure;
    end loop;
    report "ok: alle 8 Eingaben" severity note;
    report "PASS" severity note;
    wait;
  end process;
end Test;
