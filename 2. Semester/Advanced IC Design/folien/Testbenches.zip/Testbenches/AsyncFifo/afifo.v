// Asynchroner FIFO, Verilog-Fassung von afifo.vhd (teil12.typ, Folien
// "Ein asynchroner FIFO" bis "(VI)"). Die Adressen erzeugt der Gray-Zaehler
// ohne Addierer aus ../GrayCntNative/graycnt_native.v.
//
// References: Peter Alfke, Asynchronous FIFO in Virtex-II FPGAs, TechXclusives, 2001
module afifo
  #(parameter dWidth = 8,      // Width of data to be handled by the fifo
    parameter aWidth = 5)      // Width of fifo addresses (#Items = 2**aWidth)

   (input  wire clr,           // Clear the fifo and init state (synchron reset)

    // Read port of fifo
    output reg  [dWidth - 1 : 0] readData,
    output wire                  isEmpty,
    input  wire                  readEnable,
    input  wire                  rClk,

    // Write port of fifo
    input  wire [dWidth - 1 : 0] writeData,
    output wire                  isFull,
    input  wire                  writeEnable,
    input  wire                  wClk);

  // Holds all data stored in the fifo
  reg  [dWidth - 1 : 0] memory [0 : 2**aWidth - 1];

  // Store the possibility of a future empty / full warning in a latch
  reg  exCase;

  // Synchronous flags for full / empty state
  reg  full, empty;

  // Asynchronous flags for empty / full state
  wire aFull, aEmpty;

  // Read / write pointer to circular buffer
  wire [aWidth - 1 : 0] readAdr, writeAdr;

  // Indicates that readAdr and writeAdr are equal (empty / full situation)
  wire equalAdr;

  // Enable signals for new read / write address
  wire nextWriteAdrEnable, nextReadAdrEnable;

  // Warnings for an empty / full situation in the next future
  wire emptyWarn, fullWarn;

  // Write port logic (synchron to the write domain)
  always @(posedge wClk)
    if (writeEnable && !full)
      memory[writeAdr] <= writeData;

  // Read port logic (synchron to the read domain)
  always @(posedge rClk)
    if (readEnable && !empty)
      readData <= memory[readAdr];

  // Check if readAdr and writeAdr are the same (empty / full situation)
  assign equalAdr = (readAdr == writeAdr);

  // Gray counter for generating the write address
  assign nextWriteAdrEnable = ~full & writeEnable;
  graycnt_native #(.WIDTH(aWidth))
    writeCnt (.clk(wClk), .reset(clr), .enable(nextWriteAdrEnable), .gval(writeAdr));

  // Gray counter for generating the read address
  assign nextReadAdrEnable = ~empty & readEnable;
  graycnt_native #(.WIDTH(aWidth))
    readCnt (.clk(rClk), .reset(clr), .enable(nextReadAdrEnable), .gval(readAdr));

  // Read pointer one quadrant ahead of the write pointer (full warning)
  assign fullWarn  = (writeAdr[aWidth - 2] ~^ readAdr[aWidth - 1]) &
                     (writeAdr[aWidth - 1] ^  readAdr[aWidth - 2]);

  // Write pointer one quadrant ahead of the read pointer (empty warning)
  assign emptyWarn = (writeAdr[aWidth - 2] ^  readAdr[aWidth - 1]) &
                     (writeAdr[aWidth - 1] ~^ readAdr[aWidth - 2]);

  // Store possible exceptional cases (empty / full) in a latch (gewollt)
  /* verilator lint_off LATCH */
  always @(*)
    if (clr || emptyWarn)
      exCase = 1'b0;    // possible empty condition in the next future
    else if (fullWarn)
      exCase = 1'b1;    // possible full condition in the next future
  /* verilator lint_on LATCH */

  // Generate asynchronous empty / full signals
  assign aFull  =  exCase & equalAdr;
  assign aEmpty = ~exCase & equalAdr;

  // Synchronize the falling edge of the asynchronous empty signal
  // (the rising edge is already synchron)
  always @(posedge rClk or posedge aEmpty)
    if (aEmpty)
      empty <= 1'b1;    // synchron, because aEmpty = 1 needs equalAdr = 1
    else
      empty <= 1'b0;    // not empty, the falling edge is synchronized too

  // Synchronize the falling edge of the asynchronous full signal
  always @(posedge wClk or posedge aFull)
    if (aFull)
      full <= 1'b1;     // synchron, because aFull = 1 needs equalAdr = 1
    else
      full <= 1'b0;     // not full, the falling edge is synchronized too

  // Output the empty / full state
  assign isEmpty = empty;
  assign isFull  = full;

endmodule
