-- Selbstpruefende Testbench fuer aFifo (VHDL-93, dWidth = 8, aWidth = 5,
-- 32 Worte). Schreibtakt 10 ns, Lesetakt 26 ns (zwei Clock-Domains).
-- Referenzmodell: ein Scoreboard merkt sich jedes angenommene Wort
-- (Schreiben bei writeEnable und isFull = '0') und vergleicht beim Lesen
-- (readEnable und isEmpty = '0') das Wort an readData nach der Flanke.
-- Geprueft wird ausserdem: nie mehr als 32 Worte, nie Lesen aus einem
-- leeren FIFO.
--   1. Fuellen (nur schreiben): isFull kommt, dann sind genau 32 Worte drin.
--   2. Leeren (nur lesen): isEmpty kommt, dann ist das Scoreboard leer.
--   3. 400 Schreibtakte mit zufaelligem Schreiben und Lesen (LFSR).
--   4. Leeren; alle geschriebenen Worte wurden in der richtigen
--      Reihenfolge gelesen.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_aFifo is
end tb_aFifo;

architecture Test of tb_aFifo is
  constant DW    : integer := 8;
  constant AW    : integer := 5;
  constant DEPTH : integer := 2**AW;

  type sb_t is array (0 to 255) of std_logic_vector(DW - 1 downto 0);

  signal clr         : std_logic := '1';
  signal wClk, rClk  : std_logic := '0';
  signal writeEnable : std_logic := '0';
  signal readEnable  : std_logic := '0';
  signal writeData   : std_logic_vector(DW - 1 downto 0) := (others => '0');
  signal readData    : std_logic_vector(DW - 1 downto 0);
  signal isEmpty     : std_logic;
  signal isFull      : std_logic;
  signal done        : boolean := false;

  -- Verhalten der beiden Seiten: 0 = aus, 1 = immer, 2 = zufaellig
  signal wMode, rMode : integer := 0;

  -- Scoreboard
  signal sb         : sb_t;
  signal head, tail : integer := 0;

  function step(l : std_logic_vector(15 downto 0)) return std_logic_vector is
  begin
    return l(14 downto 0) & (l(15) xor l(13) xor l(12) xor l(10));
  end function;
begin
  dut : entity work.aFifo
    generic map (dWidth => DW, aWidth => AW)
    port map (clr => clr,
              readData => readData, isEmpty => isEmpty,
              readEnable => readEnable, rClk => rClk,
              writeData => writeData, isFull => isFull,
              writeEnable => writeEnable, wClk => wClk);

  wClock : process
  begin
    while not done loop
      wClk <= '0'; wait for 5 ns;
      wClk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  rClock : process
  begin
    while not done loop
      rClk <= '0'; wait for 13 ns;
      rClk <= '1'; wait for 13 ns;
    end loop;
    wait;
  end process;

  -- Schreibseite: neue Stimuli an der fallenden Flanke
  writer : process(wClk)
    variable lfsr : std_logic_vector(15 downto 0) := x"ACE1";
  begin
    if falling_edge(wClk) then
      lfsr := step(lfsr);
      if wMode = 1 or (wMode = 2 and lfsr(0) = '1') then
        writeEnable <= '1';
      else
        writeEnable <= '0';
      end if;
      writeData <= lfsr(DW - 1 downto 0);
    end if;
  end process;

  -- Leseseite
  reader : process(rClk)
    variable lfsr : std_logic_vector(15 downto 0) := x"1D2B";
  begin
    if falling_edge(rClk) then
      lfsr := step(lfsr);
      if rMode = 1 or (rMode = 2 and lfsr(0) = '1') then
        readEnable <= '1';
      else
        readEnable <= '0';
      end if;
    end if;
  end process;

  -- Scoreboard: angenommene Schreibzugriffe
  sbWrite : process(wClk)
  begin
    if rising_edge(wClk) then
      if clr = '0' and writeEnable = '1' and isFull = '0' then
        assert tail - head < DEPTH
          report "FEHLER: Schreiben in vollen FIFO" severity failure;
        sb(tail mod 256) <= writeData;
        tail <= tail + 1;
      end if;
    end if;
  end process;

  -- Scoreboard: angenommene Lesezugriffe, Daten nach der Flanke pruefen
  sbRead : process
    variable exp : std_logic_vector(DW - 1 downto 0);
  begin
    wait until rising_edge(rClk);
    if clr = '0' and readEnable = '1' and isEmpty = '0' then
      assert tail - head > 0
        report "FEHLER: Lesen aus leerem FIFO" severity failure;
      exp  := sb(head mod 256);
      head <= head + 1;
      wait for 1 ns;
      assert readData = exp
        report "FEHLER: readData falsch" severity failure;
    end if;
  end process;

  stimulus : process
    variable n : integer;
  begin
    -- Reset (synchron in beiden Domains): ueber mehrere Takte halten
    for k in 1 to 4 loop
      wait until falling_edge(rClk);
    end loop;
    clr <= '0';
    wait for 1 ns;
    assert isEmpty = '1' and isFull = '0'
      report "FEHLER: Zustand nach clr" severity failure;

    -- 1. Fuellen
    wMode <= 1;
    n := 0;
    while isFull /= '1' and n < 100 loop
      wait until falling_edge(wClk);
      n := n + 1;
    end loop;
    wMode <= 0;
    for k in 1 to 3 loop
      wait until falling_edge(wClk);
    end loop;
    assert isFull = '1' and tail - head = DEPTH
      report "FEHLER: Fuellen, " & integer'image(tail - head) & " Worte" severity failure;
    report "ok: Fuellen: isFull bei genau " & integer'image(DEPTH) & " Worten" severity note;

    -- 2. Leeren
    rMode <= 1;
    n := 0;
    while isEmpty /= '1' and n < 300 loop
      wait until falling_edge(wClk);
      n := n + 1;
    end loop;
    rMode <= 0;
    for k in 1 to 10 loop
      wait until falling_edge(wClk);
    end loop;
    assert isEmpty = '1' and tail = head
      report "FEHLER: Leeren, " & integer'image(tail - head) & " Worte" severity failure;
    report "ok: Leeren: isEmpty, alle " & integer'image(tail) & " Worte gelesen" severity note;

    -- 3. Zufaelliges Schreiben und Lesen
    wMode <= 2;
    rMode <= 2;
    for k in 1 to 400 loop
      wait until falling_edge(wClk);
    end loop;
    report "ok: 400 Schreibtakte zufaellig, " & integer'image(tail) & " Worte geschrieben"
      severity note;

    -- 4. Leeren
    wMode <= 0;
    rMode <= 1;
    n := 0;
    while isEmpty /= '1' and n < 300 loop
      wait until falling_edge(wClk);
      n := n + 1;
    end loop;
    rMode <= 0;
    for k in 1 to 10 loop
      wait until falling_edge(wClk);
    end loop;
    assert isEmpty = '1' and tail = head
      report "FEHLER: Leeren am Ende, " & integer'image(tail - head) & " Worte" severity failure;
    report "ok: alle " & integer'image(tail) & " Worte in der richtigen Reihenfolge gelesen"
      severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
