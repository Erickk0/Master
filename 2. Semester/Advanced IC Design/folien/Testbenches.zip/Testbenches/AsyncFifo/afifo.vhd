-- Asynchroner FIFO (teil12.typ, Folien "Ein asynchroner FIFO" bis "(VI)").
-- Vollstaendige Fassung aus Material/aFifo.zip (Stand 2015), unveraendert
-- bis auf: library unisim entfernt (wird nicht benutzt, GHDL kennt sie
-- nicht), Kommentare ASCII, und "natural range" in der Arraygrenze von
-- fifo_t (VHDL-93 verlangt einen Typ fuer 2**aWidth - 1). Die Folien zeigen Ausschnitte; dort heisst clr
-- im Prozess except "clear".
--
-- References: Peter Alfke, Asynchronous FIFO in Virtex-II FPGAs, TechXclusives, 2001
--             http://www.asic-world.com/examples/vhdl/asyn_fifo.html
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity aFifo is

  generic (dWidth : integer := 8;   -- Width of data to be handled by the fifo
           aWidth : integer := 5);  -- Width of fifo addresses (#Items = 2**aWidth)

  port (clr : in std_logic;  -- Clear the Fifo and init state (== synchron reset)

        -- Read port of Fifo
        readData   : out std_logic_vector(dWidth - 1 downto 0);
        isEmpty    : out std_logic;     -- something can be read for the fifo
        readEnable : in  std_logic;     -- enable the write port
        rClk       : in  std_logic;     -- clock signal for the read domain

        -- Write port of Fifo
        writeData   : in  std_logic_vector(dWidth - 1 downto 0);
        isFull      : out std_logic;    -- something can be read from the fifo
        writeEnable : in  std_logic;    -- enable the read port
        wClk        : in  std_logic);   -- clock signal for the write domain

end aFifo;

architecture Behavioral of aFifo is

  -- Holds all data stored in the fifo
  type fifo_t is array (natural range 2**aWidth - 1 downto 0) of std_logic_vector(dWidth - 1 downto 0);
  signal memory : fifo_t;

  -- Store the possibilty of a future empty / full warning in a latch
  signal exCase : std_logic;

  -- Synchronous flags for full / empty state
  signal full  : std_logic;
  signal empty : std_logic;

  -- Asynchronous flags for empty / full state
  signal aFull  : std_logic;
  signal aEmpty : std_logic;

  -- Read / Write pointer to circular buffer
  signal readAdr  : std_logic_vector(aWidth - 1 downto 0);
  signal writeAdr : std_logic_vector(aWidth - 1 downto 0);

  -- Indicates that readAdr and writeAdr are equal (empty / full situation)
  signal equalAdr : std_logic;

  -- Enable signals for new read / write adress;
  signal nextWriteAdrEnable : std_logic;
  signal nextReadAdrEnable  : std_logic;

  -- Warnings for a empty / full situation in the next future
  signal emptyWarn : std_logic;
  signal fullWarn  : std_logic;

begin

  -- Write port logic
  writePort : process(wClk)
  begin

    -- This is synchron to the write domain
    if (rising_edge(wClk)) then

      -- Write access enabled and free entry available
      if ((writeEnable = '1') and (full = '0')) then

        -- Write to the fifo memory
        memory(to_integer(unsigned(writeAdr))) <= writeData;

      end if;

    end if;

  end process;

  -- Read port logic
  readPort : process(rClk)
  begin

    -- This is synchron to the read domain
    if (rising_edge(rClk)) then

      -- Read access enabled and some data a available
      if ((readEnable = '1') and (empty = '0')) then

        -- Read data for the fifo memory
        readData <= memory(to_integer(unsigned(readAdr)));

      end if;

    end if;

  end process;

  -- Check if readAdr and writeAdr are the same (empty / full situation)
  equalAdr <= '1' when (readAdr = writeAdr)
              else '0';

  -- Generate the enable signal for generating a new write address
  nextWriteAdrEnable <= not(full) and writeEnable;

  -- Gray counter for generating the write address
  writeCnt : entity work.GrayCnt(Native)
    generic map (width => aWidth)
    port map (clk    => wClk,
              reset  => clr,
              enable => nextWriteAdrEnable,
              gval   => writeAdr);

  -- Generate the enable signal for generating a new write address
  nextReadAdrEnable <= not(empty) and readEnable;

  -- Gray counter for generating the read address
  readCnt : entity work.GrayCnt(Native)
    generic map (width => aWidth)
    port map (clk    => rClk,
              reset  => clr,
              enable => nextReadAdrEnable,
              gval   => readAdr);

  -- Check if read pointer is one quadrant ahead the write pointer (full warning)
  fullWarn <= (writeAdr(writeAdr'high - 1) xnor readAdr(readAdr'high)) and
              (writeAdr(writeAdr'high) xor readAdr(readAdr'high - 1));

  -- Check if write pointer is one quadrant ahead the read pointer (empty warning)
  emptyWarn <= (writeAdr(writeAdr'high - 1) xor readAdr(readAdr'high)) and
               (writeAdr(writeAdr'high) xnor readAdr(readAdr'high - 1));


  -- Check possible exceptional cases (empty / full) in the
  -- near future and store them in a latch
  except : process(clr, emptyWarn, fullWarn)
  begin

    -- Check if the fifo should be cleared or we have an empty warning
    if ((clr = '1') or (emptyWarn = '1')) then

      -- Use a '0' to indicate a possible empty condition in the next future
      exCase <= '0';

    elsif (fullWarn = '1') then

      -- Use a '1' to indicate a possible full condition in the next future
      exCase <= '1';

    end if;

  end process;

  -- Generate asynchronous empty / full signals;
  aFull  <= exCase and equalAdr;
  aEmpty <= not exCase and equalAdr;

  -- Synchronize falling edge of asynchronous empty signal
  -- (the rising edge is already synchron)
  synchronize_empty : process (aEmpty, rClk)
  begin

    -- Check for empty state
    if(aEmpty = '1') then

      -- This happens synchronously, because aEmpty = '1' needs equalAdr = '1'
      empty <= '1';

    elsif (rising_edge(rClk)) then

      -- Fifo is not empty. Now the falling edge is synchronized too
      empty <= '0';

    end if;

  end process;

  -- Synchronize falling edge of asynchronous full signal
  -- (the rising edge is already synchron)
  synchronize_full : process (aFull, wClk)
  begin

    -- Check for full state
    if(aFull = '1') then

      -- This happens synchronously, because aFull = '1' needs equalAdr = '1'
      full <= '1';

    elsif (rising_edge(wClk)) then

      -- Fifo is not full. Now the falling edge is synchronized too
      full <= '0';

    end if;

  end process;

  -- Output the empty / full state
  isEmpty <= empty;
  isFull  <= full;

end Behavioral;
