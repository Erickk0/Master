// Selbstpruefende Testbench fuer afifo (dWidth = 8, aWidth = 5, 32 Worte).
// Schreibtakt 10 ns, Lesetakt 26 ns (zwei unabhaengige Clock-Domains).
// Referenzmodell: ein Scoreboard merkt sich jedes angenommene Wort
// (Schreiben bei writeEnable und isFull = 0) und vergleicht beim Lesen
// (readEnable und isEmpty = 0) das Wort an readData nach der Flanke.
// Geprueft wird ausserdem: nie mehr als 32 Worte, nie Lesen aus einem
// leeren FIFO.
//   1. Fuellen (nur schreiben): isFull kommt, dann sind genau 32 Worte drin.
//   2. Leeren (nur lesen): isEmpty kommt, dann ist das Scoreboard leer.
//   3. 400 Schreibtakte mit zufaelligem Schreiben und Lesen (LFSR).
//   4. Leeren; alle geschriebenen Worte wurden in der richtigen
//      Reihenfolge gelesen.
// Stimuli werden an der fallenden Flanke des jeweiligen Takts gesetzt.

module tb_afifo;

  localparam DW = 8, AW = 5, DEPTH = 1 << AW;

  reg            clr         = 1'b1;
  reg            wClk        = 1'b0;
  reg            rClk        = 1'b0;
  reg            writeEnable = 1'b0;
  reg            readEnable  = 1'b0;
  reg  [DW-1:0]  writeData   = 0;
  wire [DW-1:0]  readData;
  wire           isEmpty, isFull;

  // Verhalten der beiden Seiten: 0 = aus, 1 = immer, 2 = zufaellig
  integer        wMode = 0, rMode = 0;
  reg  [15 : 0]  lfsrW = 16'hACE1, lfsrR = 16'h1D2B;

  // Scoreboard
  reg  [DW-1:0]  sb [0 : 255];
  integer        head = 0, tail = 0, errors = 0, i;
  reg  [DW-1:0]  exp;

  afifo #(.dWidth(DW), .aWidth(AW)) dut (
    .clr(clr),
    .readData(readData), .isEmpty(isEmpty), .readEnable(readEnable), .rClk(rClk),
    .writeData(writeData), .isFull(isFull), .writeEnable(writeEnable), .wClk(wClk));

  always #5  wClk = ~wClk;
  always #13 rClk = ~rClk;

  // Schreibseite: neue Stimuli an der fallenden Flanke
  always @(negedge wClk) begin
    lfsrW <= {lfsrW[14 : 0], lfsrW[15] ^ lfsrW[13] ^ lfsrW[12] ^ lfsrW[10]};
    writeEnable <= (wMode == 1) || (wMode == 2 && lfsrW[0]);
    writeData   <= lfsrW[DW-1 : 0];
  end

  // Leseseite
  always @(negedge rClk) begin
    lfsrR <= {lfsrR[14 : 0], lfsrR[15] ^ lfsrR[13] ^ lfsrR[12] ^ lfsrR[10]};
    readEnable <= (rMode == 1) || (rMode == 2 && lfsrR[0]);
  end

  // Scoreboard: angenommene Schreibzugriffe
  always @(posedge wClk)
    if (!clr && writeEnable && !isFull) begin
      if (tail - head >= DEPTH) begin
        $display("FEHLER: t=%0t Schreiben in vollen FIFO", $time);
        errors = errors + 1;
      end
      sb[tail % 256] = writeData;
      tail = tail + 1;
    end

  // Scoreboard: angenommene Lesezugriffe, Daten nach der Flanke pruefen
  always @(posedge rClk)
    if (!clr && readEnable && !isEmpty) begin
      if (tail - head <= 0) begin
        $display("FEHLER: t=%0t Lesen aus leerem FIFO", $time);
        errors = errors + 1;
      end else begin
        exp  = sb[head % 256];
        head = head + 1;
        #1 if (readData !== exp) begin
          $display("FEHLER: t=%0t readData=%h erwartet=%h", $time, readData, exp);
          errors = errors + 1;
        end
      end
    end

  task wait_w(input integer n);
    repeat (n) @(negedge wClk);
  endtask

  initial begin
    $dumpfile("tb_afifo.vcd");            // laeuft im Verzeichnis build/
    $dumpvars(0, tb_afifo);

    // Reset (synchron in beiden Domains): ueber mehrere Takte halten
    repeat (4) @(negedge rClk);
    clr = 1'b0;
    if (isEmpty !== 1'b1 || isFull !== 1'b0) begin
      $display("FEHLER: nach clr isEmpty=%b isFull=%b", isEmpty, isFull);
      errors = errors + 1;
    end

    // 1. Fuellen
    wMode = 1; rMode = 0;
    i = 0;
    while (isFull !== 1'b1 && i < 100) begin wait_w(1); i = i + 1; end
    wMode = 0;
    wait_w(3);
    if (isFull !== 1'b1 || tail - head != DEPTH) begin
      $display("FEHLER: Fuellen, isFull=%b, %0d Worte", isFull, tail - head);
      errors = errors + 1;
    end else
      $display("ok     Fuellen: isFull bei genau %0d Worten", DEPTH);

    // 2. Leeren
    rMode = 1;
    i = 0;
    while (isEmpty !== 1'b1 && i < 300) begin wait_w(1); i = i + 1; end
    rMode = 0;
    wait_w(10);
    if (isEmpty !== 1'b1 || tail != head) begin
      $display("FEHLER: Leeren, isEmpty=%b, %0d Worte", isEmpty, tail - head);
      errors = errors + 1;
    end else
      $display("ok     Leeren: isEmpty, alle %0d Worte gelesen", tail);

    // 3. Zufaelliges Schreiben und Lesen
    wMode = 2; rMode = 2;
    wait_w(400);
    $display("ok     400 Schreibtakte zufaellig, %0d Worte geschrieben", tail);

    // 4. Leeren
    wMode = 0; rMode = 1;
    i = 0;
    while (isEmpty !== 1'b1 && i < 300) begin wait_w(1); i = i + 1; end
    rMode = 0;
    wait_w(10);
    if (isEmpty !== 1'b1 || tail != head) begin
      $display("FEHLER: Leeren am Ende, isEmpty=%b, %0d Worte", isEmpty, tail - head);
      errors = errors + 1;
    end else
      $display("ok     alle %0d Worte in der richtigen Reihenfolge gelesen", tail);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
