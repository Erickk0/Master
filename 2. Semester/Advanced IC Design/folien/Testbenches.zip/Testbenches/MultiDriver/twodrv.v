// Versehentlich zwei Treiber fuer y. Mit wire uebersetzen Icarus und
// auch Verilator ohne Meldung. Die Simulation zeigt X, sobald sich die
// beiden Treiber widersprechen (a != b).
module twodrv
  (input  wire a,
   input  wire b,
   output wire y);

  assign y = a & b;
  assign y = a | b; // Fehler: zweiter Treiber

endmodule
