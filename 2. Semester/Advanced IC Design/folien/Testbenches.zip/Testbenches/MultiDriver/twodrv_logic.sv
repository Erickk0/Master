// Wie twodrv.v, aber mit logic. Icarus bricht mit einem Fehler ab,
// und auch Verilator meldet den zweiten Treiber (Warnung).
module twodrv
  (input  logic a,
   input  logic b,
   output logic y);

  assign y = a & b;
  assign y = a | b; // Fehler: zweiter Treiber

endmodule
