module tb_twodrv;
  reg  a = 1'b0, b = 1'b0;
  wire y;

  twodrv dut (.a(a), .b(b), .y(y));

  initial begin
    $dumpfile("tb_twodrv.vcd");
    $dumpvars(0, tb_twodrv);
    #10 a = 1'b1; b = 1'b1;
    #10 a = 1'b0; b = 1'b0;
    #10 a = 1'b1;
    #10 a = 1'b0; b = 1'b1;
    #10 a = 1'b1;
    #10 $finish;
  end

  always @(a, b, y) $display("t=%0t a=%b b=%b y=%b", $time, a, b, y);
endmodule
