-- Selbstpruefende Testbench fuer edgeDetect(mealy) (VHDL-93):
--   Referenzmodell: d1 = Wert von data an der letzten steigenden Flanke
--   (0 nach Reset). Der Mealy-Automat liefert tick = data and not d1, also
--   kombinatorisch und damit nicht taktsynchron.
--   1. 300 zufaellige Wechsel von data zu beliebigen Zeitpunkten (nie genau
--      auf der steigenden Flanke); tick wird nach jedem Wechsel und an der
--      fallenden Flanke geprueft.
--   2. Ein kurzer Puls von data zwischen zwei Flanken (Glitch) erscheint
--      auch an tick.
--   3. Asynchroner Reset mitten im Takt.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_edgeDetect is
end tb_edgeDetect;

architecture Test of tb_edgeDetect is
  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal data  : std_logic := '0';
  signal tick  : std_logic;
  signal d1    : std_logic := '0'; -- Referenzmodell
  signal done  : boolean := false;
begin
  dut : entity work.edgeDetect(mealy)
    port map (clk => clk, reset => reset, data => data, tick => tick);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  model : process(clk, reset)
  begin
    if reset = '1' then
      d1 <= '0';
    elsif rising_edge(clk) then
      d1 <= data;
    end if;
  end process;

  stimulus : process
    variable lfsr : std_logic_vector(15 downto 0) := x"ACE1";
    variable d    : integer;
    variable seen : std_logic;
  begin
    wait until falling_edge(clk);
    reset <= '0';

    -- 1. Zufaellige Wechsel
    for i in 1 to 300 loop
      d := 1 + to_integer(unsigned(lfsr(2 downto 0))); -- 1..8 ns nach der
      if d = 5 then                                    -- fallenden Flanke, nie
        d := 4;                                        -- genau auf der steigenden
      end if;
      wait for d * 1 ns;
      if lfsr(3) = '1' then
        data <= not data;
      end if;
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      wait for 500 ps;
      assert tick = (data and not d1)
        report "FEHLER nach Wechsel, Schritt " & integer'image(i) severity failure;
      wait until falling_edge(clk);
      assert tick = (data and not d1)
        report "FEHLER an fallender Flanke, Schritt " & integer'image(i) severity failure;
    end loop;
    report "ok: 300 zufaellige Wechsel, tick = data and not d1" severity note;

    -- 2. Glitch zwischen zwei Flanken
    data <= '0';
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    wait for 1 ns;
    data <= '1';
    wait for 1 ns;
    seen := tick;
    wait for 1 ns;
    data <= '0';
    assert seen = '1' report "FEHLER: Glitch erscheint nicht an tick" severity failure;
    report "ok: Glitch zwischen zwei Flanken erscheint an tick" severity note;

    -- 3. Reset mitten im Takt
    data <= '1';
    wait until falling_edge(clk);
    wait for 2 ns;
    reset <= '1';
    wait for 1 ns;
    assert tick = '1' report "FEHLER: nach Reset mit data = 1 muss tick = 1 sein"
      severity failure;
    report "ok: Reset mitten im Takt wirkt sofort" severity note;
    wait until falling_edge(clk);
    reset <= '0';

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
