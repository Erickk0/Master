// Selbstpruefende Testbench fuer edgedetect_mealy:
//   Referenzmodell: d1 = Wert von data an der letzten steigenden Flanke
//   (0 nach Reset). Der Mealy-Automat liefert tick = data & ~d1, also
//   kombinatorisch und damit nicht taktsynchron.
//   1. 300 zufaellige Wechsel von data zu beliebigen Zeitpunkten (nie genau
//      auf der steigenden Flanke); tick wird nach jedem Wechsel und an der
//      fallenden Flanke geprueft.
//   2. Ein kurzer Puls von data zwischen zwei Flanken (Glitch) erscheint
//      auch an tick (siehe Folie "Timing Diagramm des Mealy-Automaten").
//   3. Asynchroner Reset mitten im Takt.

module tb_edgedetect_mealy;

  reg     clk   = 1'b0;
  reg     reset = 1'b1;
  reg     data  = 1'b0;
  wire    tick;
  reg     d1    = 1'b0;           // Referenzmodell
  reg     [15 : 0] lfsr = 16'hACE1;
  reg     seen;
  integer i, d, errors = 0;

  edgedetect_mealy dut (.clk(clk), .reset(reset), .data(data), .tick(tick));

  always #5 clk = ~clk;

  always @(posedge clk or posedge reset)
    if (reset) d1 <= 1'b0;
    else       d1 <= data;

  task check(input [8*24 : 1] what);
    if (tick !== (data & ~d1)) begin
      $display("FEHLER (%0s): t=%0t  data=%b d1=%b tick=%b", what, $time, data, d1, tick);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_edgedetect_mealy.vcd"); // laeuft im Verzeichnis build/
    $dumpvars(0, tb_edgedetect_mealy);

    @(negedge clk);
    reset = 1'b0;

    // 1. Zufaellige Wechsel
    for (i = 0; i < 300; i = i + 1) begin
      d = 1 + lfsr[2 : 0];                // 1..8 ns nach der fallenden Flanke,
      if (d == 5) d = 4;                  // nie genau auf der steigenden Flanke
      #(d);
      if (lfsr[3]) data = ~data;
      lfsr = {lfsr[14 : 0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      #0.5 check("nach Wechsel");
      @(negedge clk);
      check("fallende Flanke");
    end
    $display("ok     300 zufaellige Wechsel, tick = data & ~d1");

    // 2. Glitch zwischen zwei Flanken
    data = 1'b0;
    repeat (2) @(negedge clk);            // d1 = 0
    #1 data = 1'b1;                       // 1 ns nach der fallenden Flanke
    #1 seen = tick;
    #1 data = 1'b0;                       // vor der steigenden Flanke wieder 0
    if (seen !== 1'b1) begin
      $display("FEHLER: Glitch erscheint nicht an tick");
      errors = errors + 1;
    end else
      $display("ok     Glitch zwischen zwei Flanken erscheint an tick");

    // 3. Reset mitten im Takt
    data = 1'b1;
    @(negedge clk);                       // d1 = 1, tick = 0
    #2 reset = 1'b1;                      // Zustand sofort LOW
    #1 check("Reset");
    if (tick !== 1'b1) begin
      $display("FEHLER: nach Reset mit data = 1 muss tick = 1 sein");
      errors = errors + 1;
    end else
      $display("ok     Reset mitten im Takt wirkt sofort");
    @(negedge clk);
    reset = 1'b0;

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
