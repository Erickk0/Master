// Flankenerkennung als Mealy-Automat, Verilog-Fassung (teil7.typ, Folien
// "Beispiel: Mealy - Automaten" und die beiden Folien "(II)").
module edgedetect_mealy
  (input  wire clk,
   input  wire reset,
   input  wire data,
   output reg  tick);

  localparam LOW = 1'b0, HIGH = 1'b1;

  reg state, stateN;

  always @(posedge clk or posedge reset) begin
    if (reset)
      state <= LOW;
    else
      state <= stateN;
  end

  // next-state / output logic
  always @(*) begin
    // Set default values
    stateN = state;
    tick   = 1'b0;

    case (state)

      // Handle state LOW
      LOW:
        if (data) begin
          stateN = HIGH;
          tick   = 1'b1;
        end

      // Handle state HIGH
      HIGH:
        if (!data)
          stateN = LOW;

    endcase
  end

endmodule
