-- Flankenerkennung als Mealy-Automat (teil7.typ, Folien "Beispiel: Mealy -
-- Automaten" und die beiden Folien "(II)").
library ieee;
use ieee.std_logic_1164.all;

entity edgeDetect is
  port (clk   : in  std_logic;
        reset : in  std_logic;
        data  : in  std_logic;
        tick  : out std_logic);
end edgeDetect;

architecture mealy of edgeDetect is
  type state_t is (low, high);
  signal state_reg  : state_t;
  signal state_next : state_t;
begin

transition : process (clk, reset)
begin
  if (reset = '1') then
    state_reg <= low;
  elsif (rising_edge(clk)) then
    state_reg <= state_next;
  end if;
end process;

-- next-state / output logic
next_state_proc : process(state_reg, data)
begin
  -- Set default values
  state_next <= state_reg;
  tick <= '0';

  case state_reg is

    -- Handle state 'low'
    when low =>
      if (data = '1') then
        state_next <= high;
        tick <= '1';
      end if;

    -- Handle state 'high'
    when high =>
      if (data = '0') then
        state_next <= low;
      end if;

  end case;

end process;
end architecture;
