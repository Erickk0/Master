// Selbstpruefende Testbench fuer lights:
//   1. Asynchroner Reset: leds = 10000000 sofort, ohne Taktflanke.
//   2. 20 Takte: das Licht wandert mit jeder steigenden Flanke eine
//      Stelle nach rechts und beginnt nach 00000001 wieder links.
//   3. Reset mitten im Takt setzt das Licht sofort zurueck.
// Geprueft wird an der fallenden Flanke.

module tb_lights;

  reg          clk   = 1'b0;
  reg          reset = 1'b1;
  wire [7 : 0] leds;
  reg  [7 : 0] exp;
  integer      i, errors = 0;

  lights dut (.clk(clk), .reset(reset), .leds(leds));

  always #5 clk = ~clk;

  task check(input [8*24 : 1] what);
    if (leds !== exp) begin
      $display("FEHLER (%0s): t=%0t  leds=%b  erwartet=%b", what, $time, leds, exp);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_lights.vcd");           // laeuft im Verzeichnis build/
    $dumpvars(0, tb_lights);

    // 1. Asynchroner Reset
    #2 exp = 8'b10000000;
    check("Reset");
    @(negedge clk);
    reset = 1'b0;
    $display("ok     asynchroner Reset");

    // 2. Lauflicht
    for (i = 0; i < 20; i = i + 1) begin
      @(negedge clk);
      exp = {exp[0], exp[7 : 1]};         // eine Stelle nach rechts
      check("Lauflicht");
    end
    $display("ok     20 Takte, Licht wandert und beginnt wieder links");

    // 3. Reset mitten im Takt
    #2 reset = 1'b1;
    #1 exp = 8'b10000000;
    check("Reset im Betrieb");
    @(negedge clk);
    reset = 1'b0;
    $display("ok     Reset mitten im Takt wirkt sofort");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
