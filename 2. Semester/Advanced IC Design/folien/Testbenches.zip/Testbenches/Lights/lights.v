// Lauflicht als Moore-Automat, Verilog-Fassung (teil7.typ, Folien "Das
// Lauflicht in Verilog" und "(II)"). Die Folien zeigen nur die Zustaende
// Q0 und Q1, hier sind alle acht ausgeschrieben.
module lights
  (input  wire       clk,
   input  wire       reset,
   output reg  [7:0] leds);

  localparam [2:0] Q0 = 3'd0, Q1 = 3'd1, Q2 = 3'd2, Q3 = 3'd3,
                   Q4 = 3'd4, Q5 = 3'd5, Q6 = 3'd6, Q7 = 3'd7;

  reg [2:0] state, stateN;

  always @(posedge clk or posedge reset) begin
    if (reset)
      state <= Q0;      // set initial state
    else                // changes on rising edge
      state <= stateN;
  end

  always @(*) begin
    case (state)

      Q0: begin
        leds   = 8'b10000000; // Moore Ausgabe
        stateN = Q1;
      end

      Q1: begin
        leds   = 8'b01000000; // Moore Ausgabe
        stateN = Q2;
      end

      Q2: begin
        leds   = 8'b00100000; // Moore Ausgabe
        stateN = Q3;
      end

      Q3: begin
        leds   = 8'b00010000; // Moore Ausgabe
        stateN = Q4;
      end

      Q4: begin
        leds   = 8'b00001000; // Moore Ausgabe
        stateN = Q5;
      end

      Q5: begin
        leds   = 8'b00000100; // Moore Ausgabe
        stateN = Q6;
      end

      Q6: begin
        leds   = 8'b00000010; // Moore Ausgabe
        stateN = Q7;
      end

      Q7: begin
        leds   = 8'b00000001; // Moore Ausgabe
        stateN = Q0;
      end

    endcase
  end

endmodule
