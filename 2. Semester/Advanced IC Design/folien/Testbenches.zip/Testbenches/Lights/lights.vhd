-- Lauflicht als Moore-Automat (teil7.typ, Folien "Das Lauflicht in VHDL"
-- und "(II)"). Die Folien zeigen nur die Zustaende q0 und q1, hier sind
-- alle acht ausgeschrieben.
library ieee;
use ieee.std_logic_1164.all;

entity lights is
   port (clk, reset : in std_logic;
         leds       : out std_logic_vector(7 downto 0));
end lights;

architecture Behavioral of lights is

type state_t is (q0, q1, q2, q3, q4, q5, q6, q7);
signal state_reg, state_next : state_t;

begin
  transition : process (clk, reset)
  begin
    if (reset = '1') then
      state_reg <= q0; -- set initial state
    elsif (rising_edge(clk)) then -- changes on rising edge
      state_reg <= state_next;
    end if;
  end process;

  next_state_proc : process (state_reg)
  begin
    case state_reg is

      when q0 =>
        leds <= "10000000"; -- Moore Ausgabe
        state_next <= q1;

      when q1 =>
        leds <= "01000000"; -- Moore Ausgabe
        state_next <= q2;

      when q2 =>
        leds <= "00100000"; -- Moore Ausgabe
        state_next <= q3;

      when q3 =>
        leds <= "00010000"; -- Moore Ausgabe
        state_next <= q4;

      when q4 =>
        leds <= "00001000"; -- Moore Ausgabe
        state_next <= q5;

      when q5 =>
        leds <= "00000100"; -- Moore Ausgabe
        state_next <= q6;

      when q6 =>
        leds <= "00000010"; -- Moore Ausgabe
        state_next <= q7;

      when q7 =>
        leds <= "00000001"; -- Moore Ausgabe
        state_next <= q0;

    end case;
  end process;
end Behavioral;
