-- Selbstpruefende Testbench fuer lights (VHDL-93):
--   1. Asynchroner Reset: leds = 10000000 sofort, ohne Taktflanke.
--   2. 20 Takte: das Licht wandert mit jeder steigenden Flanke eine
--      Stelle nach rechts und beginnt nach 00000001 wieder links.
--   3. Reset mitten im Takt setzt das Licht sofort zurueck.
-- Geprueft wird an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;

entity tb_lights is
end tb_lights;

architecture Test of tb_lights is
  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal leds  : std_logic_vector(7 downto 0);
  signal done  : boolean := false;
begin
  dut : entity work.lights
    port map (clk => clk, reset => reset, leds => leds);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable exp : std_logic_vector(7 downto 0);
  begin
    -- 1. Asynchroner Reset
    wait for 2 ns;
    exp := "10000000";
    assert leds = exp report "FEHLER: nach Reset" severity failure;
    wait until falling_edge(clk);
    reset <= '0';
    report "ok: asynchroner Reset" severity note;

    -- 2. Lauflicht
    for i in 1 to 20 loop
      wait until falling_edge(clk);
      exp := exp(0) & exp(7 downto 1);   -- eine Stelle nach rechts
      assert leds = exp
        report "FEHLER im Lauflicht, Takt " & integer'image(i)
        severity failure;
    end loop;
    report "ok: 20 Takte, Licht wandert und beginnt wieder links" severity note;

    -- 3. Reset mitten im Takt
    wait for 2 ns;
    reset <= '1';
    wait for 1 ns;
    assert leds = "10000000" report "FEHLER: Reset im Betrieb" severity failure;
    wait until falling_edge(clk);
    reset <= '0';
    report "ok: Reset mitten im Takt wirkt sofort" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
