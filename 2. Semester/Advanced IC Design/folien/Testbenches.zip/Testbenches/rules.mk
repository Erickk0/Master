# Gemeinsame Regeln für die Tests der Basisschaltkreise.
#
# Ein Schaltkreis-Makefile setzt die folgenden Variablen und bindet danach
# diese Datei ein (include ../rules.mk):
#
#   V_TOP    Verilog-Topmodul
#   V_SRC    Verilog-Quelle(n). Mehrere Dateien sind Varianten desselben
#            Moduls V_TOP (z.B. assign und casez); jede Variante wird einzeln
#            gelintet, synthetisiert, simuliert und mit VHDL verglichen.
#   V_TB     Verilog-Testbench (Modul tb_$(V_TOP), Ausgabe "PASS"/"FAIL",
#            schreibt die Wellenform nach tb_$(V_TOP).vcd)
#   V_SUB    zusaetzliche Verilog-Module (z.B. ../GrayCntNative/graycnt_native.v),
#            die bei Lint, Synthese, Simulation und Aequivalenzpruefung
#            jeder Variante mitgelesen werden (optional)
#   VHD_TOP  VHDL-Top-Entity, Schreibweise wie im Quelltext (das GHDL-Plugin
#            behält sie als Yosys-Modulnamen bei)
#   VHD_SRC  VHDL-Quellen
#   VHD_TB   VHDL-Testbench (Entity tb_$(VHD_TOP), Fehler per severity failure)
#   VHD_LIBS zusätzliche VHDL-Bibliotheken als bibliothek:datei, z.B.
#            cpu:cputypes.vhd für "library cpu; use cpu.CPUTypes.all;"
#            (optional, werden vor VHD_SRC übersetzt)
#   COMB     1 = rein kombinatorisch: Latch-Test verbietet auch Flip-Flops
#   LATCH_OK 1 = gewollte Latches erlauben (z.B. exCase im asynchronen FIFO);
#            der Latch-Test prueft dann nichts mehr, ghdl --synth bekommt
#            --latches. Standard 0
#   EQUIV    0 = make all ohne Äquivalenzprüfung (z.B. wenn VHDL- und
#            Verilog-Fassung absichtlich verschieden sind), Standard 1
#            Flip-Flops mit asynchronem Reset wandelt die Pruefung mit
#            async2sync in synchrone Logik um (equiv_simple/equiv_induct
#            koennen $adff nicht direkt beweisen).
#            proc -norom verhindert, dass Yosys einen case mit konstanten
#            Ausgaben in ein ROM ($mem) umwandelt; damit kaeme async2sync
#            nicht zurecht.
#   EQUIV_RENAME  Verilog-Register fuer die Aequivalenzpruefung umbenennen,
#            als verilog:vhdl, z.B. hBit:hbit_reg val:val_reg. equiv_make
#            ordnet Register nur ueber gleiche Namen zu (GHDL schreibt sie
#            klein); ohne Zuordnung scheitert die Induktion an Zustand, der
#            nicht direkt am Ausgang sichtbar ist (optional)
#   EQUIV_GOLD  zusaetzliche Yosys-Befehle auf der VHDL-Seite (Modul gold)
#            vor equiv_make, z.B. Hilfsdraehte fuer Register, die in VHDL
#            ein Array und in Verilog einzelne Register sind (optional)
#   EQUIV_V  1 = make all vergleicht zusätzlich jede weitere Verilog-Variante
#            formal mit der ersten Datei in V_SRC (z.B. debounce_logic.sv
#            mit debounce.v), Standard 0
#
# Dateien mit der Endung .sv werden als SystemVerilog gelesen (Icarus
# -g2012, Yosys read_verilog -sv). Der Variantenname ist der Dateiname ohne
# Endung, er muss daher auch über .v und .sv hinweg eindeutig sein.
#
# Ziele: lint, latch, sim, equiv, equiv-v, all (Standard), clean
#        show      Schaltbilder auf Gatterebene nach synth
#        show-rtl  Schaltbilder auf RTL-Ebene nach proc
#        Format über SHOW_FORMAT (svg, png, pdf), z.B. make show SHOW_FORMAT=png
# Jeweils auch nur für eine Sprache: lint-v, lint-vhd, latch-v, ...
# und für eine Verilog-Variante <v> (Dateiname ohne .v): lint-v-<v>,
# latch-v-<v>, sim-v-<v>, equiv-<v>, show-v-<v>, show-rtl-v-<v>

# OSS CAD Suite. Nicht interaktive Shells (make) haben sie nicht im PATH,
# daher absolute Pfade; der PATH-Export gilt für die Hilfsprogramme der Tools.
OSS_CAD  ?= /usr/local/oss-cad-suite
export PATH := $(OSS_CAD)/bin:$(PATH)

VERILATOR ?= $(OSS_CAD)/bin/verilator
IVERILOG  ?= $(OSS_CAD)/bin/iverilog
VVP       ?= $(OSS_CAD)/bin/vvp
YOSYS     ?= $(OSS_CAD)/bin/yosys
GHDL      ?= $(OSS_CAD)/bin/ghdl
GHDL_STD  ?= --std=93

# Varianten (z.B. prienc_casez.v) enthalten dasselbe Modul wie die
# Hauptdatei, der Dateiname passt dann nicht zum Modulnamen.
VERILATOR_WAIVE ?= -Wno-DECLFILENAME

BUILD := build
COMB  ?= 1

# Speicherelemente, die der Latch-Test verbietet. Bei sequentiellen
# Schaltungen (COMB=0) sind Flip-Flops erlaubt, Latches nie.
LATCH_OK ?= 0
ifeq ($(COMB),1)
FORBIDDEN := t:\$$dlatch t:\$$adlatch t:\$$dlatchsr t:\$$*dff* t:\$$sr
else ifeq ($(LATCH_OK),1)
FORBIDDEN :=
else
FORBIDDEN := t:\$$dlatch t:\$$adlatch t:\$$dlatchsr
endif
GHDL_SYNTH_FLAGS := $(if $(filter 1,$(LATCH_OK)),--latches)

HAVE_V   := $(if $(V_TOP),1)
HAVE_VHD := $(if $(VHD_TOP),1)
V_NAMES  := $(basename $(notdir $(V_SRC)))
V_REF    := $(firstword $(V_SRC))
V_ALT    := $(wordlist 2,$(words $(V_SRC)),$(V_SRC))

# Verilog oder SystemVerilog, je nach Endung: $(1) = Quelldatei
v_read   = read_verilog $(if $(filter %.sv,$(1)),-sv )$(1)
v_gen    = $(if $(filter %.sv,$(1)),-g2012,-g2005)

# Zusaetzliche Verilog-Module (V_SUB) fuer Yosys. Fuer die
# Aequivalenzpruefung wird jede Seite fuer sich mit hierarchy -top aufgeloest
# und flachgeklopft, bevor das Topmodul umbenannt wird; so funktionieren auch
# rekursive Instanzen (z.B. prienc_gen in PriEncGen).
V_READ_SUB = $(foreach f,$(V_SUB),$(call v_read,$(f));)

# Yosys-Befehle zum Umbenennen der Verilog-Register (siehe EQUIV_RENAME)
EQUIV_REN = $(if $(EQUIV_RENAME),cd gate; $(foreach r,$(EQUIV_RENAME),rename $(subst :, ,$(r));) cd ..;) \
            $(if $(EQUIV_GOLD),cd gold; $(EQUIV_GOLD) cd ..;)

.PHONY: all lint latch sim equiv equiv-v show show-rtl clean \
        lint-v lint-vhd latch-v latch-vhd sim-v sim-vhd \
        show-v show-vhd show-rtl-v show-rtl-vhd \
        $(foreach n,$(V_NAMES),lint-v-$(n) latch-v-$(n) sim-v-$(n) equiv-$(n) \
                               equiv-v-$(n) show-v-$(n) show-rtl-v-$(n))

EQUIV   ?= 1
EQUIV_V ?= 0

all: lint latch sim $(if $(and $(HAVE_V),$(HAVE_VHD),$(filter 1,$(EQUIV))),equiv) \
     $(if $(and $(V_ALT),$(filter 1,$(EQUIV_V))),equiv-v)

lint:  $(if $(HAVE_V),lint-v)  $(if $(HAVE_VHD),lint-vhd)
latch: $(if $(HAVE_V),latch-v) $(if $(HAVE_VHD),latch-vhd)
sim:   $(if $(HAVE_V),sim-v)   $(if $(HAVE_VHD),sim-vhd)

lint-v:  $(addprefix lint-v-,$(V_NAMES))
latch-v: $(addprefix latch-v-,$(V_NAMES))
sim-v:   $(addprefix sim-v-,$(V_NAMES))
equiv:   $(addprefix equiv-,$(V_NAMES))
equiv-v: $(addprefix equiv-v-,$(basename $(notdir $(V_ALT))))

show:       $(if $(HAVE_V),show-v)     $(if $(HAVE_VHD),show-vhd)
show-rtl:   $(if $(HAVE_V),show-rtl-v) $(if $(HAVE_VHD),show-rtl-vhd)
show-v:     $(addprefix show-v-,$(V_NAMES))
show-rtl-v: $(addprefix show-rtl-v-,$(V_NAMES))

$(BUILD):
	@mkdir -p $@

# proc ohne Optimierung: so sieht man genau die Speicherelemente, die der
# Code beschreibt. select -assert-none bricht bei einem Treffer ab.
# $(1) = Topmodul, $(2) = Name für die Statistikdatei
YOSYS_LATCH = proc; opt_clean; \
  $(if $(strip $(FORBIDDEN)),select -assert-none $(FORBIDDEN);) \
  synth -top $(1); check -assert; \
  $(if $(strip $(FORBIDDEN)),select -assert-none $(FORBIDDEN);) \
  tee -o $(BUILD)/$(2)_stat.txt stat

# Schaltbilder mit Yosys show (ruft dot aus der Suite auf, siehe PATH).
# RTL: direkt nach proc, zeigt die Struktur des Codes (Muxe, Vergleicher).
# Gatter: nach synth und Aufräumen, zeigt die erzeugte Logik.
# $(1) = Topmodul, $(2) = Name der Beschreibung (Dateiname des Bildes)
SHOW_FORMAT ?= svg
SHOW_OPTS    = -format $(SHOW_FORMAT) -notitle -width
YOSYS_RTL   = proc; opt_clean; \
  show $(SHOW_OPTS) -prefix $(BUILD)/$(2)_rtl
YOSYS_GATES = synth -flatten -top $(1); opt_clean -purge; \
  show $(SHOW_OPTS) -prefix $(BUILD)/$(2)_gates

# ---------------------------------------------------------------- VHDL
# ghdl --synth übersetzt die VHDL-Quellen in eine Verilog-Netzliste, die
# Yosys dann einliest. GHDL verweigert Latches schon hier ("latch infered
# for net ... (use --latches)"), der Test schlägt dann beim Übersetzen fehl.
# Das GHDL-Plugin für Yosys (yosys -m ghdl) wäre direkter, stürzt in der
# Suite 20271107 aber bei jedem Flip-Flop ab (ASSERTION_ERROR netlists.adb).
VHD_NET  := $(BUILD)/$(VHD_TOP)_vhd.v
READ_VHD  = read_verilog $(VHD_NET)

# Zusätzliche Bibliotheken (VHD_LIBS) landen ebenfalls in build/, -P$(BUILD)
# macht sie für alle weiteren GHDL-Aufrufe sichtbar.
lib_name = $(word 1,$(subst :, ,$(1)))
lib_file = $(word 2,$(subst :, ,$(1)))
VHD_LIB_STAMP := $(if $(VHD_LIBS),$(BUILD)/vhd_libs.stamp)
GHDL_LIBS     := -P$(BUILD)

$(BUILD)/vhd_libs.stamp: $(foreach l,$(VHD_LIBS),$(call lib_file,$(l))) | $(BUILD)
	$(foreach l,$(VHD_LIBS),$(GHDL) -a $(GHDL_STD) --workdir=$(BUILD) \
	  --work=$(call lib_name,$(l)) $(call lib_file,$(l)) &&) true
	@touch $@

$(VHD_NET): $(VHD_SRC) $(VHD_LIB_STAMP) | $(BUILD)
	$(GHDL) --synth $(GHDL_STD) --workdir=$(BUILD) $(GHDL_LIBS) $(GHDL_SYNTH_FLAGS) --out=verilog \
	  $(VHD_SRC) -e $(VHD_TOP) > $@ || { rm -f $@; exit 1; }

lint-vhd: $(VHD_LIB_STAMP) | $(BUILD)
	@echo "== Lint (GHDL): $(VHD_SRC)"
	$(GHDL) -a $(GHDL_STD) --workdir=$(BUILD) $(GHDL_LIBS) -Wall $(VHD_SRC)
	@echo "   ok"

latch-vhd: $(VHD_NET)
	@echo "== Latch-Test (GHDL --synth + Yosys): $(VHD_TOP)"
	$(YOSYS) -q -l $(BUILD)/latch_vhd.log \
	  -p "$(READ_VHD); $(call YOSYS_LATCH,$(VHD_TOP),vhd)"
	@echo "   ok, keine verbotenen Speicherelemente (Statistik: $(BUILD)/vhd_stat.txt)"

sim-vhd: $(VHD_LIB_STAMP) | $(BUILD)
	@echo "== Simulation (GHDL): tb_$(VHD_TOP)"
	$(GHDL) -a $(GHDL_STD) --workdir=$(BUILD) $(GHDL_LIBS) $(VHD_SRC) $(VHD_TB)
	$(GHDL) -e $(GHDL_STD) --workdir=$(BUILD) $(GHDL_LIBS) -o $(BUILD)/tb_$(VHD_TOP) tb_$(VHD_TOP)
	$(BUILD)/tb_$(VHD_TOP) --vcd=$(BUILD)/tb_$(VHD_TOP)_vhd.vcd --assert-level=error
	@echo "   Wellenform: $(BUILD)/tb_$(VHD_TOP)_vhd.vcd"

show-vhd: $(VHD_NET)
	@echo "== Schaltbild Gatter (Yosys show): $(VHD_SRC)"
	$(YOSYS) -q -p "$(READ_VHD); $(call YOSYS_GATES,$(VHD_TOP),vhd)"
	@echo "   $(BUILD)/vhd_gates.$(SHOW_FORMAT)"

show-rtl-vhd: $(VHD_NET)
	@echo "== Schaltbild RTL (Yosys show): $(VHD_SRC)"
	$(YOSYS) -q -p "$(READ_VHD); $(call YOSYS_RTL,$(VHD_TOP),vhd)"
	@echo "   $(BUILD)/vhd_rtl.$(SHOW_FORMAT)"

# ---------------------------------------------------------------- Verilog
# Regeln je Variante: $(1) = Quelldatei, $(2) = Name der Variante.
# Innerhalb von define/eval werden globale Variablen mit $$ referenziert,
# damit sie erst beim Ausführen expandiert werden.
define V_RULES
lint-v-$(2):
	@echo "== Lint (Verilator): $(1)"
	$$(VERILATOR) --lint-only -Wall $$(VERILATOR_WAIVE) --top-module $$(V_TOP) $$(V_SUB) $(1)
	@echo "   ok"

latch-v-$(2): | $$(BUILD)
	@echo "== Latch-Test (Yosys): $(1)"
	$$(YOSYS) -q -l $$(BUILD)/latch_$(2).log \
	  -p "$$(V_READ_SUB) $$(call v_read,$(1)); $$(call YOSYS_LATCH,$$(V_TOP),$(2))"
	@echo "   ok, keine verbotenen Speicherelemente (Statistik: $$(BUILD)/$(2)_stat.txt)"

sim-v-$(2): | $$(BUILD)
	@echo "== Simulation (Icarus Verilog): tb_$$(V_TOP) mit $(1)"
	$$(IVERILOG) $$(call v_gen,$(1)) -Wall -o $$(BUILD)/tb_$(2).vvp $$(V_TB) $$(V_SUB) $(1)
	cd $$(BUILD) && $$(VVP) -n tb_$(2).vvp | tee sim_$(2).log
	$$(if $$(filter $(2),$$(V_TOP)),,@mv -f $$(BUILD)/tb_$$(V_TOP).vcd $$(BUILD)/tb_$(2).vcd)
	@grep -q '^PASS' $$(BUILD)/sim_$(2).log
	@echo "   Wellenform: $$(BUILD)/tb_$(2).vcd"

# Formaler Vergleich: VHDL- und Verilog-Fassung beschreiben dieselbe Funktion.
equiv-$(2): $$(VHD_NET)
	@echo "== Äquivalenz VHDL <-> Verilog (Yosys equiv): $(1)"
	$$(YOSYS) -q -l $$(BUILD)/equiv_$(2).log -p " \
	  $$(READ_VHD); hierarchy -top $$(VHD_TOP); \
	  proc -norom; flatten; rename $$(VHD_TOP) gold; design -stash vhd; \
	  $$(V_READ_SUB) $$(call v_read,$(1)); hierarchy -top $$(V_TOP); \
	  proc -norom; flatten; rename $$(V_TOP) gate; design -stash ver; \
	  design -copy-from vhd -as gold gold; design -copy-from ver -as gate gate; \
	  memory -nomap; memory_map; opt_clean; async2sync; $$(EQUIV_REN) \
	  equiv_make gold gate eq; hierarchy -top eq; \
	  equiv_simple; equiv_induct; equiv_status -assert"
	@echo "   ok, äquivalent zur VHDL-Fassung"

# Formaler Vergleich zweier Verilog-Varianten: $(1) gegen V_REF.
equiv-v-$(2): | $$(BUILD)
	@echo "== Äquivalenz $$(V_REF) <-> $(1) (Yosys equiv)"
	$$(YOSYS) -q -l $$(BUILD)/equiv_v_$(2).log -p " \
	  $$(call v_read,$$(V_REF)); rename $$(V_TOP) gold; \
	  $$(call v_read,$(1)); rename $$(V_TOP) gate; \
	  proc -norom; opt_clean; async2sync; \
	  equiv_make gold gate eq; hierarchy -top eq; \
	  equiv_simple; equiv_induct; equiv_status -assert"
	@echo "   ok, äquivalent zu $$(V_REF)"

show-v-$(2): | $$(BUILD)
	@echo "== Schaltbild Gatter (Yosys show): $(1)"
	$$(YOSYS) -q -p "$$(V_READ_SUB) $$(call v_read,$(1)); $$(call YOSYS_GATES,$$(V_TOP),$(2))"
	@echo "   $$(BUILD)/$(2)_gates.$$(SHOW_FORMAT)"

show-rtl-v-$(2): | $$(BUILD)
	@echo "== Schaltbild RTL (Yosys show): $(1)"
	$$(YOSYS) -q -p "$$(V_READ_SUB) $$(call v_read,$(1)); $$(call YOSYS_RTL,$$(V_TOP),$(2))"
	@echo "   $$(BUILD)/$(2)_rtl.$$(SHOW_FORMAT)"
endef

$(foreach f,$(V_SRC),$(eval $(call V_RULES,$(f),$(basename $(notdir $(f))))))

clean:
	rm -rf $(BUILD)
