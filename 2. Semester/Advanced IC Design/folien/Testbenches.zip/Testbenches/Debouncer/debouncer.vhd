-- Entprellung mit einem Zaehler
-- (teil5.typ, Folien "Entprellung mit einem Zaehler" und
-- "Implementierung: Entprellung mit einem Zaehler" I bis III)
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity debouncer is
-- Approx 10ms@100Mhz
generic (cntWidth : integer := 20);
port(clk    : in  std_logic;
     sigRaw : in  std_logic;
     sigDeb : out std_logic);
end debouncer;

architecture Behavioral of debouncer is
constant HIGH : std_logic_vector(cntWidth-1 downto 0) := (others => '1');

signal dCnt_r : std_logic_vector(cntWidth-1 downto 0) := (others => '0');
signal dCnt_n : std_logic_vector(cntWidth-1 downto 0);

signal deb_r : std_logic := '0';
signal deb_n : std_logic;

begin
  state_logic : process(clk)
  begin
    -- Test auf steigende Flanke
    if (rising_edge(clk)) then

      -- Setze Zaehlerregister
      dCnt_r <= dCnt_n;

      -- Setze Register fuer entprelltes Signal
      deb_r <= deb_n;
    end if;
  end process;

next_state_logic : process(dCnt_r, sigRaw, deb_r)
begin

  -- Teste entprelltes Signal und Eingabe auf Gleichheit
  if (deb_r = sigRaw) then

    -- Reset des Wartezaehlers
    dCnt_n <= (others => '0');

  else

    -- Zaehler erhoehen (prellen vermeiden)
    dCnt_n <= std_logic_vector(unsigned(dCnt_r) + 1);

  end if;

end process;

deb_logic : process(dCnt_r, sigRaw, deb_r)
begin

  -- Test auf groessten Zaehlerwert
  if (dCnt_r = HIGH) then

    -- Eingabe merken
    deb_n <= sigRaw;

  else

    -- Aktuelles entprelltes Signal nicht aendern
    deb_n <= deb_r;

  end if;

end process;

-- Entprelltes Signal ausgeben
sigDeb <= deb_r;

end architecture;
