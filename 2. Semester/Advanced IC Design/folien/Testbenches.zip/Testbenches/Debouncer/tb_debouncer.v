// Selbstprüfende Testbench für debouncer, WIDTH = 3 (Zähler voll nach
// 2^3 = 8 Takten):
//   1. Nach dem Reset: sigDeb = 0.
//   2. Gezielte Abschnitte: Störimpulse von 1 bis 7 Takten werden
//      unterdrückt, ein Wechsel von 8 Takten wird übernommen. Prellen
//      (kurze Impulse) vor einem Wechsel verzögert die Übernahme, bis die
//      Eingabe 8 Takte lang stabil ist. Gemessen wird jeweils, nach wie
//      vielen Takten sigDeb wechselt.
//   3. 400 Takte, in denen sigRaw mit Wahrscheinlichkeit 1/8 je Takt
//      wechselt (LFSR), damit kurze und lange Phasen gemischt vorkommen.
// In jedem Takt wird sigDeb gegen ein Referenzmodell geprüft. Eingänge
// werden an der fallenden Flanke gesetzt und eine fallende Flanke später
// geprüft. Ausgegeben werden nur die ersten 10 Fehler.

module tb_debouncer;

  localparam W = 3;
  localparam N = 1 << W;                 // Takte bis zur Übernahme

  reg           clk    = 1'b0;
  reg           reset  = 1'b1;
  reg           sigRaw = 1'b0;
  wire          sigDeb;
  integer       cnt;                     // Referenzmodell
  reg           eDeb;
  reg           lastDeb;
  integer       nDeb;                    // Wechsel von sigDeb
  integer       delay;                   // Takte seit dem letzten Eingabewechsel
  reg  [15 : 0] lfsr   = 16'hACE1;
  integer       i;
  integer       errors = 0;

  debouncer #(.WIDTH(W)) dut (.clk(clk), .reset(reset),
                              .sigRaw(sigRaw), .sigDeb(sigDeb));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  task check;
    begin
      if (sigDeb !== eDeb) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  sigRaw=%b sigDeb=%b  erwartet %b",
                   $time, sigRaw, sigDeb, eDeb);
        errors = errors + 1;
      end
    end
  endtask

  // Setzt sigRaw, rechnet das Referenzmodell einen Takt weiter und prüft
  // nach der nächsten steigenden Flanke. Das Modell zählt die Takte, in
  // denen Eingabe und Ausgabe verschieden sind; im N-ten übernimmt es.
  task step(input d);
    begin
      if (d !== sigRaw) delay = 0;
      sigRaw = d;
      delay  = delay + 1;
      if (d == eDeb) begin
        cnt = 0;
      end else if (cnt == N - 1) begin
        cnt = 0; eDeb = d;
      end else begin
        cnt = cnt + 1;
      end
      @(negedge clk);
      check;
      if (sigDeb !== lastDeb) nDeb = nDeb + 1;
      lastDeb = sigDeb;
    end
  endtask

  // Hält sigRaw k Takte lang
  task hold(input d, input integer k);
    begin
      repeat (k) step(d);
    end
  endtask

  // Erwartet die Ausgabe d und die angegebene Zahl von Wechseln seit dem
  // letzten Aufruf
  task expectDeb(input d, input integer n, input [8*24-1 : 0] what);
    begin
      if (sigDeb !== d || nDeb != n) begin
        $display("FEHLER: %0s: sigDeb=%b, %0d Wechsel (erwartet %b, %0d)",
                 what, sigDeb, nDeb, d, n);
        errors = errors + 1;
      end
      nDeb = 0;
    end
  endtask

  initial begin
    $dumpfile("tb_debouncer.vcd");        // läuft im Verzeichnis build/
    $dumpvars(0, tb_debouncer);

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten)
    @(negedge clk); @(negedge clk);
    cnt = 0; eDeb = 1'b0; delay = 0; nDeb = 0;
    check;
    lastDeb = sigDeb;
    reset = 1'b0;

    // 2. Gezielte Abschnitte
    hold(1'b0, 4);
    for (i = 1; i < N; i = i + 1) begin   // Störimpulse 1 bis N-1 Takte
      hold(1'b1, i);
      hold(1'b0, 2);
    end
    expectDeb(1'b0, 0, "Stoerimpulse 1..N-1");

    hold(1'b1, N - 1);                     // genau N Takte: übernommen
    step(1'b1);
    if (sigDeb !== 1'b1 || delay != N) begin
      $display("FEHLER: Wechsel nach 1 nicht nach %0d Takten", N);
      errors = errors + 1;
    end
    hold(1'b1, 4);
    expectDeb(1'b1, 1, "Wechsel nach N Takten");

    // Prellendes Loslassen: 0 für 3, 1 für 2, 0 für 5, 1 für 1, dann 0
    hold(1'b0, 3); hold(1'b1, 2); hold(1'b0, 5); hold(1'b1, 1);
    while (sigDeb !== 1'b0 && delay < 4 * N) step(1'b0);
    if (delay != N) begin
      $display("FEHLER: nach Prellen %0d statt %0d Takte bis zum Wechsel",
               delay, N);
      errors = errors + 1;
    end
    hold(1'b0, 4);
    expectDeb(1'b0, 1, "prellendes Loslassen");
    $display("ok     gezielte Abschnitte: Stoerimpulse unterdrueckt, Wechsel nach %0d Takten", N);

    // 3. Eingabe wechselt mit Wahrscheinlichkeit 1/8 je Takt
    repeat (400) begin
      lfsr = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      step((lfsr[2:0] == 3'b000) ? !sigRaw : sigRaw);
    end
    $display("ok     400 Takte Zufall: %0d Wechsel von sigDeb", nDeb);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
