// Entprellung mit einem Zähler
// (teil5.typ, Folie "Entprellung mit einem Zähler")
module debouncer
  #(parameter WIDTH = 20) // ca. 10 ms bei 100 MHz
   (input  wire clk, reset,
    input  wire sigRaw,
    output wire sigDeb);

  wire [WIDTH - 1 : 0] cntN;
  reg  [WIDTH - 1 : 0] cnt;
  wire                 debN;
  reg                  deb;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      cnt <= {WIDTH{1'b0}};
      deb <= 1'b0;
    end else begin
      cnt <= cntN;
      deb <= debN;
    end
  end

  // Nextstate logic
  assign cntN = (deb == sigRaw) ? {WIDTH{1'b0}} : cnt + 1;
  assign debN = (&cnt) ? sigRaw : deb; // Zähler voll?

  // Output logic
  assign sigDeb = deb;

endmodule
