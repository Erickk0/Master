-- Selbstpruefende Testbench fuer debouncer (VHDL-93), cntWidth = 3
-- (Zaehler voll nach 2^3 = 8 Takten):
--   1. Die Entity hat keinen Reset, Startwerte sind dCnt_r = 0 und
--      deb_r = '0', also sigDeb = '0'.
--   2. Gezielte Abschnitte: Stoerimpulse von 1 bis 7 Takten werden
--      unterdrueckt, ein Wechsel von 8 Takten wird uebernommen. Prellen
--      (kurze Impulse) vor einem Wechsel verzoegert die Uebernahme, bis die
--      Eingabe 8 Takte lang stabil ist. Gemessen wird jeweils, nach wie
--      vielen Takten sigDeb wechselt.
--   3. 400 Takte, in denen sigRaw mit Wahrscheinlichkeit 1/8 je Takt
--      wechselt (LFSR, dieselbe Folge wie in der Verilog-Testbench).
-- In jedem Takt wird sigDeb gegen ein Referenzmodell geprueft. Eingaenge
-- werden an der fallenden Flanke gesetzt und eine fallende Flanke spaeter
-- geprueft. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;

entity tb_debouncer is
end tb_debouncer;

architecture Test of tb_debouncer is
  constant W : integer := 3;
  constant N : integer := 2**W;          -- Takte bis zur Uebernahme

  signal clk    : std_logic := '0';
  signal sigRaw : std_logic := '0';
  signal sigDeb : std_logic;
  signal done   : boolean := false;
begin
  dut : entity work.debouncer
    generic map (cntWidth => W)
    port map (clk => clk, sigRaw => sigRaw, sigDeb => sigDeb);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable cnt     : natural := 0;       -- Referenzmodell
    variable eDeb    : std_logic := '0';
    variable lastDeb : std_logic;
    variable nDeb    : natural := 0;       -- Wechsel von sigDeb
    variable delay   : natural := 0;       -- Takte seit dem letzten Eingabewechsel
    variable cur     : std_logic := '0';   -- aktuelle Eingabe
    variable lfsr    : std_logic_vector(15 downto 0) := x"ACE1";

    -- Setzt sigRaw, rechnet das Referenzmodell einen Takt weiter und
    -- prueft nach der naechsten steigenden Flanke. Das Modell zaehlt die
    -- Takte, in denen Eingabe und Ausgabe verschieden sind; im N-ten
    -- uebernimmt es.
    procedure step(d : std_logic) is
    begin
      if d /= cur then delay := 0; end if;
      cur := d; sigRaw <= d;
      delay := delay + 1;
      if d = eDeb then
        cnt := 0;
      elsif cnt = N - 1 then
        cnt := 0; eDeb := d;
      else
        cnt := cnt + 1;
      end if;
      wait until falling_edge(clk);
      assert sigDeb = eDeb
        report "FEHLER: sigRaw = " & std_logic'image(d)
               & ", sigDeb = " & std_logic'image(sigDeb)
               & ", erwartet " & std_logic'image(eDeb)
        severity failure;
      if sigDeb /= lastDeb then nDeb := nDeb + 1; end if;
      lastDeb := sigDeb;
    end procedure;

    -- Haelt sigRaw k Takte lang
    procedure hold(d : std_logic; k : natural) is
    begin
      for i in 1 to k loop step(d); end loop;
    end procedure;

    -- Erwartet die Ausgabe d und die angegebene Zahl von Wechseln seit dem
    -- letzten Aufruf
    procedure expectDeb(d : std_logic; nExp : natural; what : string) is
    begin
      assert sigDeb = d and nDeb = nExp
        report "FEHLER: " & what & ": sigDeb = " & std_logic'image(sigDeb)
               & ", " & integer'image(nDeb) & " Wechsel"
        severity failure;
      nDeb := 0;
    end procedure;
  begin
    -- 1. Startwerte (einen Delta-Zyklus warten, bis die nebenlaeufige
    --    Zuweisung sigDeb <= deb_r gelaufen ist)
    wait for 0 ns;
    lastDeb := sigDeb;
    assert sigDeb = '0' report "FEHLER: Startwert" severity failure;

    -- 2. Gezielte Abschnitte
    hold('0', 4);
    for i in 1 to N - 1 loop                -- Stoerimpulse 1 bis N-1 Takte
      hold('1', i);
      hold('0', 2);
    end loop;
    expectDeb('0', 0, "Stoerimpulse 1..N-1");

    hold('1', N);                           -- genau N Takte: uebernommen
    assert sigDeb = '1' and delay = N
      report "FEHLER: Wechsel nach 1 nicht nach " & integer'image(N) & " Takten"
      severity failure;
    hold('1', 4);
    expectDeb('1', 1, "Wechsel nach N Takten");

    -- Prellendes Loslassen: 0 fuer 3, 1 fuer 2, 0 fuer 5, 1 fuer 1, dann 0
    hold('0', 3); hold('1', 2); hold('0', 5); hold('1', 1);
    while sigDeb /= '0' and delay < 4 * N loop step('0'); end loop;
    assert delay = N
      report "FEHLER: nach Prellen " & integer'image(delay) & " statt "
             & integer'image(N) & " Takte bis zum Wechsel"
      severity failure;
    hold('0', 4);
    expectDeb('0', 1, "prellendes Loslassen");
    report "ok: gezielte Abschnitte: Stoerimpulse unterdrueckt, Wechsel nach "
           & integer'image(N) & " Takten" severity note;

    -- 3. Eingabe wechselt mit Wahrscheinlichkeit 1/8 je Takt
    for i in 1 to 400 loop
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      if lfsr(2 downto 0) = "000" then step(not cur); else step(cur); end if;
    end loop;
    report "ok: 400 Takte Zufall: " & integer'image(nDeb) & " Wechsel von sigDeb"
      severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
