-- Decoder aus Teil 5 (VHDL), teil5.typ, Folie "Decoder"
library ieee;
use ieee.std_logic_1164.all;

entity Decoder4 is
port (idx : in std_logic_vector(2 downto 0);
        o : out std_logic_vector(7 downto 0));
end Decoder4;

architecture Behavioral of Decoder4 is
begin
with idx select
  o <= "00000000" when "000" | "001" | "010" | "011",
       "01000000" when "100",
       "10000000" when "101",
       "11000000" when others; -- inkl. "111"
end architecture;
