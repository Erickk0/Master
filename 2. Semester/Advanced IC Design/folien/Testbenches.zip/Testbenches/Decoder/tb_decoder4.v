// Selbstprüfende Testbench für decoder4: alle 8 Eingaben gegen eine
// unabhängig formulierte Referenz.

module tb_decoder4;

  reg  [2 : 0] idx;
  wire [7 : 0] o;
  integer      i;
  integer      errors = 0;

  decoder4 dut (.idx(idx), .o(o));

  // Referenz: idx < 4 -> 0, sonst o[7:6] = idx - 3 (gesättigt bei 3)
  function [7 : 0] expected(input [2 : 0] x);
    if (x < 3'd4)       expected = 8'b00000000;
    else if (x == 3'd4) expected = 8'b01000000;
    else if (x == 3'd5) expected = 8'b10000000;
    else                expected = 8'b11000000;
  endfunction

  initial begin
    $dumpfile("tb_decoder4.vcd");      // läuft im Verzeichnis build/
    $dumpvars(0, tb_decoder4);

    for (i = 0; i < 8; i = i + 1) begin
      idx = i;
      #10;
      if (o !== expected(idx)) begin
        $display("FEHLER: idx=%b  o=%b  erwartet=%b", idx, o, expected(idx));
        errors = errors + 1;
      end else
        $display("ok     idx=%b  o=%b", idx, o);
    end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
