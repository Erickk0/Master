-- Selbstpruefende Testbench fuer Decoder4 (VHDL-93): alle 8 Eingaben gegen
-- eine Referenztabelle. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_Decoder4 is
end tb_Decoder4;

architecture Test of tb_Decoder4 is
  signal idx : std_logic_vector(2 downto 0);
  signal o   : std_logic_vector(7 downto 0);

  type table_t is array (0 to 7) of std_logic_vector(7 downto 0);
  constant EXPECTED : table_t := (
    "00000000", "00000000", "00000000", "00000000",
    "01000000", "10000000", "11000000", "11000000");
begin
  dut : entity work.Decoder4 port map (idx => idx, o => o);

  stimulus : process
  begin
    for i in 0 to 7 loop
      idx <= std_logic_vector(to_unsigned(i, 3));
      wait for 10 ns;
      assert o = EXPECTED(i)
        report "FEHLER bei idx = " & integer'image(i)
        severity failure;
    end loop;
    report "PASS" severity note;
    wait;
  end process;
end architecture;
