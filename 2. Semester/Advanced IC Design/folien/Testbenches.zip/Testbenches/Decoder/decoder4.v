// Decoder in Verilog (teil5.typ, Folie "Decoder")
module decoder4 (input  wire [2 : 0] idx,
                 output reg  [7 : 0] o);

  always @(*) begin
    case (idx)
      3'b000, 3'b001,
      3'b010, 3'b011: o = 8'b00000000;
      3'b100:         o = 8'b01000000;
      3'b101:         o = 8'b10000000;
      default:        o = 8'b11000000; // inkl. 3'b111
    endcase
  end

endmodule
