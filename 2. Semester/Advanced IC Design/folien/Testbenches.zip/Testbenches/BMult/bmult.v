// Einfacher 5-Bit-Multiplizierer ohne Pipeline, Verilog-Fassung von
// bmult.vhd (teil14.typ). Die Kopien a0..a3, b0..b3 und die Teilprodukte
// sind bewusst redundant: An ihren Stellen sitzen spaeter die
// Pipelineregister (pmult.sv).
module bmult
  (input  wire [4 : 0] a,
   input  wire [4 : 0] b,
   output wire [9 : 0] c);

  // Vector version of ith bit of b
  wire [4 : 0] b0Vect, b1Vect, b2Vect, b3Vect, b4Vect;

  // The ith bit-product
  wire [9 : 0] bitProd0, bitProd1, bitProd2, bitProd3, bitProd4;

  // The ith partial product
  wire [9 : 0] partProd0, partProd1, partProd2, partProd3, partProd4;

  // Copies of inputs for each stage. Stage i braucht von b nur noch die
  // Bits ab i (wie in VHDL); die Synthese entfernt den Rest.
  wire [4 : 0] a0, a1, a2, a3;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [4 : 0] b0, b1, b2, b3;
  /* verilator lint_on UNUSEDSIGNAL */

  // Stage 0
  assign b0Vect    = {5{b[0]}};
  assign bitProd0  = {5'b00000, b0Vect & a};
  assign partProd0 = bitProd0;
  assign a0 = a;
  assign b0 = b;

  // Stage 1
  assign b1Vect    = {5{b0[1]}};
  assign bitProd1  = {4'b0000, b1Vect & a0, 1'b0};
  assign partProd1 = bitProd1 + partProd0;
  assign a1 = a0;
  assign b1 = b0;

  // Stage 2
  assign b2Vect    = {5{b1[2]}};
  assign bitProd2  = {3'b000, b2Vect & a1, 2'b00};
  assign partProd2 = bitProd2 + partProd1;
  assign a2 = a1;
  assign b2 = b1;

  // Stage 3
  assign b3Vect    = {5{b2[3]}};
  assign bitProd3  = {2'b00, b3Vect & a2, 3'b000};
  assign partProd3 = bitProd3 + partProd2;
  assign a3 = a2;
  assign b3 = b2;

  // Stage 4
  assign b4Vect    = {5{b3[4]}};
  assign bitProd4  = {1'b0, b4Vect & a3, 4'b0000};
  assign partProd4 = bitProd4 + partProd3;

  // Output
  assign c = partProd4;

endmodule
