-- Selbstpruefende Testbench fuer BMult (VHDL-93): alle 1024 Kombinationen
-- von a und b werden mit dem Produkt a * b verglichen (rein
-- kombinatorisch). Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_BMult is
end tb_BMult;

architecture Test of tb_BMult is
  signal a, b : std_logic_vector(4 downto 0);
  signal c    : std_logic_vector(9 downto 0);
begin
  dut : entity work.BMult
    port map (a => a, b => b, c => c);

  stimulus : process
  begin
    for i in 0 to 31 loop
      for j in 0 to 31 loop
        a <= std_logic_vector(to_unsigned(i, 5));
        b <= std_logic_vector(to_unsigned(j, 5));
        wait for 1 ns;
        assert to_integer(unsigned(c)) = i * j
          report "FEHLER: " & integer'image(i) & " * " & integer'image(j)
                 & " = " & integer'image(to_integer(unsigned(c)))
          severity failure;
      end loop;
    end loop;
    report "ok: alle 1024 Produkte" severity note;
    report "PASS" severity note;
    wait;
  end process;
end Test;
