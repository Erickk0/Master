-- Einfacher 5-Bit-Multiplizierer ohne Pipeline (teil14.typ). Die Folien
-- zeigen nur einen Ausschnitt; dies ist die vollstaendige Fassung im
-- selben Stil. Die Kopien a0..a3, b0..b3 und die Teilprodukte sind bewusst
-- redundant: An ihren Stellen sitzen spaeter die Pipelineregister (PMult).
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity BMult is
  port (a : in  std_logic_vector(4 downto 0);
        b : in  std_logic_vector(4 downto 0);
        c : out std_logic_vector(9 downto 0));
end entity;

architecture Behavioral of BMult is

  -- Vector version of ith bit of b
  signal b0Vect, b1Vect, b2Vect, b3Vect, b4Vect : std_logic_vector(4 downto 0);

  -- The ith bit-product
  signal bitProd0, bitProd1, bitProd2, bitProd3, bitProd4 : unsigned(9 downto 0);

  -- The ith partial product
  signal partProd0, partProd1, partProd2, partProd3, partProd4 : unsigned(9 downto 0);

  -- Copies of inputs for each stage
  signal a0, a1, a2, a3 : std_logic_vector(4 downto 0);
  signal b0, b1, b2, b3 : std_logic_vector(4 downto 0);
begin

  -- Stage 0
  b0Vect <= (others => b(0));
  bitProd0 <= unsigned("00000" & (b0Vect and a));
  partProd0 <= bitProd0;
  a0 <= a;
  b0 <= b;

  -- Stage 1
  b1Vect <= (others => b0(1));
  bitProd1 <= unsigned("0000" & (b1Vect and a0) & "0");
  partProd1 <= bitProd1 + partProd0;
  a1 <= a0;
  b1 <= b0;

  -- Stage 2
  b2Vect <= (others => b1(2));
  bitProd2 <= unsigned("000" & (b2Vect and a1) & "00");
  partProd2 <= bitProd2 + partProd1;
  a2 <= a1;
  b2 <= b1;

  -- Stage 3
  b3Vect <= (others => b2(3));
  bitProd3 <= unsigned("00" & (b3Vect and a2) & "000");
  partProd3 <= bitProd3 + partProd2;
  a3 <= a2;
  b3 <= b2;

  -- Stage 4
  b4Vect <= (others => b3(4));
  bitProd4 <= unsigned("0" & (b4Vect and a3) & "0000");
  partProd4 <= bitProd4 + partProd3;

  -- Output
  c <= std_logic_vector(partProd4);

end;
