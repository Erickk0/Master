// Selbstpruefende Testbench fuer bmult: alle 1024 Kombinationen von a und
// b werden mit dem Produkt a * b verglichen (rein kombinatorisch).

module tb_bmult;

  reg  [4 : 0] a, b;
  wire [9 : 0] c;
  integer      i, j, errors = 0;

  bmult dut (.a(a), .b(b), .c(c));

  initial begin
    $dumpfile("tb_bmult.vcd");            // laeuft im Verzeichnis build/
    $dumpvars(0, tb_bmult);

    for (i = 0; i < 32; i = i + 1)
      for (j = 0; j < 32; j = j + 1) begin
        a = i; b = j;
        #1;
        if (c !== i * j) begin
          $display("FEHLER: %0d * %0d = %0d, erwartet %0d", i, j, c, i * j);
          errors = errors + 1;
        end
      end
    $display("ok     alle 1024 Produkte");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
