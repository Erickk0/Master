// Gray-Zaehler ohne Addierer, SystemVerilog-Fassung durchgaengig mit logic
// (statt wire/reg). Gleiche Funktion wie graycnt_native.v.
module graycnt_native

  #(parameter WIDTH = 5)

  (input  logic clk,
   input  logic reset,
   input  logic enable,
   output logic [WIDTH - 1 : 0] gval);

  logic                  hBit, hBitN; // Toggle-Bit
  logic  [WIDTH - 1 : 0] val, valN;
  logic                  tmp;

  always_ff @(posedge clk) begin
    if (reset) begin // Synchron reset
      hBit <= 1'b1;
      val  <= {1'b1, {(WIDTH - 1){1'b0}}}; // g(Vorgaenger von 0)
    end else if (enable) begin
      hBit <= hBitN;
      val  <= valN;
    end
  end

  // Output logic
  assign gval = val;

  // Nextstate logic
  always_comb begin
    hBitN   = ~hBit;              // Toggle
    valN[0] = ~(val[0] ^ hBit);   // LSB

    // MSB: teste auf Muster x0^*
    tmp = 1'b1;
    for (int j = 0; j <= WIDTH - 3; j++)
      tmp = tmp & ~val[j];
    valN[WIDTH - 1] = val[WIDTH - 1] ^ (tmp & hBit);

    // Innere Bits: teste auf Muster 10^*
    for (int i = 1; i <= WIDTH - 2; i++) begin
      tmp = 1'b1;
      for (int j = 0; j <= i - 2; j++)
        tmp = tmp & ~val[j];
      valN[i] = val[i] ^ (val[i - 1] & tmp & hBit);
    end
  end

endmodule
