library ieee;
use ieee.std_logic_1164.all;

entity GrayCnt is

  generic(width : integer := 5);

  port (clk    : in  std_logic;
        reset  : in  std_logic;
        enable : in  std_logic;
        gval   : out std_logic_vector(width - 1 downto 0));

end GrayCnt;

architecture Native of GrayCnt is
  signal hBit_reg  : std_logic; -- Hold the toggling bit
  signal hBit_next : std_logic;

  signal val_reg  : std_logic_vector(width - 1 downto 0);
  signal val_next : std_logic_vector(width - 1 downto 0);
begin

  state_logic : process (clk, reset)
  begin
    if (rising_edge(clk)) then
      if(reset = '1') then
        hBit_reg <= '1';
        val_reg <= (others => '0');
        val_reg(val_reg'high) <= '1';
      else
        if (enable = '1') then
          hBit_reg <= hBit_next;
          val_reg <= val_next;
        end if;
      end if;
    end if;
  end process;

  gval <= val_reg; -- Output logic

  next_state : process(val_reg, hBit_reg)
    variable tmp : std_logic;
  begin
    hBit_next <= not hBit_reg; -- Toggle

    val_next(val_next'low) <=
      not(val_reg(val_reg'low) xor (hBit_reg)); -- LSB

    -- Teil der Gleichung fuer das MSB
    tmp := '1';
    for j in 0 to width - 3 loop
      -- Teste auf Muster 0^*
      tmp := tmp and not(val_reg(j));
    end loop;

    -- Vollstaendige Gleichung fuer das MSB
    val_next(val_next'high) <=
      val_reg(val_reg'high) xor (tmp and hBit_reg);

    -- Erzeuge alle inneren Bits
    for i in 1 to width - 2 loop

      -- Test auf Muster 10^*
      tmp := '1';

      for j in 0 to i - 2 loop
        tmp := tmp and not(val_reg(j));
      end loop;

      tmp := val_reg(i - 1) and tmp and hBit_reg;

      -- Vollstaendige Gleichung fuer Bit i
      val_next(i) <= val_reg(i) xor tmp;

    end loop;

  end process;

end architecture;
