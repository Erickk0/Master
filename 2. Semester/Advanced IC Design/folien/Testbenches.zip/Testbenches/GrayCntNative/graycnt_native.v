module graycnt_native

  #(parameter WIDTH = 5)

  (input  wire clk,
   input  wire reset,
   input  wire enable,
   output wire [WIDTH - 1 : 0] gval);

  reg                  hBit, hBitN; // Toggle-Bit
  reg  [WIDTH - 1 : 0] val, valN;
  reg                  tmp;
  integer              i, j;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      hBit <= 1'b1;
      val  <= {1'b1, {(WIDTH - 1){1'b0}}}; // g(Vorgänger von 0)
    end else if (enable) begin
      hBit <= hBitN;
      val  <= valN;
    end
  end

  // Output logic
  assign gval = val;

  // Nextstate logic
  always @* begin
    hBitN  = ~hBit;              // Toggle
    valN[0] = ~(val[0] ^ hBit);  // LSB

    // MSB: teste auf Muster x0^*
    tmp = 1'b1;
    for (j = 0; j <= WIDTH - 3; j = j + 1)
      tmp = tmp & ~val[j];
    valN[WIDTH - 1] = val[WIDTH - 1] ^ (tmp & hBit);

    // Innere Bits: teste auf Muster 10^*
    for (i = 1; i <= WIDTH - 2; i = i + 1) begin
      tmp = 1'b1;
      for (j = 0; j <= i - 2; j = j + 1)
        tmp = tmp & ~val[j];
      valN[i] = val[i] ^ (val[i - 1] & tmp & hBit);
    end
  end

endmodule
