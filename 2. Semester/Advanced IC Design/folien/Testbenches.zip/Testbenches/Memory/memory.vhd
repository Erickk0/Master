-- Dual-Port-BlockRAM: Port A nur lesen, Port B schreiben und lesen
-- (teil5.typ, Folien "BlockRAM - Interface" und "BlockRAM - Architektur" I, II)
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library cpu;
use cpu.CPUTypes.all;

entity Memory is

  port (clk          : in std_logic;

        adrA         : in  cpuAdr_t;
        dOutA        : out cell_t;

        writeEnableB : in  std_logic;
        adrB         : in  cpuAdr_t;
        dInB         : in  cell_t;
        dOutB        : out cell_t);

end Memory;

architecture Behavioral of Memory is

-- The memory file (use := for an initial value / e.g. program)
shared variable mem : memory_t;

-- Use block RAM for the memory (Xilinx)
attribute ram_style        : string;
attribute ram_style of mem : variable is "block";

begin

portA : process (clk)
begin
  if (rising_edge(clk)) then
    -- Synchron readonly port A
    dOutA <= mem(to_integer(unsigned(adrA)));
  end if;
end process;

portB : process (clk)
begin
  if (rising_edge(clk)) then

    -- Check for write mode
    if (writeEnableB = '1') then
      mem(to_integer(unsigned(adrB))) := dInB;
    end if;

    -- Synchron read access
    dOutB <= mem(to_integer(unsigned(adrB)));

  end if;
end process;

end Behavioral;
