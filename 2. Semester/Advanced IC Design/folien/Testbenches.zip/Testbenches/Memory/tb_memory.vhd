-- Selbstpruefende Testbench fuer Memory (VHDL-93), Typen aus cpu.CPUTypes
-- (8 Bit Adresse, 8 Bit Daten):
--   1. Alle 256 Adressen ueber Port B beschreiben. Port B liefert dabei den
--      neuen Wert (write first), Port A liest parallel die zuletzt
--      beschriebene Adresse.
--   2. Alles ueber beide Ports zuruecklesen (A aufsteigend, B absteigend).
--   3. 500 Takte mit pseudozufaelligen Adressen, Daten und writeEnableB
--      aus einem LFSR (dieselbe Folge wie in der Verilog-Testbench).
--      Gelegentlich gleiche Adresse an A und B, waehrend B schreibt
--      (Kollision): Dann wird dOutA nicht geprueft. In der Simulation ist
--      der Wert nicht festgelegt (zwei Prozesse, eine shared variable,
--      Reihenfolge offen), und im BlockRAM ist er unzuverlaessig, wenn der
--      schreibende Port im Modus WRITE_FIRST arbeitet (Xilinx UG383; der
--      Vivado-Simulator gibt dann X aus, UG900).
-- In jedem Takt werden dOutA und dOutB gegen ein Referenzmodell geprueft.
-- Eingaenge werden an der fallenden Flanke gesetzt und eine fallende
-- Flanke spaeter geprueft. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library cpu;
use cpu.CPUTypes.all;

entity tb_Memory is
end tb_Memory;

architecture Test of tb_Memory is
  constant DEPTH : integer := 2**cpuAdrWidth;

  signal clk          : std_logic := '0';
  signal adrA, adrB   : cpuAdr_t  := (others => '0');
  signal writeEnableB : std_logic := '0';
  signal dInB         : cell_t    := (others => '0');
  signal dOutA, dOutB : cell_t;
  signal done         : boolean := false;

  function to_hex(v : std_logic_vector) return string is
    constant HEX : string(1 to 16) := "0123456789abcdef";
    variable s : string(1 to v'length / 4);
    variable n : integer;
  begin
    for k in 0 to integer(v'length / 4 - 1) loop
      if is_x(v(v'right + 4 * k + 3 downto v'right + 4 * k)) then
        s(s'length - k) := 'X';
      else
        n := to_integer(unsigned(v(v'right + 4 * k + 3 downto v'right + 4 * k)));
        s(s'length - k) := HEX(n + 1);
      end if;
    end loop;
    return s;
  end function;
begin
  dut : entity work.Memory
    port map (clk => clk, adrA => adrA, dOutA => dOutA,
              writeEnableB => writeEnableB, adrB => adrB, dInB => dInB,
              dOutB => dOutB);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable model  : memory_t;            -- Referenzmodell
    variable eA, eB : cell_t;
    variable coll   : boolean;             -- Kollision: dOutA nicht pruefen
    variable lfsr   : std_logic_vector(15 downto 0) := x"ACE1";
    variable r1, r2 : std_logic_vector(15 downto 0);
    variable bAdr   : cpuAdr_t;
    variable nWrite, nColl : natural := 0;

    -- Ein Takt: Eingaenge setzen, Modell weiterrechnen, nach der
    -- steigenden Flanke pruefen.
    procedure step(a : natural; w : std_logic; b : natural; d : cell_t) is
    begin
      adrA <= std_logic_vector(to_unsigned(a, cpuAdrWidth));
      adrB <= std_logic_vector(to_unsigned(b, cpuAdrWidth));
      writeEnableB <= w; dInB <= d;
      eA := model(a);
      coll := w = '1' and a = b;
      if w = '1' then
        model(b) := d; eB := d; nWrite := nWrite + 1;
        if coll then nColl := nColl + 1; end if;
      else
        eB := model(b);
      end if;
      wait until falling_edge(clk);
      assert (coll or dOutA = eA) and dOutB = eB
        report "FEHLER: adrA = " & integer'image(a) & ", adrB = " & integer'image(b)
               & ", we = " & std_logic'image(w)
               & ": dOutA = " & to_hex(dOutA) & ", dOutB = " & to_hex(dOutB)
               & ", erwartet " & to_hex(eA) & ", " & to_hex(eB)
        severity failure;
    end procedure;

    function lfsrStep(x : std_logic_vector(15 downto 0)) return std_logic_vector is
    begin
      return x(14 downto 0) & (x(15) xor x(13) xor x(12) xor x(10));
    end function;
  begin
    wait until falling_edge(clk);

    -- 1. Alle Adressen beschreiben, A liest die vorherige Adresse
    for i in 0 to DEPTH - 1 loop
      step((i - 1) mod DEPTH, '1', i,
           std_logic_vector(to_unsigned((i * 37 + 5) mod 256, 8)
                            xor to_unsigned(i / 8, 8)));
    end loop;
    -- 2. Zuruecklesen ueber beide Ports
    for i in 0 to DEPTH - 1 loop
      step(i, '0', DEPTH - 1 - i, x"00");
    end loop;
    report "ok: alle " & integer'image(DEPTH)
           & " Adressen geschrieben und ueber A und B gelesen" severity note;

    -- 3. Pseudozufaellige Zugriffe
    nWrite := 0; nColl := 0;
    for i in 1 to 500 loop
      lfsr := lfsrStep(lfsr); r1 := lfsr;
      lfsr := lfsrStep(lfsr); r2 := lfsr;
      -- in einem Viertel der Takte gleiche Adresse an A und B
      if r2(15 downto 14) = "00" then bAdr := r1(7 downto 0);
      else bAdr := r2(7 downto 0); end if;
      step(to_integer(unsigned(r1(7 downto 0))), r1(8),
           to_integer(unsigned(bAdr)), r2(7 downto 0) xor r1(15 downto 8));
    end loop;
    report "ok: 500 Takte Zufall: " & integer'image(nWrite)
           & " Schreibzugriffe, " & integer'image(nColl)
           & " davon auf die Adresse von A" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
