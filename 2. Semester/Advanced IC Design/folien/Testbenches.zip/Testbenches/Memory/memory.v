// Dual-Port-BlockRAM: Port A nur lesen, Port B schreiben und lesen
// (teil5.typ, Folie "Ein BlockRAM")
module memory
  #(parameter ADR_WIDTH  = 8,
              DATA_WIDTH = 8)
   (input  wire                      clk,

    input  wire [ADR_WIDTH - 1 : 0]  adrA,
    output reg  [DATA_WIDTH - 1 : 0] dOutA,

    input  wire                      writeEnableB,
    input  wire [ADR_WIDTH - 1 : 0]  adrB,
    input  wire [DATA_WIDTH - 1 : 0] dInB,
    output reg  [DATA_WIDTH - 1 : 0] dOutB);

  (* ram_style = "block" *) // BlockRAM verwenden (Xilinx)
  reg [DATA_WIDTH - 1 : 0] mem [0 : 2**ADR_WIDTH - 1];

  always @(posedge clk) begin // Port A: nur lesen
    dOutA <= mem[adrA];
  end

  always @(posedge clk) begin // Port B: schreiben, lesen
    if (writeEnableB) begin
      mem[adrB] <= dInB;
      dOutB     <= dInB; // Write first
    end else begin
      dOutB     <= mem[adrB];
    end
  end

endmodule
