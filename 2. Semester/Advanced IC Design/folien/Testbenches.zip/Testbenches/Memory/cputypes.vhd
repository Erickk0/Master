-- Typen fuer das BlockRAM, Package in der Bibliothek cpu
-- (teil5.typ, Folie "BlockRAM")
library ieee;
use ieee.std_logic_1164.all;

package CPUTypes is

constant cpuAdrWidth : integer := 8;
subtype cpuAdr_t is std_logic_vector(cpuAdrWidth - 1 downto 0);

constant cellWidth : integer := 8;
subtype cell_t is std_logic_vector(cellWidth - 1 downto 0);

type memory_t is array (natural range 2**cpuAdrWidth - 1 downto 0) of cell_t;

end CPUTypes;
