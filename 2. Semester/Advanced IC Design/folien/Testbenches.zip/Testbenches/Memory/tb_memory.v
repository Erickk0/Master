// Selbstprüfende Testbench für memory, ADR_WIDTH = DATA_WIDTH = 8:
//   1. Alle 256 Adressen über Port B beschreiben. Port B liefert dabei den
//      neuen Wert (write first), Port A liest parallel die zuletzt
//      beschriebene Adresse.
//   2. Alles über beide Ports zurücklesen (A aufsteigend, B absteigend).
//   3. 500 Takte mit pseudozufälligen Adressen, Daten und writeEnableB aus
//      einem LFSR. Gelegentlich gleiche Adresse an A und B, während B
//      schreibt (Kollision): Dann wird dOutA nicht geprüft. In der
//      Verilog-Simulation liest A wegen <= zwar den alten Inhalt, im
//      BlockRAM ist der Wert aber unzuverlässig, wenn der schreibende Port
//      im Modus WRITE_FIRST arbeitet (Xilinx UG383; der Vivado-Simulator
//      gibt dann X aus, UG900). Die Testbench verlangt daher nichts, was
//      die Hardware nicht garantiert.
// In jedem Takt werden dOutA und dOutB gegen ein Referenzmodell (Array)
// geprüft. Eingänge werden an der fallenden Flanke gesetzt und eine
// fallende Flanke später geprüft. Ausgegeben werden nur die ersten 10
// Fehler.

module tb_memory;

  localparam AW    = 8;
  localparam DW    = 8;
  localparam DEPTH = 1 << AW;

  reg            clk          = 1'b0;
  reg  [AW-1 : 0] adrA        = 0;
  reg  [AW-1 : 0] adrB        = 0;
  reg            writeEnableB = 1'b0;
  reg  [DW-1 : 0] dInB        = 0;
  wire [DW-1 : 0] dOutA, dOutB;

  reg  [DW-1 : 0] model [0 : DEPTH-1];  // Referenzmodell
  reg  [DW-1 : 0] eA, eB;
  reg             coll;                 // Kollision: dOutA nicht prüfen
  reg  [15 : 0]   lfsr = 16'hACE1;
  reg  [15 : 0]   r1, r2;
  integer         i, nWrite, nColl;
  integer         errors = 0;

  memory dut (.clk(clk), .adrA(adrA), .dOutA(dOutA),
              .writeEnableB(writeEnableB), .adrB(adrB), .dInB(dInB),
              .dOutB(dOutB));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  // Ein Takt: Eingänge setzen, Modell weiterrechnen, nach der steigenden
  // Flanke prüfen. Port B liefert beim Schreiben den neuen Wert (write
  // first), Port A den Inhalt der Adresse (außer bei einer Kollision).
  task step(input [AW-1 : 0] a, input w, input [AW-1 : 0] b, input [DW-1 : 0] d);
    begin
      adrA = a; writeEnableB = w; adrB = b; dInB = d;
      eA = model[a];
      coll = w && (a == b);
      if (w) begin
        model[b] = d; eB = d; nWrite = nWrite + 1;
        if (coll) nColl = nColl + 1;
      end else begin
        eB = model[b];
      end
      @(negedge clk);
      if ((!coll && dOutA !== eA) || dOutB !== eB) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  adrA=%0d adrB=%0d we=%b: dOutA=%h dOutB=%h, erwartet %h %h",
                   $time, a, b, w, dOutA, dOutB, eA, eB);
        errors = errors + 1;
      end
    end
  endtask

  // LFSR einen Schritt weiter
  function [15 : 0] next(input [15 : 0] x);
    next = {x[14:0], x[15] ^ x[13] ^ x[12] ^ x[10]};
  endfunction

  initial begin
    $dumpfile("tb_memory.vcd");           // läuft im Verzeichnis build/
    $dumpvars(0, tb_memory);
    nWrite = 0; nColl = 0;
    @(negedge clk);

    // 1. Alle Adressen beschreiben, A liest die vorherige Adresse
    for (i = 0; i < DEPTH; i = i + 1)
      step(i - 1, 1'b1, i, (i * 37 + 5) ^ (i >> 3));
    // 2. Zurücklesen über beide Ports
    for (i = 0; i < DEPTH; i = i + 1)
      step(i, 1'b0, DEPTH - 1 - i, 8'h00);
    $display("ok     alle %0d Adressen geschrieben und ueber A und B gelesen", DEPTH);

    // 3. Pseudozufällige Zugriffe
    nWrite = 0;
    repeat (500) begin
      lfsr = next(lfsr); r1 = lfsr;
      lfsr = next(lfsr); r2 = lfsr;
      // in einem Viertel der Takte gleiche Adresse an A und B
      step(r1[7:0], r1[8], (r2[15:14] == 2'b00) ? r1[7:0] : r2[7:0], r2[7:0] ^ r1[15:8]);
    end
    $display("ok     500 Takte Zufall: %0d Schreibzugriffe, %0d davon auf die Adresse von A",
             nWrite, nColl);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
