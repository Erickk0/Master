-- Entprellung mit einem Schieberegister, inkl. alarm
-- (teil5.typ, Folien "Eine Anwendung von Schieberegistern (II)" und "(III)")
library ieee;
use ieee.std_logic_1164.all;

entity debounce is

  generic (preScale : natural := 100000);

  port (clk100M : in  std_logic;
        input   : in  std_logic;
        output  : out std_logic;
        alarm   : out std_logic);

end debounce;

architecture Behavioral of debounce is

  signal preCnt : integer range 0 to preScale - 1 := 0;
  signal shReg  : std_logic_vector(3 downto 0) := (others => '0');
begin
  process (clk100M)
  begin
    if (rising_edge(clk100M)) then
      if (preCnt = 0) then
        preCnt <= preScale - 1;
        if (shReg  = "0000") then output <= '0'; end if;
        if (shReg  = "1111") then output <= '1'; end if;
        if ((shReg = "1000") or (shReg = "0111")) then
          alarm <= '1';
        else
          alarm <= '0';
        end if;
        shReg <= shReg(2 downto 0) & input;
      else
        preCnt <= preCnt - 1;
     end if;
   end if;
 end process;
end architecture;
