// Entprellung mit einem Schieberegister, inkl. alarm, in SystemVerilog:
// alle reg und wire durch logic ersetzt, always_ff fuer die Register
// (frueher teil9.typ, Folie "Der Datentyp logic: ein Beispiel";
// diese Folie gibt es nicht mehr).
module debounce
  #(parameter PRESCALE = 100000)
   (input  logic clk, reset,
    input  logic din,
    output logic dout, alarm);

  localparam WIDTH = $clog2(PRESCALE);

  logic [WIDTH - 1 : 0] cnt, cntN;
  logic [3 : 0]         sh, shN;
  logic                 deb, debN, alm, almN, tick;

  always_ff @(posedge clk) begin
    if (reset) begin // Synchron reset
      cnt <= 0;    sh  <= 4'b0000;
      deb <= 1'b0; alm <= 1'b0;
    end else begin
      cnt <= cntN; sh  <= shN;
      deb <= debN; alm <= almN;
    end
  end

  // Nextstate logic
  assign tick = (cnt == 0); // Eingabe abtasten

  assign cntN = tick ? PRESCALE - 1 : cnt - 1;

  assign shN  = tick ? {sh[2 : 0], din} : sh;

  assign debN = tick ? ((sh == 4'b0000) ? 1'b0 :
                        (sh == 4'b1111) ? 1'b1 : deb) : deb;

  assign almN = tick ? ((sh == 4'b1000) ||
                        (sh == 4'b0111)) : alm;

  // Output logic
  assign dout  = deb;
  assign alarm = alm;

endmodule
