// Entprellung mit einem Schieberegister, inkl. alarm
// (teil5.typ, Folie "Eine Anwendung von Schieberegistern (II)")
module debounce
  #(parameter PRESCALE = 100000)
   (input  wire clk, reset,
    input  wire din,
    output wire dout, alarm);

  localparam WIDTH = $clog2(PRESCALE); // log2, aufgerundet

  wire [WIDTH - 1 : 0] cntN;
  reg  [WIDTH - 1 : 0] cnt;
  wire [3 : 0]         shN;
  reg  [3 : 0]         sh;
  wire                 debN, almN, tick;
  reg                  deb, alm;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      cnt <= 0;    sh  <= 4'b0000;
      deb <= 1'b0; alm <= 1'b0;
    end else begin
      cnt <= cntN; sh  <= shN;
      deb <= debN; alm <= almN;
    end
  end

  // Nextstate logic
  assign tick = (cnt == 0); // Eingabe abtasten

  assign cntN = tick ? PRESCALE - 1 : cnt - 1; // Counter aktualisieren

  assign shN  = tick ? {sh[2 : 0], din} : sh;

  assign debN = tick ? ((sh == 4'b0000) ? 1'b0 :
                        (sh == 4'b1111) ? 1'b1 : deb) : deb;

  assign almN = tick ? ((sh == 4'b1000) ||      // Beim nächsten Mal
                        (sh == 4'b0111)) : alm; // vielleicht ein Alarm

  // Output logic
  assign dout  = deb;
  assign alarm = alm;

endmodule
