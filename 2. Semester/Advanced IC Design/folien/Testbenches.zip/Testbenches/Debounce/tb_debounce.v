// Selbstprüfende Testbench für debounce, PRESCALE = 4 (Abtastung alle 4
// Takte):
//   1. Nach dem Reset: dout = 0, alarm = 0.
//   2. Prellender Tastendruck und prellendes Loslassen (Abtastwerte ohne
//      vier gleiche in Folge): dout wechselt jeweils genau einmal. alarm
//      kommt zweimal: einmal bei drei gleichen Abtastwerten, die das Prellen
//      noch einmal unterbricht (Fehlalarm), und einmal vor dem Wechsel.
//   3. 400 Takte mit pseudozufälligem din aus einem LFSR.
// In jedem Takt werden dout und alarm gegen ein Referenzmodell geprüft.
// Eingänge werden an der fallenden Flanke gesetzt und eine fallende Flanke
// später geprüft. Ausgegeben werden nur die ersten 10 Fehler.

module tb_debounce;

  localparam P = 4;

  reg           clk   = 1'b0;
  reg           reset = 1'b1;
  reg           din   = 1'b0;
  wire          dout, alarm;
  integer       cnt;                    // Referenzmodell
  reg  [3 : 0]  sh;
  reg           eOut, eAlarm;
  reg           lastOut, lastAlarm;
  integer       nOut, nAlarm;           // Wechsel von dout, alarm-Pulse
  reg  [15 : 0] lfsr  = 16'hACE1;
  integer       errors = 0;

  debounce #(.PRESCALE(P)) dut (.clk(clk), .reset(reset), .din(din),
                                .dout(dout), .alarm(alarm));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  task check;
    begin
      if (dout !== eOut || alarm !== eAlarm) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  dout=%b alarm=%b  erwartet %b %b",
                   $time, dout, alarm, eOut, eAlarm);
        errors = errors + 1;
      end
    end
  endtask

  // Setzt din, rechnet das Referenzmodell einen Takt weiter und prüft nach
  // der nächsten steigenden Flanke. Zählt die Wechsel von dout und die
  // steigenden Flanken von alarm.
  task step(input d);
    begin
      din = d;
      if (cnt == 0) begin
        cnt = P - 1;
        if (sh == 4'b0000) eOut = 1'b0;
        if (sh == 4'b1111) eOut = 1'b1;
        eAlarm = (sh == 4'b1000) || (sh == 4'b0111);
        sh = {sh[2 : 0], d};
      end else begin
        cnt = cnt - 1;
      end
      @(negedge clk);
      check;
      if (dout !== lastOut) nOut = nOut + 1;
      if (alarm === 1'b1 && lastAlarm !== 1'b1) nAlarm = nAlarm + 1;
      lastOut = dout; lastAlarm = alarm;
    end
  endtask

  // Hält din für eine ganze Abtastperiode (P Takte)
  task sample(input d);
    begin
      repeat (P) step(d);
    end
  endtask

  // Prellender Wechsel nach d: nie vier gleiche Abtastwerte in Folge, danach
  // stabil. Erwartet genau einen Wechsel von dout und zwei alarm-Pulse
  // (nach d, d, d vor dem letzten !d und vor dem Wechsel).
  task bounce(input d);
    begin
      nOut = 0; nAlarm = 0;
      sample(d); sample(!d); sample(d); sample(d); sample(!d);
      sample(d); sample(d); sample(d); sample(!d);
      repeat (8) sample(d);
      if (dout !== d || nOut != 1 || nAlarm != 2) begin
        $display("FEHLER: Wechsel nach %b: dout=%b, %0d Wechsel, %0d alarm-Pulse",
                 d, dout, nOut, nAlarm);
        errors = errors + 1;
      end else
        $display("ok     prellender Wechsel nach %b: ein Wechsel, zwei alarm-Pulse", d);
    end
  endtask

  initial begin
    $dumpfile("tb_debounce.vcd");         // läuft im Verzeichnis build/
    $dumpvars(0, tb_debounce);

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten)
    @(negedge clk); @(negedge clk);
    cnt = 0; sh = 4'b0000; eOut = 1'b0; eAlarm = 1'b0;
    check;
    lastOut = dout; lastAlarm = alarm;
    reset = 1'b0;

    // 2. Prellender Tastendruck und prellendes Loslassen
    repeat (6) sample(1'b0);
    bounce(1'b1);
    bounce(1'b0);

    // 3. Pseudozufälliges din
    nOut = 0; nAlarm = 0;
    repeat (400) begin
      lfsr = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      step(lfsr[0]);
    end
    $display("ok     400 Takte Zufall: %0d Wechsel von dout, %0d alarm-Pulse",
             nOut, nAlarm);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
