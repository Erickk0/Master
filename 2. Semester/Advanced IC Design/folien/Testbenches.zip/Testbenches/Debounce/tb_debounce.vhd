-- Selbstpruefende Testbench fuer debounce (VHDL-93), preScale = 4
-- (Abtastung alle 4 Takte):
--   1. Die Entity hat keinen Reset. Nach der ersten steigenden Flanke
--      gilt output = '0' und alarm = '0' (Startwerte preCnt = 0,
--      shReg = "0000").
--   2. Prellender Tastendruck und prellendes Loslassen (Abtastwerte ohne
--      vier gleiche in Folge): output wechselt jeweils genau einmal. alarm
--      kommt zweimal: einmal bei drei gleichen Abtastwerten, die das
--      Prellen noch einmal unterbricht (Fehlalarm), und einmal vor dem
--      Wechsel.
--   3. 400 Takte mit pseudozufaelligem input aus einem LFSR (dieselbe
--      Folge wie in der Verilog-Testbench).
-- In jedem Takt werden output und alarm gegen ein Referenzmodell geprueft.
-- Eingaenge werden an der fallenden Flanke gesetzt und eine fallende Flanke
-- spaeter geprueft. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;

entity tb_debounce is
end tb_debounce;

architecture Test of tb_debounce is
  constant P : natural := 4;

  signal clk   : std_logic := '0';
  signal din   : std_logic := '0';
  signal dout  : std_logic;
  signal alarm : std_logic;
  signal done  : boolean := false;
begin
  dut : entity work.debounce
    generic map (preScale => P)
    port map (clk100M => clk, input => din, output => dout, alarm => alarm);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable cnt       : natural := 0;          -- Referenzmodell
    variable sh        : std_logic_vector(3 downto 0) := "0000";
    variable eOut      : std_logic := 'U';
    variable eAlarm    : std_logic := 'U';
    variable lastOut   : std_logic := 'U';
    variable lastAlarm : std_logic := 'U';
    variable nOut, nAlarm : natural := 0;
    variable lfsr      : std_logic_vector(15 downto 0) := x"ACE1";

    -- Setzt input, rechnet das Referenzmodell einen Takt weiter und prueft
    -- nach der naechsten steigenden Flanke. Zaehlt die Wechsel von output
    -- und die steigenden Flanken von alarm.
    procedure step(d : std_logic) is
    begin
      din <= d;
      if cnt = 0 then
        cnt := P - 1;
        if sh = "0000" then eOut := '0'; end if;
        if sh = "1111" then eOut := '1'; end if;
        if sh = "1000" or sh = "0111" then eAlarm := '1'; else eAlarm := '0'; end if;
        sh := sh(2 downto 0) & d;
      else
        cnt := cnt - 1;
      end if;
      wait until falling_edge(clk);
      assert dout = eOut and alarm = eAlarm
        report "FEHLER: output = " & std_logic'image(dout)
               & ", alarm = " & std_logic'image(alarm)
               & ", erwartet " & std_logic'image(eOut)
               & ", " & std_logic'image(eAlarm)
        severity failure;
      if dout /= lastOut then nOut := nOut + 1; end if;
      if alarm = '1' and lastAlarm /= '1' then nAlarm := nAlarm + 1; end if;
      lastOut := dout; lastAlarm := alarm;
    end procedure;

    -- Haelt input fuer eine ganze Abtastperiode (P Takte)
    procedure sample(d : std_logic) is
    begin
      for i in 1 to P loop step(d); end loop;
    end procedure;

    -- Prellender Wechsel nach d: nie vier gleiche Abtastwerte in Folge,
    -- danach stabil. Erwartet genau einen Wechsel von output und zwei
    -- alarm-Pulse (nach d, d, d vor dem letzten nd und vor dem Wechsel).
    procedure bounce(d : std_logic) is
      variable nd : std_logic;
    begin
      nd := not d;
      nOut := 0; nAlarm := 0;
      sample(d); sample(nd); sample(d); sample(d); sample(nd);
      sample(d); sample(d); sample(d); sample(nd);
      for i in 1 to 8 loop sample(d); end loop;
      assert dout = d and nOut = 1 and nAlarm = 2
        report "FEHLER: Wechsel nach " & std_logic'image(d) & ": "
               & integer'image(nOut) & " Wechsel, "
               & integer'image(nAlarm) & " alarm-Pulse"
        severity failure;
      report "ok: prellender Wechsel nach " & std_logic'image(d)
             & ": ein Wechsel, zwei alarm-Pulse" severity note;
    end procedure;
  begin
    -- 1. Erste Flanke: Startwerte, output und alarm werden '0'
    step('0');
    lastOut := dout; lastAlarm := alarm;

    -- 2. Prellender Tastendruck und prellendes Loslassen
    for i in 1 to 6 loop sample('0'); end loop;
    bounce('1');
    bounce('0');

    -- 3. Pseudozufaelliges input
    nOut := 0; nAlarm := 0;
    for i in 1 to 400 loop
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      step(lfsr(0));
    end loop;
    report "ok: 400 Takte Zufall: " & integer'image(nOut) & " Wechsel von output, "
           & integer'image(nAlarm) & " alarm-Pulse" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
