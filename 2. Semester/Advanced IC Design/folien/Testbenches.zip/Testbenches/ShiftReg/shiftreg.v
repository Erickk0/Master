// Universelles Schieberegister: halten, rechts/links schieben, laden
// (teil5.typ, Folie "Ein universelles Schieberegister")
module shiftreg
  #(parameter WIDTH = 8)
   (input  wire clk, reset,
    input  wire [1 : 0] mode,
    input  wire [WIDTH - 1 : 0] d,
    output wire [WIDTH - 1 : 0] q);

  localparam NOP   = 2'b00,
             RIGHT = 2'b01,
             LEFT  = 2'b10,
             LOAD  = 2'b11;

  reg  [WIDTH - 1 : 0] datN;
  reg  [WIDTH - 1 : 0] dat;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      dat <= {WIDTH{1'b0}};
    end else begin
      dat <= datN;
    end
  end

  // Nextstate logic (kombinatorisch, alle vier Fälle belegt)
  always @(*) begin
    case (mode)
      NOP:   datN = dat;
      RIGHT: datN = {d[0], dat[WIDTH - 1 : 1]};
      LEFT:  datN = {dat[WIDTH - 2 : 0], d[WIDTH - 1]};
      LOAD:  datN = d;
    endcase
  end

  // Output logic
  assign q = dat;

endmodule
