-- Selbstpruefende Testbench fuer shiftReg (VHDL-93), N = 8:
--   1. Nach dem Reset: q = 0.
--   2. Gezielte Abschnitte: laden, halten, 8 x rechts schieben (serielle
--      Ausgabe an q(0), von oben kommen die Bits von d(0) nach), 8 x links
--      schieben (von unten kommen die Bits von d(7) nach).
--   3. 200 Takte mit pseudozufaelligem mode und d aus einem LFSR
--      (dieselbe Folge wie in der Verilog-Testbench).
-- In jedem Takt wird q gegen ein Referenzmodell geprueft. Eingaenge werden
-- an der fallenden Flanke gesetzt und eine fallende Flanke spaeter
-- geprueft. Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_shiftReg is
end tb_shiftReg;

architecture Test of tb_shiftReg is
  constant N : integer := 8;

  constant NOP   : std_logic_vector(1 downto 0) := "00";
  constant RIGHT : std_logic_vector(1 downto 0) := "01";
  constant LEFT  : std_logic_vector(1 downto 0) := "10";
  constant LOAD  : std_logic_vector(1 downto 0) := "11";

  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal mode  : std_logic_vector(1 downto 0) := NOP;
  signal d     : std_logic_vector(N - 1 downto 0) := (others => '0');
  signal q     : std_logic_vector(N - 1 downto 0);
  signal done  : boolean := false;

  function to_str(v : std_logic_vector) return string is
    variable s : string(1 to v'length);
    variable k : positive := 1;
  begin
    for i in v'range loop
      if v(i) = '1' then s(k) := '1'; else s(k) := '0'; end if;
      k := k + 1;
    end loop;
    return s;
  end function;
begin
  dut : entity work.shiftReg
    generic map (N => N)
    port map (clk => clk, reset => reset, mode => mode, d => d, q => q);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable expected : std_logic_vector(N - 1 downto 0);
    variable serial   : std_logic_vector(N - 1 downto 0);
    variable lfsr     : std_logic_vector(15 downto 0) := x"ACE1";
    variable nNop, nRight, nLeft, nLoad : natural := 0;

    -- Setzt mode und d, rechnet das Referenzmodell einen Takt weiter und
    -- prueft nach der naechsten steigenden Flanke.
    procedure step(m : std_logic_vector(1 downto 0);
                   dd : std_logic_vector(N - 1 downto 0)) is
    begin
      mode <= m; d <= dd;
      if m = NOP then
        nNop := nNop + 1;
      elsif m = RIGHT then
        expected := dd(0) & expected(N - 1 downto 1); nRight := nRight + 1;
      elsif m = LEFT then
        expected := expected(N - 2 downto 0) & dd(N - 1); nLeft := nLeft + 1;
      else
        expected := dd; nLoad := nLoad + 1;
      end if;
      wait until falling_edge(clk);
      assert q = expected
        report "FEHLER: q = " & to_str(q) & ", erwartet " & to_str(expected)
        severity failure;
    end procedure;
  begin
    -- 1. Reset ueber zwei steigende Flanken halten (dazu auf zwei fallende
    --    Flanken warten)
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    expected := (others => '0');
    assert q = expected report "FEHLER: nach Reset" severity failure;
    reset <= '0';

    -- 2. Gezielte Abschnitte
    step(LOAD, "10110010");                         -- laden
    for i in 1 to 3 loop step(NOP, x"FF"); end loop; -- halten
    serial := (others => '0');
    for i in 1 to N loop                            -- serialisieren, LSB zuerst
      serial := q(0) & serial(N - 1 downto 1);
      step(RIGHT, x"00");
    end loop;
    assert serial = "10110010"
      report "FEHLER: seriell ausgegeben " & to_str(serial) severity failure;
    for i in 1 to N loop step(LEFT, x"80"); end loop; -- mit Einsen fuellen
    report "ok: gezielte Abschnitte geprueft, q = " & to_str(q) severity note;

    -- 3. Pseudozufaelliger mode und d
    for i in 1 to 200 loop
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      step(lfsr(1 downto 0), lfsr(9 downto 2));
    end loop;
    report "ok: Takte: " & integer'image(nNop) & " halten, "
           & integer'image(nRight) & " rechts, "
           & integer'image(nLeft) & " links, "
           & integer'image(nLoad) & " laden" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
