-- Universelles Schieberegister aus Teil 5 (VHDL), teil5.typ, Folien
-- "Ein Schieberegister" (Entity) und "Ein Schieberegister (II)" (Architecture).
library ieee;
use ieee.std_logic_1164.all;

entity shiftReg is

  generic(N : integer := 8);

  port(clk   : in std_logic;
       reset : in std_logic;

       mode : in std_logic_vector(1 downto 0);

       d : in  std_logic_vector(N - 1 downto 0);
       q : out std_logic_vector(N - 1 downto 0));

end shiftReg;

architecture Behavioural of shiftReg is
signal dat_r, dat_n : std_logic_vector(N - 1 downto 0);
begin

  process (clk, reset)
  begin
    if (reset = '1') then
      dat_r <= (others => '0');
    elsif (rising_edge(clk)) then
      dat_r <= dat_n; -- Change state on rising edge
    end if;
  end process;

  with mode select -- next state logic (Aufzaehlungstypen erhoehen die Lesbarkeit!)
    dat_n <= dat_r when "00",                          -- NOP
             d(0) & dat_r(N - 1 downto 1) when "01",   -- Shift right
             dat_r(N - 2 downto 0) & d(N-1) when "10", -- Shift left
             d when others;                            -- Load

  q <= dat_r;  -- Output logic

end architecture;
