// Selbstprüfende Testbench für shiftreg, WIDTH = 8:
//   1. Nach dem Reset: q = 0.
//   2. Gezielte Abschnitte: laden, halten, 8 x rechts schieben (serielle
//      Ausgabe an q[0], von oben kommen die Bits von d[0] nach), 8 x links
//      schieben (von unten kommen die Bits von d[7] nach).
//   3. 200 Takte mit pseudozufälligem mode und d aus einem LFSR.
// In jedem Takt wird q gegen ein Referenzmodell geprüft. Eingänge werden an
// der fallenden Flanke gesetzt und eine fallende Flanke später geprüft.
// Ausgegeben werden nur die ersten 10 Fehler.

module tb_shiftreg;

  localparam W = 8;

  localparam NOP   = 2'b00,
             RIGHT = 2'b01,
             LEFT  = 2'b10,
             LOAD  = 2'b11;

  reg            clk   = 1'b0;
  reg            reset = 1'b1;
  reg  [1 : 0]   mode  = NOP;
  reg  [W-1 : 0] d     = 0;
  wire [W-1 : 0] q;
  reg  [W-1 : 0] expected;
  reg  [W-1 : 0] serial;               // seriell an q[0] ausgegebene Bits
  reg  [15 : 0]  lfsr  = 16'hACE1;
  integer        i;
  integer        n[0 : 3];
  integer        errors = 0;

  shiftreg #(.WIDTH(W)) dut (.q(q), .clk(clk), .reset(reset), .mode(mode), .d(d));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  task check;
    begin
      if (q !== expected) begin
        if (errors < 10)
          $display("FEHLER: t=%0t  mode=%b  q=%b  erwartet=%b", $time, mode, q, expected);
        errors = errors + 1;
      end
    end
  endtask

  // Setzt mode und d, rechnet das Referenzmodell einen Takt weiter und
  // prüft nach der nächsten steigenden Flanke.
  task step(input [1 : 0] m, input [W-1 : 0] dd);
    begin
      mode = m; d = dd;
      case (m)
        NOP:   expected = expected;
        RIGHT: expected = {dd[0], expected[W-1 : 1]};
        LEFT:  expected = {expected[W-2 : 0], dd[W-1]};
        LOAD:  expected = dd;
      endcase
      n[m] = n[m] + 1;
      @(negedge clk);
      check;
    end
  endtask

  initial begin
    $dumpfile("tb_shiftreg.vcd");         // läuft im Verzeichnis build/
    $dumpvars(0, tb_shiftreg);
    for (i = 0; i < 4; i = i + 1) n[i] = 0;

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten)
    @(negedge clk); @(negedge clk);
    expected = 0;
    check;
    reset = 1'b0;

    // 2. Gezielte Abschnitte
    step(LOAD, 8'b1011_0010);             // laden
    repeat (3) step(NOP, 8'hFF);          // halten, d wird ignoriert
    serial = 0;
    for (i = 0; i < W; i = i + 1) begin   // serialisieren, LSB zuerst
      serial = {q[0], serial[W-1 : 1]};
      step(RIGHT, 8'h00);
    end
    if (serial !== 8'b1011_0010) begin
      $display("FEHLER: seriell ausgegeben %b statt 10110010", serial);
      errors = errors + 1;
    end
    for (i = 0; i < W; i = i + 1)         // von unten mit Einsen füllen
      step(LEFT, 8'h80);
    $display("ok     gezielte Abschnitte geprueft, q=%b", q);

    // 3. Pseudozufälliger mode und d
    repeat (200) begin
      lfsr = {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      step(lfsr[1:0], lfsr[9:2]);
    end
    $display("ok     Takte: %0d halten, %0d rechts, %0d links, %0d laden",
             n[0], n[1], n[2], n[3]);

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
