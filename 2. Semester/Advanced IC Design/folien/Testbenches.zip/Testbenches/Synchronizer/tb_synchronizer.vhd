-- Selbstpruefende Testbench fuer Synchronizer (VHDL-93):
--   1. Asynchroner Reset: sync ist sofort 0, ohne Taktflanke.
--   2. 300 Takte, async wechselt zu pseudozufaelligen Zeitpunkten (LFSR),
--      auch nicht taktsynchron, aber nie genau auf der steigenden Flanke
--      (Setup-Verletzung, Wert nicht festgelegt). sync muss gleich dem Wert sein, den async
--      zwei steigende Flanken vorher hatte (Referenzmodell mit zwei
--      Registern). Metastabilitaet gibt es in der Simulation nicht.
--   3. Ein einzelner Wechsel von async erscheint nach genau zwei Flanken.
--   4. Reset mitten im Takt loescht den Ausgang sofort.
-- Geprueft wird an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_Synchronizer is
end tb_Synchronizer;

architecture Test of tb_Synchronizer is
  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal async : std_logic := '0';
  signal sync  : std_logic;
  signal m1    : std_logic := '0'; -- Referenzmodell
  signal m2    : std_logic := '0';
  signal done  : boolean := false;
begin
  dut : entity work.Synchronizer(TwoFF)
    port map (clk => clk, reset => reset, async => async, sync => sync);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  model : process(clk, reset)
  begin
    if reset = '1' then
      m1 <= '0';
      m2 <= '0';
    elsif rising_edge(clk) then
      m1 <= async;
      m2 <= m1;
    end if;
  end process;

  stimulus : process
    variable lfsr : std_logic_vector(15 downto 0) := x"ACE1";
    variable n    : integer;
    variable d    : integer;
  begin
    -- 1. Asynchroner Reset
    async <= '1';
    wait for 2 ns;
    assert sync = '0' report "FEHLER: sync nach Reset nicht 0" severity failure;
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    assert sync = '0' report "FEHLER: sync waehrend Reset nicht 0" severity failure;
    async <= '0';
    wait for 3 ns;
    reset <= '0';                       -- mitten im Takt loesen
    report "ok: asynchroner Reset" severity note;

    -- 2. Pseudozufaellige Wechsel
    for i in 1 to 300 loop
      -- 1..8 ns nach der fallenden Flanke, nicht taktsynchron. Nicht genau
      -- auf der steigenden Flanke (5 ns): Das waere eine Setup-Verletzung,
      -- der uebernommene Wert ist dann nicht festgelegt.
      d := 1 + to_integer(unsigned(lfsr(2 downto 0)));
      if d = 5 then
        d := 4;
      end if;
      wait for d * 1 ns;
      if lfsr(3) = '1' then
        async <= not async;
      end if;
      lfsr := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      wait until falling_edge(clk);
      assert sync = m2
        report "FEHLER bei zufaelligem async, Takt " & integer'image(i)
        severity failure;
    end loop;
    report "ok: 300 Takte mit zufaelligen Wechseln von async" severity note;

    -- 3. Latenz genau zwei Flanken
    async <= '0';
    for i in 1 to 3 loop
      wait until falling_edge(clk);
    end loop;
    async <= '1';
    n := 0;
    while sync /= '1' and n < 10 loop
      wait until falling_edge(clk);
      n := n + 1;
    end loop;
    assert n = 2
      report "FEHLER: Latenz " & integer'image(n) & " statt 2 Flanken"
      severity failure;
    report "ok: Latenz zwei Flanken" severity note;

    -- 4. Reset mitten im Takt
    wait for 2 ns;
    reset <= '1';
    wait for 1 ns;
    assert sync = '0' report "FEHLER: Reset mitten im Takt wirkt nicht sofort"
      severity failure;
    report "ok: Reset mitten im Takt wirkt sofort" severity note;
    wait until falling_edge(clk);
    reset <= '0';

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
