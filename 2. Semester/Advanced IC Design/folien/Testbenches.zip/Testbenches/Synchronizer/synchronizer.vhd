library ieee;
use ieee.std_logic_1164.all;

entity Synchronizer is
  port(clk   : in std_logic;
       reset : in std_logic;
       async : in std_logic;
       sync  : out std_logic);
end Synchronizer;

architecture TwoFF of Synchronizer is
  signal meta_reg, meta_next : std_logic;
  signal sync_reg, sync_next : std_logic;
begin
  process(clk, reset) -- Implementiere zwei Flip-Flops
  begin
    if (reset = '1') then
      meta_reg <= '0';
      sync_reg <= '0';
    elsif (rising_edge(clk)) then
      meta_reg <= meta_next;
      sync_reg <= sync_next;
    end if;
  end process;

  -- Next state logic
  meta_next <= async;
  sync_next <= meta_reg;

  -- Output logic
  sync <= sync_reg;
end architecture;
