module synchronizer
  (input  wire clk,
   input  wire reset,
   input  wire async,
   output wire sync);

  reg  metaR, syncR;
  wire metaN, syncN;

  // Implementiere zwei Flip-Flops
  always @(posedge clk or posedge reset) begin
    if (reset) begin // Asynchron reset
      metaR <= 1'b0;
      syncR <= 1'b0;
    end else begin
      metaR <= metaN;
      syncR <= syncN;
    end
  end

  // Next state logic
  assign metaN = async;
  assign syncN = metaR;

  // Output logic
  assign sync = syncR;

endmodule
