// Selbstpruefende Testbench fuer synchronizer:
//   1. Asynchroner Reset: sync ist sofort 0, ohne Taktflanke.
//   2. 300 Takte, async wechselt zu pseudozufaelligen Zeitpunkten (LFSR),
//      auch nicht taktsynchron, aber nie genau auf der steigenden Flanke
//      (Setup-Verletzung, Wert nicht festgelegt). sync muss gleich dem Wert sein, den async
//      zwei steigende Flanken vorher hatte (Referenzmodell mit zwei
//      Registern). Metastabilitaet gibt es in der Simulation nicht.
//   3. Ein einzelner Wechsel von async erscheint nach genau zwei Flanken.
//   4. Reset mitten im Takt loescht beide Flip-Flops sofort.
// Geprueft wird an der fallenden Flanke.

module tb_synchronizer;

  reg     clk   = 1'b0;
  reg     reset = 1'b1;
  reg     async = 1'b0;
  wire    sync;

  reg     m1 = 1'b0, m2 = 1'b0; // Referenzmodell
  reg     [15 : 0] lfsr = 16'hACE1;
  integer i, n, d, errors = 0;

  synchronizer dut (.clk(clk), .reset(reset), .async(async), .sync(sync));

  always #5 clk = ~clk;

  always @(posedge clk or posedge reset)
    if (reset) begin m1 <= 1'b0; m2 <= 1'b0; end
    else       begin m1 <= async; m2 <= m1; end

  task check(input [8*24 : 1] what);
    if (sync !== m2) begin
      $display("FEHLER (%0s): t=%0t  sync=%b  erwartet=%b", what, $time, sync, m2);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_synchronizer.vcd");     // laeuft im Verzeichnis build/
    $dumpvars(0, tb_synchronizer);

    // 1. Asynchroner Reset
    async = 1'b1;
    #2;
    if (sync !== 1'b0) begin
      $display("FEHLER: sync nach Reset %b statt 0", sync);
      errors = errors + 1;
    end
    @(negedge clk); @(negedge clk);
    if (sync !== 1'b0) begin
      $display("FEHLER: sync waehrend Reset %b statt 0", sync);
      errors = errors + 1;
    end
    async = 1'b0;
    #3 reset = 1'b0;                      // mitten im Takt loesen
    $display("ok     asynchroner Reset");

    // 2. Pseudozufaellige Wechsel
    for (i = 0; i < 300; i = i + 1) begin
      // 1..8 ns nach der fallenden Flanke, nicht taktsynchron. Nicht genau
      // auf der steigenden Flanke (5 ns): Das waere eine Setup-Verletzung,
      // der uebernommene Wert ist dann nicht festgelegt.
      d = 1 + lfsr[2 : 0];
      if (d == 5) d = 4;
      #(d);
      if (lfsr[3]) async = ~async;
      lfsr = {lfsr[14 : 0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      @(negedge clk);
      check("zufaellig");
    end
    $display("ok     300 Takte mit zufaelligen Wechseln von async");

    // 3. Latenz genau zwei Flanken
    async = 1'b0;
    repeat (3) @(negedge clk);
    async = 1'b1;
    n = 0;
    while (sync !== 1'b1 && n < 10) begin
      @(negedge clk);
      n = n + 1;
    end
    if (n != 2) begin
      $display("FEHLER: Latenz %0d statt 2 Flanken", n);
      errors = errors + 1;
    end else
      $display("ok     Latenz zwei Flanken");

    // 4. Reset mitten im Takt
    #2 reset = 1'b1;
    #1;
    if (sync !== 1'b0 || dut.metaR !== 1'b0) begin
      $display("FEHLER: Reset mitten im Takt wirkt nicht sofort");
      errors = errors + 1;
    end else
      $display("ok     Reset mitten im Takt wirkt sofort");
    @(negedge clk);
    reset = 1'b0;

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
