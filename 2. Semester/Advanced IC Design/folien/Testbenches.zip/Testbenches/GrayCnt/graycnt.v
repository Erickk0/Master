module graycnt

  #(parameter WIDTH = 5)

  (input  wire clk,
   input  wire reset,
   input  wire enable,
   output wire [WIDTH - 1 : 0] gval);

  wire [WIDTH - 1 : 0] valN;
  reg  [WIDTH - 1 : 0] val;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      val <= {WIDTH{1'b1}}; // Vorgänger von 0
    end else if (enable) begin
      val <= valN;
    end
  end

  // Nextstate logic
  assign valN = val + 1;

  // Gray-Code: g(k) = k xor k/2
  assign gval = val ^ (val >> 1);

endmodule
