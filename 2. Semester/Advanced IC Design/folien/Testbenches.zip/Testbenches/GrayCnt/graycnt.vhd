library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity GrayCnt is

  generic(width : integer := 5);

  port (clk    : in  std_logic;
        reset  : in  std_logic;
        enable : in  std_logic;
        gval   : out std_logic_vector(width - 1 downto 0));

end GrayCnt;

architecture BinConv of GrayCnt is
  signal val_reg  : std_logic_vector(width - 1 downto 0);
  signal val_next : std_logic_vector(width - 1 downto 0);
begin

  state_logic : process (clk)
  begin
    if (rising_edge(clk)) then

      -- Synchron reset
      if(reset = '1') then

        -- Set binary counter to the predecessor of 0
        val_reg <= (others => '1');

      else

        -- Check if counter is enabled
        if (enable = '1') then

          -- Set value on rising edge
          val_reg <= val_next;

        end if;
      end if;
    end if;
  end process;

  -- Next state logic
  val_next <= std_logic_vector(unsigned(val_reg) + 1);

  -- Convert to Gray-Code as output (note: g(k) = k xor k/2)
  gval <= val_reg xor ("0" & val_reg(width - 1 downto 1));

end architecture;
