-- Selbstpruefende Testbench fuer GrayCnt (VHDL-93, width = 5):
--   1. Reset ueber zwei Flanken halten: der Binaerzaehler steht auf dem
--      Vorgaenger von 0, gval = g(31) = 10000.
--   2. 200 Takte mit zufaelligem enable (LFSR): gval wird mit einem
--      Referenzmodell g(k) = k xor k/2 verglichen. Zusaetzlich gilt: mit
--      enable aendert sich genau ein Bit, ohne enable keines.
--   3. Ein voller Durchlauf mit enable = 1 liefert alle 32 Codewoerter
--      genau einmal.
--   4. Synchroner Reset: wirkt erst mit der naechsten Taktflanke.
-- Stimuli werden an der fallenden Flanke gesetzt und geprueft. Ein Fehler
-- beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_GrayCnt is
end tb_GrayCnt;

architecture Test of tb_GrayCnt is
  constant W : integer := 5;

  signal clk    : std_logic := '0';
  signal reset  : std_logic := '1';
  signal enable : std_logic := '0';
  signal gval   : std_logic_vector(W - 1 downto 0);
  signal done   : boolean := false;

  function gray(b : unsigned) return std_logic_vector is
  begin
    return std_logic_vector(b xor shift_right(b, 1));
  end function;

  function ones(v : std_logic_vector) return integer is
    variable n : integer := 0;
  begin
    for j in v'range loop
      if v(j) = '1' then
        n := n + 1;
      end if;
    end loop;
    return n;
  end function;
begin
  dut : entity work.GrayCnt
    generic map (width => W)
    port map (clk => clk, reset => reset, enable => enable, gval => gval);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable k    : unsigned(W - 1 downto 0);
    variable last : std_logic_vector(W - 1 downto 0);
    variable lfsr : std_logic_vector(15 downto 0) := x"ACE1";
    variable seen : std_logic_vector(2**W - 1 downto 0);
    variable en   : std_logic;
    variable exp1 : integer;
  begin
    -- 1. Reset
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    k := (others => '1');
    assert gval = gray(k) report "FEHLER: nach Reset" severity failure;
    reset <= '0';

    -- 2. Zufaelliges enable
    for i in 1 to 200 loop
      en     := lfsr(0);
      enable <= en;
      lfsr   := lfsr(14 downto 0) & (lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));
      last   := gval;
      wait until falling_edge(clk);
      if en = '1' then
        k    := k + 1;
        exp1 := 1;
      else
        exp1 := 0;
      end if;
      assert gval = gray(k)
        report "FEHLER bei zufaelligem enable, Takt " & integer'image(i)
        severity failure;
      assert ones(gval xor last) = exp1
        report "FEHLER: Hammingdistanz falsch, Takt " & integer'image(i)
        severity failure;
    end loop;
    report "ok: 200 Takte mit zufaelligem enable, je genau ein Bit geaendert"
      severity note;

    -- 3. Voller Durchlauf
    enable <= '1';
    seen   := (others => '0');
    for i in 1 to integer(2**W) loop
      wait until falling_edge(clk);
      k := k + 1;
      assert gval = gray(k)
        report "FEHLER im Durchlauf, Schritt " & integer'image(i)
        severity failure;
      seen(to_integer(unsigned(gval))) := '1';
    end loop;
    assert seen = (seen'range => '1')
      report "FEHLER: nicht alle Codewoerter gesehen" severity failure;
    report "ok: alle Codewoerter in einem Durchlauf" severity note;

    -- 4. Synchroner Reset
    wait for 1 ns;
    reset <= '1';
    wait for 1 ns;
    assert gval = gray(k) report "FEHLER: Reset vor Flanke" severity failure;
    wait until falling_edge(clk);
    k := (others => '1');
    assert gval = gray(k) report "FEHLER: Reset nach Flanke" severity failure;
    reset <= '0';
    wait until falling_edge(clk);
    assert unsigned(gval) = 0
      report "FEHLER: erster Wert nach Reset nicht 0" severity failure;
    report "ok: synchroner Reset, danach beginnt die Folge bei 0" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
