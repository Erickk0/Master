// Selbstpruefende Testbench fuer graycnt (WIDTH = 5):
//   1. Reset ueber zwei Flanken halten: der Binaerzaehler steht auf dem
//      Vorgaenger von 0, gval = g(31) = 10000.
//   2. 200 Takte mit zufaelligem enable (LFSR): gval wird mit einem
//      Referenzmodell g(k) = k xor k/2 verglichen. Zusaetzlich gilt: mit
//      enable aendert sich genau ein Bit, ohne enable keines.
//   3. Ein voller Durchlauf mit enable = 1 liefert alle 32 Codewoerter
//      genau einmal.
//   4. Synchroner Reset: wirkt erst mit der naechsten Taktflanke.
// Stimuli werden an der fallenden Flanke gesetzt und geprueft.

module tb_graycnt;

  localparam W = 5;

  reg            clk    = 1'b0;
  reg            reset  = 1'b1;
  reg            enable = 1'b0;
  wire [W-1 : 0] gval;

  reg  [W-1 : 0] k;            // Referenzmodell: Binaerzaehler
  reg  [W-1 : 0] last;         // gval im vorigen Takt
  reg  [15 : 0]  lfsr = 16'hACE1;
  reg  [(1<<W)-1 : 0] seen;    // bereits gesehene Codewoerter
  integer        i, errors = 0;

  graycnt #(.WIDTH(W)) dut (.clk(clk), .reset(reset), .enable(enable), .gval(gval));

  always #5 clk = ~clk;

  function [W-1 : 0] gray(input [W-1 : 0] b);
    gray = b ^ (b >> 1);
  endfunction

  function integer ones(input [W-1 : 0] v);
    integer j;
    begin
      ones = 0;
      for (j = 0; j < W; j = j + 1) ones = ones + v[j];
    end
  endfunction

  task check(input [8*24 : 1] what);
    if (gval !== gray(k)) begin
      $display("FEHLER (%0s): t=%0t  gval=%b  erwartet=%b", what, $time, gval, gray(k));
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_graycnt.vcd");          // laeuft im Verzeichnis build/
    $dumpvars(0, tb_graycnt);

    // 1. Reset
    @(negedge clk); @(negedge clk);
    k = {W{1'b1}};
    check("nach Reset");
    reset = 1'b0;

    // 2. Zufaelliges enable
    for (i = 0; i < 200; i = i + 1) begin
      enable = lfsr[0];
      lfsr   = {lfsr[14 : 0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      last   = gval;
      @(negedge clk);
      if (enable) k = k + 1;
      check("enable zufaellig");
      if (ones(gval ^ last) != (enable ? 1 : 0)) begin
        $display("FEHLER (Hamming): t=%0t  %b -> %b  enable=%b", $time, last, gval, enable);
        errors = errors + 1;
      end
    end
    $display("ok     200 Takte mit zufaelligem enable, je genau ein Bit geaendert");

    // 3. Voller Durchlauf
    enable = 1'b1;
    seen   = 0;
    for (i = 0; i < (1 << W); i = i + 1) begin
      @(negedge clk);
      k = k + 1;
      check("Durchlauf");
      seen[gval] = 1'b1;
    end
    if (~&seen) begin
      $display("FEHLER: nicht alle %0d Codewoerter gesehen: %b", 1 << W, seen);
      errors = errors + 1;
    end else
      $display("ok     alle %0d Codewoerter in einem Durchlauf", 1 << W);

    // 4. Synchroner Reset
    #1 reset = 1'b1;
    #1 check("Reset vor Flanke");
    @(negedge clk);
    k = {W{1'b1}};
    check("Reset nach Flanke");
    reset = 1'b0;
    @(negedge clk);
    k = k + 1;
    check("erster Wert nach Reset");
    if (gval !== 0) begin
      $display("FEHLER: erster Wert nach Reset %b statt 0", gval);
      errors = errors + 1;
    end
    $display("ok     synchroner Reset, danach beginnt die Folge bei 0");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
