// Selbstprüfende Testbench für nextcnt, WIDTH = 4:
//   1. Während des Resets ist das Register 0, die Ausgabe zeigt aber schon
//      den Folgewert 1 (die Ausgabe hängt am Addierer, nicht am Register).
//   2. 40 Takte zählen (mit Überlauf). Die Ausgabe muss in jedem Takt dem
//      Registerwert des Referenzmodells plus 1 entsprechen, also dem Wert,
//      den ein normaler Zähler (freecnt) erst einen Takt später zeigt.
// Geprüft wird immer an der fallenden Flanke, damit es keine Races gibt.

module tb_nextcnt;

  localparam W = 4;

  reg            clk   = 1'b0;
  reg            reset = 1'b1;
  wire [W-1 : 0] value;
  reg  [W-1 : 0] regval;                // Modell des Zustandsregisters
  integer        cycle;
  integer        errors = 0;

  nextcnt #(.WIDTH(W)) dut (.value(value), .clk(clk), .reset(reset));

  // Alle 5 Zeiteinheiten umschalten, damit ist die Periode 10 Zeiteinheiten.
  always #5 clk = ~clk;

  // Die Ausgabe muss dem Folgezustand regval + 1 entsprechen.
  task check;
    reg [W-1 : 0] exp;
    begin
      exp = regval + 1;
      if (value !== exp) begin
        $display("FEHLER: t=%0t  value=%0d  erwartet=%0d (Register=%0d)",
                 $time, value, exp, regval);
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_nextcnt.vcd");          // läuft im Verzeichnis build/
    $dumpvars(0, tb_nextcnt);

    // 1. Reset über zwei steigende Flanken halten (dazu auf zwei fallende
    //    Flanken warten); value zeigt dabei schon 1
    @(negedge clk); @(negedge clk);
    regval = 0;
    check;
    $display("ok     waehrend des Resets: value=%0d", value);
    reset = 1'b0;

    // 2. Zählen
    for (cycle = 1; cycle <= 40; cycle = cycle + 1) begin
      @(negedge clk);
      regval = regval + 1;
      check;
    end
    $display("ok     40 Takte: value war immer einen Takt voraus");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
