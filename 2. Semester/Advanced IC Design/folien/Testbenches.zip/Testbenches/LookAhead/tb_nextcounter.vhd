-- Selbstpruefende Testbench fuer nextCounter (VHDL-93), N = 4:
--   1. Waehrend des Resets ist das Register 0, die Ausgabe zeigt aber schon
--      den Folgewert 1 (die Ausgabe haengt am Addierer, nicht am Register).
--   2. 40 Takte zaehlen (mit Ueberlauf). Die Ausgabe muss in jedem Takt dem
--      Registerwert des Referenzmodells plus 1 entsprechen, also dem Wert,
--      den ein normaler Zaehler erst einen Takt spaeter zeigt.
-- Geprueft wird immer an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_nextCounter is
end tb_nextCounter;

architecture Test of tb_nextCounter is
  constant N : integer := 4;

  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal value : std_logic_vector(N - 1 downto 0);
  signal done  : boolean := false;
begin
  dut : entity work.nextCounter
    generic map (N => N)
    port map (clk => clk, reset => reset, value => value);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable regval : unsigned(N - 1 downto 0);  -- Modell des Registers
  begin
    -- 1. Reset ueber zwei steigende Flanken halten (dazu auf zwei fallende
    --    Flanken warten); value zeigt dabei schon 1
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    regval := (others => '0');
    assert unsigned(value) = regval + 1
      report "FEHLER: waehrend des Resets" severity failure;
    report "ok: waehrend des Resets: value = "
           & integer'image(to_integer(unsigned(value))) severity note;
    reset <= '0';

    -- 2. Zaehlen
    for i in 1 to 40 loop
      wait until falling_edge(clk);
      regval := regval + 1;
      assert unsigned(value) = regval + 1
        report "FEHLER bei Takt " & integer'image(i) & ": value = "
               & integer'image(to_integer(unsigned(value)))
        severity failure;
    end loop;
    report "ok: 40 Takte, value war immer einen Takt voraus" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
