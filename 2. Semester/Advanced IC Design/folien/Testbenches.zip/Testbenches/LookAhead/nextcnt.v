// Binärzähler, der seinen Wert einen Takt früher ausgibt
// (teil5.typ, Folie "Ein Blick in die Zukunft"): wie freecnt, aber die
// Ausgabe ist der Folgezustand valN statt des Registers val.
module nextcnt (value, clk, reset);

  parameter WIDTH = 8;

  input  wire clk;
  input  wire reset;
  output wire [WIDTH - 1 : 0] value;

  wire [WIDTH - 1 : 0] valN;
  reg  [WIDTH - 1 : 0] val;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      val <= {WIDTH{1'b0}};
    end else begin
      val <= valN;
    end
  end

  // Nextstate logic
  assign valN = val + 1;

  // Output logic (statt value = val)
  assign value = valN;

endmodule
