// Selbstpruefende Testbench fuer orn (WIDTH = 8): alle 256 Eingaben,
// res = 1 genau dann, wenn src != 0.
module tb_orn;

  reg  [7 : 0] src;
  wire         res;
  integer      i, errors = 0;

  orn #(.WIDTH(8)) dut (.src(src), .res(res));

  initial begin
    $dumpfile("tb_orn.vcd");              // laeuft im Verzeichnis build/
    $dumpvars(0, tb_orn);
    for (i = 0; i < 256; i = i + 1) begin
      src = i;
      #1;
      if (res !== (src != 0)) begin
        $display("FEHLER: src=%b res=%b", src, res);
        errors = errors + 1;
      end
    end
    $display("ok     alle 256 Eingaben");
    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
