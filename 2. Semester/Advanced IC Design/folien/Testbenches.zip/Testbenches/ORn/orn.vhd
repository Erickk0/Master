-- ORn: or ueber alle Bits mit einer Schleife im Prozess (teil9.typ, Folie
-- "Eine Bemerkung zu HasOne")
library ieee;
use ieee.std_logic_1164.all;

entity ORn is
generic(width : natural := 8);
port(src : in std_logic_vector(width - 1 downto 0);
     res : out std_logic);
end entity;
architecture Behavioral of ORn is
begin

  genOr : process (src)
    variable tmp : std_logic;
  begin

    tmp := '0';
    for i in src'range loop
      tmp := tmp or src(i);
    end loop;

    res <= tmp;

  end process;
end architecture;
