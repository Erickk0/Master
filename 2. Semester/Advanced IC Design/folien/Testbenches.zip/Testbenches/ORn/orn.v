// ORn: or ueber alle Bits mit einer Schleife im always-Block (teil9.typ,
// Folie "Eine Bemerkung zu HasOne")
module orn
  #(parameter WIDTH = 8)
   (input  wire [WIDTH - 1 : 0] src,
    output reg                  res);

  integer i;

  always @(*) begin
    res = 1'b0;
    for (i = 0; i < WIDTH; i = i + 1)
      res = res | src[i];
  end

endmodule
