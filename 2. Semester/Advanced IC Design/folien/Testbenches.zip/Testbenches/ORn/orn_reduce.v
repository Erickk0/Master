// ORn mit dem Reduktionsoperator | (teil9.typ, Folie "Eine Bemerkung zu
// HasOne", Hinweis unter dem Code)
module orn
  #(parameter WIDTH = 8)
   (input  wire [WIDTH - 1 : 0] src,
    output wire                 res);

  assign res = |src;

endmodule
