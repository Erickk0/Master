-- Selbstpruefende Testbench fuer ORn (VHDL-93, width = 8): alle 256
-- Eingaben, res = '1' genau dann, wenn src /= 0.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_ORn is
end tb_ORn;

architecture Test of tb_ORn is
  signal src : std_logic_vector(7 downto 0);
  signal res : std_logic;
begin
  dut : entity work.ORn
    generic map (width => 8)
    port map (src => src, res => res);

  stimulus : process
  begin
    for i in 0 to 255 loop
      src <= std_logic_vector(to_unsigned(i, 8));
      wait for 1 ns;
      if i = 0 then
        assert res = '0' report "FEHLER bei src = 0" severity failure;
      else
        assert res = '1' report "FEHLER bei src = " & integer'image(i) severity failure;
      end if;
    end loop;
    report "ok: alle 256 Eingaben" severity note;
    report "PASS" severity note;
    wait;
  end process;
end Test;
