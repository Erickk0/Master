-- Selbstpruefende Testbench fuer RCAdder (VHDL-93, width = 6): alle
-- 2^13 = 8192 Kombinationen von a, b und cin gegen a + b + cin.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_RCAdder is
end tb_RCAdder;

architecture Test of tb_RCAdder is
  constant W : integer := 6;
  constant N : integer := 2**(2 * W + 1);  -- Anzahl der Kombinationen
  signal a, b : std_logic_vector(W - 1 downto 0);
  signal cin  : std_logic;
  signal s    : std_logic_vector(W - 1 downto 0);
  signal cout : std_logic;
begin
  dut : entity work.RCAdder
    generic map (width => W)
    port map (a => a, b => b, cin => cin, s => s, cout => cout);

  stimulus : process
    variable v : unsigned(2 * W downto 0);
  begin
    for i in 0 to N - 1 loop
      v   := to_unsigned(i, 2 * W + 1);
      a   <= std_logic_vector(v(2 * W downto W + 1));
      b   <= std_logic_vector(v(W downto 1));
      cin <= v(0);
      wait for 1 ns;
      assert to_integer(unsigned(cout & s)) = to_integer(v(2 * W downto W + 1))
                                              + to_integer(v(W downto 1))
                                              + to_integer(v(0 downto 0))
        report "FEHLER bei Eingabe " & integer'image(i) severity failure;
    end loop;
    report "ok: alle " & integer'image(N) & " Kombinationen" severity note;
    report "PASS" severity note;
    wait;
  end process;
end Test;
