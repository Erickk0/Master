// Selbstpruefende Testbench fuer rcadder (WIDTH = 6): alle 2^13 = 8192
// Kombinationen von a, b und cin gegen a + b + cin.
module tb_rcadder;

  localparam W = 6;

  reg  [W - 1 : 0] a, b;
  reg              cin;
  wire [W - 1 : 0] s;
  wire             cout;
  integer          i, errors = 0;

  rcadder #(.WIDTH(W)) dut (.a(a), .b(b), .cin(cin), .s(s), .cout(cout));

  initial begin
    $dumpfile("tb_rcadder.vcd");          // laeuft im Verzeichnis build/
    $dumpvars(0, tb_rcadder);
    for (i = 0; i < (1 << (2 * W + 1)); i = i + 1) begin
      {a, b, cin} = i;
      #1;
      if ({cout, s} !== a + b + cin) begin
        if (errors < 10)
          $display("FEHLER: %0d + %0d + %0d = %0d", a, b, cin, {cout, s});
        errors = errors + 1;
      end
    end
    $display("ok     alle %0d Kombinationen", 1 << (2 * W + 1));
    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
