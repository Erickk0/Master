// Halbaddierer (teil9.typ, Folie "Ein Halbaddierer in Verilog")
module halfadder
  (input  wire a,
   input  wire b,
   output wire s,
   output wire cout);

  assign s    = a ^ b;   // Calculate the sum
  assign cout = a & b;   // Calculate the overflow

endmodule
