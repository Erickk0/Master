// Generischer Ripple-Carry-Addierer mit generate-for (teil9.typ, Folien
// "Ein generischer Ripple-Carry Addierer in Verilog" und "(II)")
module rcadder
  #(parameter WIDTH = 6)
   (input  wire [WIDTH - 1 : 0] a,
    input  wire [WIDTH - 1 : 0] b,
    input  wire                 cin,
    output wire [WIDTH - 1 : 0] s,
    output wire                 cout);

  wire [WIDTH : 0] carry;

  // Generate an array of full adders
  genvar i;
  generate
    for (i = 0; i < WIDTH; i = i + 1) begin : adders
      // Generate the ith full adder
      fulladder adder (.a(a[i]), .b(b[i]), .cin(carry[i]),
                       .s(s[i]), .cout(carry[i + 1]));
    end
  endgenerate

  assign carry[0] = cin;
  assign cout     = carry[WIDTH];

endmodule
