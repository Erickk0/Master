// Volladdierer aus zwei Halbaddierern (teil9.typ, Folie "Ein Volladdierer
// in Verilog")
module fulladder
  (input  wire a,
   input  wire b,
   input  wire cin,
   output wire s,
   output wire cout);

  wire sum1, carry1, carry2;

  halfadder adder1 (.a(a),    .b(b),   .s(sum1), .cout(carry1));
  halfadder adder2 (.a(sum1), .b(cin), .s(s),    .cout(carry2));

  // Generate full-adder carry
  assign cout = carry1 | carry2;

endmodule
