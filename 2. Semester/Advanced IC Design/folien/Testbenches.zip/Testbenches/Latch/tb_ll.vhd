-- Selbstpruefende Testbench fuer LL (Vergleicher: eq = (a = b), gt = (a > b)).
-- Es werden alle 16 Uebergaenge zwischen den vier Eingabekombinationen
-- durchlaufen, also auch solche, bei denen sich nur b aendert. Eine
-- unvollstaendige Sensitivitaetsliste oder ein Latch faellt dadurch auf.
-- Mit ll_fixed.vhd endet die Simulation mit PASS, mit ll.vhd (absichtlich
-- falsch) mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_LL is
end tb_LL;

architecture Test of tb_LL is
  signal a, b   : std_logic := '0';
  signal eq, gt : std_logic;
begin
  dut : entity work.LL port map (a => a, b => b, eq => eq, gt => gt);

  stimulus : process
    procedure apply(ab : natural) is
      variable v      : std_logic_vector(1 downto 0);
      variable expEq  : std_logic;
      variable expGt  : std_logic;
    begin
      v := std_logic_vector(to_unsigned(ab, 2));
      a <= v(1); b <= v(0);
      wait for 10 ns;
      if v(1) = v(0) then expEq := '1'; else expEq := '0'; end if;
      if v(1) = '1' and v(0) = '0' then expGt := '1'; else expGt := '0'; end if;
      assert eq = expEq and gt = expGt
        report "FEHLER: a=" & std_logic'image(a) & " b=" & std_logic'image(b)
               & " eq=" & std_logic'image(eq) & " gt=" & std_logic'image(gt)
        severity failure;
    end procedure;
  begin
    for f in 0 to 3 loop
      for t in 0 to 3 loop
        apply(f);
        apply(t);
      end loop;
    end loop;
    report "PASS" severity note;
    wait;
  end process;
end architecture;
