// Latch-Beispiel, korrigiert nach dem Kochrezept (teil5.typ, Folie
// "Beispiel: Latches"): vollständige Sensitivitätsliste mit @(*) und
// Defaultwerte, damit jedes Signal in jedem Zweig einen Wert bekommt.
module ll (input  wire a, b,
           output reg  eq, gt);

  always @(*) begin  // vollständig
    eq = 1'b0;       // Defaultwerte
    gt = 1'b0;
    if (a > b)
      gt = 1'b1;
    else if (a == b)
      eq = 1'b1;
  end

endmodule
