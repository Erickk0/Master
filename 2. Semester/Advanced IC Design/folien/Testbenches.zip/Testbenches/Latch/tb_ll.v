// Selbstprüfende Testbench für ll (Vergleicher: eq = (a == b), gt = (a > b)).
// Es werden alle 16 Übergänge zwischen den vier Eingabekombinationen
// durchlaufen, also auch solche, bei denen sich nur b ändert. Eine
// unvollständige Sensitivitätsliste oder ein Latch fällt dadurch auf.
// Mit ll_fixed.v muss PASS herauskommen, mit ll.v (absichtlich falsch) FAIL.

module tb_ll;

  reg     a, b;
  wire    eq, gt;
  integer from, to;
  integer errors = 0;

  ll dut (.a(a), .b(b), .eq(eq), .gt(gt));

  task apply(input [1 : 0] ab);
    begin
      {a, b} = ab;
      #10;
      if (eq !== (a == b) || gt !== (a > b)) begin
        $display("FEHLER: a=%b b=%b  eq=%b gt=%b  erwartet eq=%b gt=%b",
                 a, b, eq, gt, a == b, a > b);
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_ll.vcd");               // läuft im Verzeichnis build/
    $dumpvars(0, tb_ll);

    for (from = 0; from < 4; from = from + 1)
      for (to = 0; to < 4; to = to + 1) begin
        apply(from);
        apply(to);
      end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
