-- Latch-Beispiel aus Teil 5 (VHDL), teil5.typ, Folie "Beispiel: Latches".
-- Absichtlich falsch: unvollstaendige Sensitivitaetsliste, fehlende
-- Zuweisungen, kein else-Zweig.
library ieee;
use ieee.std_logic_1164.all;

entity LL is
  port(a : in std_logic;
       b : in std_logic;

       eq : out std_logic;
       gt : out std_logic);
end LL;

architecture Behavioral of LL is
begin
  process (a) -- b fehlt in der Sensitivitaetsliste
  begin
    if (a > b) then -- eq bekommt keinen Wert
      gt <= '1';
    elsif (a = b) then -- gt bekommt keinen Wert
      eq <= '1';
    end if; -- Es gibt keinen else-Zweig
  end process;
end architecture;
