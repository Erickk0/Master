// Latch-Beispiel (teil5.typ, Folie "Beispiel: Latches"), absichtlich falsch:
// gleiche Fehler wie das VHDL-Beispiel LL aus teil5.typ.
module ll (input  wire a, b,
           output reg  eq, gt);

  always @(a) begin  // b fehlt
    if (a > b)       // eq fehlt
      gt = 1'b1;
    else if (a == b) // gt fehlt
      eq = 1'b1;
    // hier fehlt else
  end

endmodule
