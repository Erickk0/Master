-- Latch-Beispiel LL, korrigiert nach dem Kochrezept aus teil5.typ:
-- vollstaendige Sensitivitaetsliste und Defaultwerte.
library ieee;
use ieee.std_logic_1164.all;

entity LL is
  port(a : in std_logic;
       b : in std_logic;

       eq : out std_logic;
       gt : out std_logic);
end LL;

architecture Behavioral of LL is
begin
  process (a, b) -- vollstaendige Sensitivitaetsliste
  begin
    eq <= '0';   -- Defaultwerte
    gt <= '0';
    if (a > b) then
      gt <= '1';
    elsif (a = b) then
      eq <= '1';
    end if;
  end process;
end architecture;
