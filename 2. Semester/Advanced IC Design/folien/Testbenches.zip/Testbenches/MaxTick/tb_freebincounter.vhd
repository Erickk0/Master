-- Selbstpruefende Testbench fuer freeBinCounter mit maxTick (VHDL-93), N = 4,
-- damit der Ueberlauf oft vorkommt:
--   1. Nach dem Reset: value = 0, maxTick = 0.
--   2. 40 Takte zaehlen. In jedem Takt muss maxTick genau dann 1 sein, wenn
--      value = 15 ist, also im letzten Takt vor dem Ueberlauf.
--   3. In 40 Takten ab 0 kommt maxTick genau zweimal (bei Takt 15 und 31).
-- Geprueft wird immer an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_freeBinCounter is
end tb_freeBinCounter;

architecture Test of tb_freeBinCounter is
  constant N : integer := 4;

  signal clk     : std_logic := '0';
  signal reset   : std_logic := '1';
  signal value   : std_logic_vector(N - 1 downto 0);
  signal maxTick : std_logic;
  signal done    : boolean := false;
begin
  dut : entity work.freeBinCounter
    generic map (N => N)
    port map (clk => clk, reset => reset, value => value, maxTick => maxTick);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable expected : unsigned(N - 1 downto 0);
    variable tick     : std_logic;
    variable ticks    : natural := 0;
  begin
    -- 1. Reset ueber zwei steigende Flanken halten
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    assert unsigned(value) = 0 and maxTick = '0'
      report "FEHLER: nach Reset" severity failure;
    reset    <= '0';
    expected := (others => '0');

    -- 2. Zaehlen, maxTick in jedem Takt pruefen
    for i in 1 to 40 loop
      wait until falling_edge(clk);
      expected := expected + 1;
      if expected = 2**N - 1 then tick := '1'; else tick := '0'; end if;
      assert unsigned(value) = expected and maxTick = tick
        report "FEHLER bei Takt " & integer'image(i)
        severity failure;
      if maxTick = '1' then
        ticks := ticks + 1;
        report "ok: maxTick bei Takt " & integer'image(i) severity note;
      end if;
    end loop;

    -- 3. Anzahl der Ticks
    assert ticks = 2
      report "FEHLER: " & integer'image(ticks) & " statt 2 Ticks"
      severity failure;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
