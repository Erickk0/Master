// Selbstprüfende Testbench für tickcnt (beide Varianten), WIDTH = 4, damit
// der Überlauf oft vorkommt:
//   1. Nach dem Reset: value = 0, maxTick = 0.
//   2. 40 Takte zählen. In jedem Takt muss maxTick genau dann 1 sein, wenn
//      value = 15 ist, also im letzten Takt vor dem Überlauf.
//   3. In 40 Takten ab 0 kommt maxTick genau zweimal (bei Takt 15 und 31),
//      jeweils für einen Takt.
// Geprüft wird immer an der fallenden Flanke, damit es keine Races gibt.

module tb_tickcnt;

  localparam W = 4;

  reg            clk   = 1'b0;
  reg            reset = 1'b1;
  wire [W-1 : 0] value;
  wire           maxTick;
  reg  [W-1 : 0] expected;
  integer        cycle;
  integer        ticks  = 0;
  integer        errors = 0;

  tickcnt #(.WIDTH(W)) dut (.value(value), .maxTick(maxTick),
                            .clk(clk), .reset(reset));

  // Toggle alle fünf clocks. Damit ist die Periode zehn clocks.
  always #5 clk = ~clk;

  // Ein "Unterprogramm", das an verschiedenen Stellen die Richtigkeit des Codes checkt.
  task check;
    begin
      if (value !== expected || maxTick !== (expected == {W{1'b1}})) begin
        $display("FEHLER: t=%0t  value=%0d  maxTick=%b  erwartet value=%0d  maxTick=%b",
                 $time, value, maxTick, expected, expected == {W{1'b1}});
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_tickcnt.vcd");          // läuft im Verzeichnis build/
    $dumpvars(0, tb_tickcnt);             // 0 == alles von tb_tickcnt aufzeichnen

    // 1. Genau noch eine Flanke abwarten (== Reset über zwei steigende Flanken halten)
    @(negedge clk); @(negedge clk);
    expected = 0;
    check;
    reset = 1'b0;

    // 2. Zählen, maxTick in jedem Takt prüfen
    for (cycle = 1; cycle <= 40; cycle = cycle + 1) begin
      @(negedge clk);
      expected = expected + 1;
      check;
      if (maxTick === 1'b1) begin
        ticks = ticks + 1;
        $display("ok     maxTick bei Takt %0d (value=%0d)", cycle, value);
      end
    end

    // 3. Anzahl der Ticks
    if (ticks != 2) begin
      $display("FEHLER: %0d statt 2 Ticks in 40 Takten", ticks);
      errors = errors + 1;
    end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
