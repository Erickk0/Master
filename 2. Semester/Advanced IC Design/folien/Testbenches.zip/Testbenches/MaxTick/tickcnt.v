// Frei laufender Binärzähler mit Überlauf-Flag maxTick
// (teil5.typ, Folie "Ein Binärzähler mit Überlauf-Flag").
// freecnt aus "Ein Binärzähler", ergänzt um den Ausgang maxTick.
module tickcnt (value, maxTick, clk, reset);

  parameter WIDTH = 8;

  input  wire clk;
  input  wire reset;
  output wire [WIDTH - 1 : 0] value;
  output wire maxTick;

  wire [WIDTH - 1 : 0] valN;
  reg  [WIDTH - 1 : 0] val;

  always @(posedge clk) begin
    if (reset) begin // Synchron reset
      val <= {WIDTH{1'b0}};
    end else begin
      val <= valN;
    end
  end

  assign valN = val + 1; // Nextstate logic
  assign value = val;    // Output logic
  assign maxTick = (val == {WIDTH{1'b1}}) ? 1'b1 : 1'b0;

endmodule
