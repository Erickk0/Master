-- 5-Bit-Multiplizierer mit Pipeline (teil14.typ). Die Folien zeigen nur
-- einen Ausschnitt; dies ist die vollstaendige Fassung im selben Stil.
-- Stage 0 und 1 sind rein kombinatorisch (keine Register dazwischen), nach
-- Stage 1, 2, 3 und 4 liegen Pipelineregister. Latenz: 4 Takte.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity PMult is
  port (clk   : in std_logic;
        reset : in std_logic;
        a     : in  std_logic_vector(4 downto 0);
        b     : in  std_logic_vector(4 downto 0);
        c     : out std_logic_vector(9 downto 0));
end entity;

architecture Behavioral of PMult is

  -- Vector version of ith bit of b
  signal b0Vect, b1Vect, b2Vect, b3Vect, b4Vect : std_logic_vector(4 downto 0);

  -- The ith bit-product
  signal bitProd0, bitProd1, bitProd2, bitProd3, bitProd4 : unsigned(9 downto 0);

  -- Registers for the copies of the input
  signal a1_reg, a2_reg, a3_reg : std_logic_vector(4 downto 0);
  signal b1_reg, b2_reg, b3_reg : std_logic_vector(4 downto 0);
  signal partProd1_reg, partProd2_reg, partProd3_reg,
         partProd4_reg : unsigned(9 downto 0);

  -- Inputs for the pipeline registers
  signal a1_next, a2_next, a3_next : std_logic_vector(4 downto 0);
  signal b1_next, b2_next, b3_next : std_logic_vector(4 downto 0);
  signal partProd1_next, partProd2_next, partProd3_next,
         partProd4_next : unsigned(9 downto 0);

begin

  pipeline : process (clk)
  begin

    if (rising_edge(clk)) then

      if (reset = '1') then -- Init all registers
        a1_reg <= (others => '0');
        a2_reg <= (others => '0');
        a3_reg <= (others => '0');
        b1_reg <= (others => '0');
        b2_reg <= (others => '0');
        b3_reg <= (others => '0');
        partProd1_reg <= (others => '0');
        partProd2_reg <= (others => '0');
        partProd3_reg <= (others => '0');
        partProd4_reg <= (others => '0');
      else -- Handle the pipeline registers
        a1_reg <= a1_next;
        a2_reg <= a2_next;
        a3_reg <= a3_next;
        b1_reg <= b1_next;
        b2_reg <= b2_next;
        b3_reg <= b3_next;
        partProd1_reg <= partProd1_next;
        partProd2_reg <= partProd2_next;
        partProd3_reg <= partProd3_next;
        partProd4_reg <= partProd4_next;
      end if;
    end if;
  end process;

  -- Stage 0 and 1 (no pipeline registers in between)
  b0Vect <= (others => b(0));
  bitProd0 <= unsigned("00000" & (b0Vect and a));
  b1Vect <= (others => b(1));
  bitProd1 <= unsigned("0000" & (b1Vect and a) & "0");
  partProd1_next <= bitProd1 + bitProd0;
  a1_next <= a;
  b1_next <= b;

  -- Stage 2
  b2Vect <= (others => b1_reg(2));
  bitProd2 <= unsigned("000" & (b2Vect and a1_reg) & "00");
  partProd2_next <= bitProd2 + partProd1_reg;
  a2_next <= a1_reg;
  b2_next <= b1_reg;

  -- Stage 3
  b3Vect <= (others => b2_reg(3));
  bitProd3 <= unsigned("00" & (b3Vect and a2_reg) & "000");
  partProd3_next <= bitProd3 + partProd2_reg;
  a3_next <= a2_reg;
  b3_next <= b2_reg;

  -- Stage 4
  b4Vect <= (others => b3_reg(4));
  bitProd4 <= unsigned("0" & (b4Vect and a3_reg) & "0000");
  partProd4_next <= bitProd4 + partProd3_reg;

  -- Output
  c <= std_logic_vector(partProd4_reg);

end;
