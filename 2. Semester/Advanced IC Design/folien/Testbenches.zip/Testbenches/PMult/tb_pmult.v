// Selbstpruefende Testbench fuer pmult (Latenz 4 Takte):
//   1. Synchroner Reset: c = 0.
//   2. Die Folge aus dem Timingdiagramm der Folien: a = 10, 11, 12, 13, 14
//      mit b = 20, je ein Takt. c liefert 4 Takte spaeter 200 ... 280.
//   3. Alle 1024 Kombinationen von a und b, in jedem Takt ein neues Paar
//      (volle Pipeline). c wird mit a * b von vor 4 Takten verglichen
//      (Referenzmodell: Schieberegister mit den erwarteten Produkten).
//   4. Reset mitten im Betrieb leert die Pipeline.
// Stimuli werden an der fallenden Flanke gesetzt und geprueft.

module tb_pmult;

  localparam LAT = 4;

  reg          clk   = 1'b0;
  reg          reset = 1'b1;
  reg  [4 : 0] a     = 5'd0;
  reg  [4 : 0] b     = 5'd0;
  wire [9 : 0] c;

  reg  [9 : 0] exp [0 : LAT - 1];  // exp[LAT-1]: Erwartung fuer jetzt
  integer      i, j, k, errors = 0;

  pmult dut (.clk(clk), .reset(reset), .a(a), .b(b), .c(c));

  always #5 clk = ~clk;

  // Referenzmodell: das Produkt wandert mit der steigenden Flanke weiter
  always @(posedge clk)
    if (reset)
      for (k = 0; k < LAT; k = k + 1) exp[k] <= 10'd0;
    else begin
      exp[0] <= a * b;
      for (k = 1; k < LAT; k = k + 1) exp[k] <= exp[k - 1];
    end

  task check(input [8*24 : 1] what);
    if (c !== exp[LAT - 1]) begin
      $display("FEHLER (%0s): t=%0t  c=%0d  erwartet=%0d", what, $time, c, exp[LAT - 1]);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_pmult.vcd");            // laeuft im Verzeichnis build/
    $dumpvars(0, tb_pmult);

    // 1. Reset
    @(negedge clk); @(negedge clk);
    check("Reset");
    reset = 1'b0;

    // 2. Folge aus dem Timingdiagramm
    b = 5'd20;
    for (i = 10; i <= 14; i = i + 1) begin
      a = i;
      @(negedge clk);
      check("Timingdiagramm");
    end
    for (i = 0; i < LAT; i = i + 1) begin
      @(negedge clk);
      check("Timingdiagramm");
      if (i == LAT - 1 && c !== 10'd280) begin
        $display("FEHLER: c=%0d statt 280 (14 * 20)", c);
        errors = errors + 1;
      end
    end
    $display("ok     Folge 10..14 * 20 wie im Timingdiagramm");

    // 3. Alle Kombinationen bei voller Pipeline
    for (i = 0; i < 32; i = i + 1)
      for (j = 0; j < 32; j = j + 1) begin
        a = i; b = j;
        @(negedge clk);
        check("alle Kombinationen");
      end
    for (i = 0; i < LAT; i = i + 1) begin
      @(negedge clk);
      check("Pipeline leeren");
    end
    $display("ok     alle 1024 Produkte, ein neues Paar pro Takt");

    // 4. Reset mitten im Betrieb
    a = 5'd31; b = 5'd31;
    repeat (2) @(negedge clk);
    reset = 1'b1;
    @(negedge clk);
    check("Reset im Betrieb");
    if (c !== 10'd0) begin
      $display("FEHLER: c=%0d nach Reset statt 0", c);
      errors = errors + 1;
    end
    reset = 1'b0;
    $display("ok     Reset leert die Pipeline");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
