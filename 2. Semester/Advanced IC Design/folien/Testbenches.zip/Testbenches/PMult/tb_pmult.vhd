-- Selbstpruefende Testbench fuer PMult (VHDL-93, Latenz 4 Takte):
--   1. Synchroner Reset: c = 0.
--   2. Die Folge aus dem Timingdiagramm der Folien: a = 10, 11, 12, 13, 14
--      mit b = 20, je ein Takt. c liefert 4 Takte spaeter 200 ... 280.
--   3. Alle 1024 Kombinationen von a und b, in jedem Takt ein neues Paar
--      (volle Pipeline). c wird mit a * b von vor 4 Takten verglichen
--      (Referenzmodell: Schieberegister mit den erwarteten Produkten).
--   4. Reset mitten im Betrieb leert die Pipeline.
-- Stimuli werden an der fallenden Flanke gesetzt und geprueft. Ein Fehler
-- beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_PMult is
end tb_PMult;

architecture Test of tb_PMult is
  constant LAT : integer := 4;

  type exp_t is array (0 to LAT - 1) of unsigned(9 downto 0);

  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal a     : std_logic_vector(4 downto 0) := (others => '0');
  signal b     : std_logic_vector(4 downto 0) := (others => '0');
  signal c     : std_logic_vector(9 downto 0);
  signal exp   : exp_t := (others => (others => '0')); -- exp(LAT-1): jetzt
  signal done  : boolean := false;
begin
  dut : entity work.PMult
    port map (clk => clk, reset => reset, a => a, b => b, c => c);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  -- Referenzmodell: das Produkt wandert mit der steigenden Flanke weiter
  model : process(clk)
  begin
    if rising_edge(clk) then
      if reset = '1' then
        exp <= (others => (others => '0'));
      else
        exp(0) <= unsigned(a) * unsigned(b);
        for k in 1 to LAT - 1 loop
          exp(k) <= exp(k - 1);
        end loop;
      end if;
    end if;
  end process;

  stimulus : process
    procedure check(what : string) is
    begin
      assert unsigned(c) = exp(LAT - 1)
        report "FEHLER (" & what & "): c=" & integer'image(to_integer(unsigned(c)))
               & " erwartet=" & integer'image(to_integer(exp(LAT - 1)))
        severity failure;
    end procedure;
  begin
    -- 1. Reset
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    check("Reset");
    reset <= '0';

    -- 2. Folge aus dem Timingdiagramm
    b <= std_logic_vector(to_unsigned(20, 5));
    for i in 10 to 14 loop
      a <= std_logic_vector(to_unsigned(i, 5));
      wait until falling_edge(clk);
      check("Timingdiagramm");
    end loop;
    for i in 1 to LAT loop
      wait until falling_edge(clk);
      check("Timingdiagramm");
    end loop;
    assert unsigned(c) = 280 report "FEHLER: c nicht 280 (14 * 20)" severity failure;
    report "ok: Folge 10..14 * 20 wie im Timingdiagramm" severity note;

    -- 3. Alle Kombinationen bei voller Pipeline
    for i in 0 to 31 loop
      for j in 0 to 31 loop
        a <= std_logic_vector(to_unsigned(i, 5));
        b <= std_logic_vector(to_unsigned(j, 5));
        wait until falling_edge(clk);
        check("alle Kombinationen");
      end loop;
    end loop;
    for i in 1 to LAT loop
      wait until falling_edge(clk);
      check("Pipeline leeren");
    end loop;
    report "ok: alle 1024 Produkte, ein neues Paar pro Takt" severity note;

    -- 4. Reset mitten im Betrieb
    a <= (others => '1');
    b <= (others => '1');
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    reset <= '1';
    wait until falling_edge(clk);
    check("Reset im Betrieb");
    assert unsigned(c) = 0 report "FEHLER: c nach Reset nicht 0" severity failure;
    reset <= '0';
    report "ok: Reset leert die Pipeline" severity note;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end Test;
