// 5-Bit-Multiplizierer mit Pipeline, SystemVerilog-Fassung von pmult.vhd
// (teil14.typ). Stage 0 und 1 sind rein kombinatorisch, nach Stage 1, 2,
// 3 und 4 liegen Pipelineregister. Latenz: 4 Takte.
module pmult
  (input  logic         clk,
   input  logic         reset,
   input  logic [4 : 0] a,
   input  logic [4 : 0] b,
   output logic [9 : 0] c);

  // The ith bit-product
  logic [9 : 0] bitProd0, bitProd1, bitProd2, bitProd3, bitProd4;

  // Registers for the copies of the input
  logic [4 : 0] a1, a2, a3;
  logic [4 : 0] b1, b2;
  // Von b3 braucht Stage 4 nur Bit 4 (wie b3_reg in VHDL); die Synthese
  // entfernt die uebrigen Flip-Flops.
  /* verilator lint_off UNUSEDSIGNAL */
  logic [4 : 0] b3;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [9 : 0] partProd1, partProd2, partProd3, partProd4;

  // Inputs for the pipeline registers
  logic [4 : 0] a1N, a2N, a3N;
  logic [4 : 0] b1N, b2N, b3N;
  logic [9 : 0] partProd1N, partProd2N, partProd3N, partProd4N;

  always_ff @(posedge clk) begin
    if (reset) begin // Init all registers
      a1 <= '0; a2 <= '0; a3 <= '0;
      b1 <= '0; b2 <= '0; b3 <= '0;
      partProd1 <= '0; partProd2 <= '0;
      partProd3 <= '0; partProd4 <= '0;
    end else begin // Handle the pipeline registers
      a1 <= a1N; a2 <= a2N; a3 <= a3N;
      b1 <= b1N; b2 <= b2N; b3 <= b3N;
      partProd1 <= partProd1N; partProd2 <= partProd2N;
      partProd3 <= partProd3N; partProd4 <= partProd4N;
    end
  end

  // Stage 0 and 1 (no pipeline registers in between)
  assign bitProd0   = {5'b00000, {5{b[0]}} & a};
  assign bitProd1   = {4'b0000, {5{b[1]}} & a, 1'b0};
  assign partProd1N = bitProd1 + bitProd0;
  assign a1N = a;
  assign b1N = b;

  // Stage 2
  assign bitProd2   = {3'b000, {5{b1[2]}} & a1, 2'b00};
  assign partProd2N = bitProd2 + partProd1;
  assign a2N = a1;
  assign b2N = b1;

  // Stage 3
  assign bitProd3   = {2'b00, {5{b2[3]}} & a2, 3'b000};
  assign partProd3N = bitProd3 + partProd2;
  assign a3N = a2;
  assign b3N = b2;

  // Stage 4
  assign bitProd4   = {1'b0, {5{b3[4]}} & a3, 4'b0000};
  assign partProd4N = bitProd4 + partProd3;

  // Output
  assign c = partProd4;

endmodule
