-- Selbstpruefende Testbench fuer PriEnc(Recursive) (VHDL-93, idxWidth = 5,
-- 32 Bit). Referenzmodell: Index des hoechsten gesetzten Bits,
-- active = mindestens ein Bit gesetzt.
--   1. src = 0 (active = '0') und alle 32 Einer-Muster.
--   2. Alle Muster "1 an Stelle k, darunter alles 1" (Prioritaet).
--   3. 5000 Zufallsmuster (LFSR), auch duenn besetzte.
-- Ein Fehler beendet die Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_PriEnc is
end tb_PriEnc;

architecture Test of tb_PriEnc is
  constant IW : integer := 5;
  constant N  : integer := 32;          -- 2**IW
  signal src    : std_logic_vector(N - 1 downto 0);
  signal idx    : std_logic_vector(IW - 1 downto 0);
  signal active : std_logic;
begin
  dut : entity work.PriEnc(Recursive)
    generic map (idxWidth => IW)
    port map (src => src, idx => idx, active => active);

  stimulus : process
    variable lfsr : std_logic_vector(31 downto 0) := x"ACE12345";
    variable v    : std_logic_vector(N - 1 downto 0);

    procedure check(x : std_logic_vector(N - 1 downto 0)) is
      variable e   : integer := 0;
      variable any : std_logic := '0';
    begin
      src <= x;
      for k in 0 to N - 1 loop
        if x(k) = '1' then
          e   := k;
          any := '1';
        end if;
      end loop;
      wait for 1 ns;
      assert active = any and (any = '0' or to_integer(unsigned(idx)) = e)
        report "FEHLER: erwartet Index " & integer'image(e) severity failure;
    end procedure;
  begin
    check((others => '0'));
    for i in 0 to N - 1 loop
      v := (others => '0');
      v(i) := '1';
      check(v);
    end loop;
    report "ok: src = 0 und alle 32 Einer-Muster" severity note;

    for i in 0 to N - 1 loop
      v := (others => '0');
      v(i downto 0) := (others => '1');
      check(v);
    end loop;
    report "ok: Prioritaet: 1 an Stelle k, darunter alles 1" severity note;

    for i in 0 to 4999 loop
      lfsr := lfsr(30 downto 0) & (lfsr(31) xor lfsr(21) xor lfsr(1) xor lfsr(0));
      if i mod 3 = 0 then
        check(lfsr and (lfsr(15 downto 0) & lfsr(31 downto 16)));
      else
        check(lfsr);
      end if;
    end loop;
    report "ok: 5000 Zufallsmuster" severity note;

    report "PASS" severity note;
    wait;
  end process;
end Test;
