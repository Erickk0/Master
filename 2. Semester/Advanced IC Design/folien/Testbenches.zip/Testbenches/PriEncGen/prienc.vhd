-- Generischer Prioritaetsencoder, rekursiv mit if-generate (teil9.typ,
-- Folien "VHDL-Beschreibung des Priority-Encoders" bis "(III)")
library ieee;
use ieee.std_logic_1164.all;

entity PriEnc is

generic (idxWidth : integer := 5);
port (src    : in std_logic_vector(2**idxWidth - 1 downto 0);
      idx    : out std_logic_vector(idxWidth - 1 downto 0);
      active : out std_logic);

end PriEnc;

architecture Recursive of PriEnc is
begin

abortRec : if (idxWidth = 1) generate

  active <= src(0) or src(1);
  idx(0) <= src(1);

end generate abortRec;

  stepRec : if (idxWidth > 1) generate

    signal lActive  : std_logic;
    signal rActive  : std_logic;
    signal leftIdx  : std_logic_vector(idxWidth - 2 downto 0);
    signal rightIdx : std_logic_vector(idxWidth - 2 downto 0);

  begin

    -- Generate a priority encoder for the upperhalf of src
    leftEnc : entity work.PriEnc(Recursive)
    generic map (idxWidth => idxWidth - 1)
    port map (src    => src(2**idxWidth - 1 downto 2**(idxWidth - 1)),
              idx    => leftIdx,
              active => lActive);

    -- Generate a priority encoder for the lower half of src
    rightEnc : entity work.PriEnc(Recursive)
    generic map (idxWidth => idxWidth - 1)
    port map (src     => src(2**(idxWidth - 1) - 1 downto 0),
               idx    => rightIdx,
               active => rActive);

    -- Calculate if at least one bit is set
    active <= lActive or rActive;

    -- Set MSB if upper half contains a '1'
    idx(idx'high) <= '1' when (lActive = '1')
                         else '0';

    -- Set the lower index bits
    idx(idx'high - 1 downto 0) <= leftIdx when (lActive = '1')
                                          else rightIdx;

  end generate stepRec;

end architecture;
