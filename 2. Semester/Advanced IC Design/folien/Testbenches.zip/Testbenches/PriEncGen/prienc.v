// Generischer Prioritaetsencoder, rekursiv mit generate-if (teil9.typ,
// Folien "Verilog-Beschreibung des Priority-Encoders" bis "(III)")
module prienc
  #(parameter IDXWIDTH = 5)
   (input  wire [2**IDXWIDTH - 1 : 0] src,
    output wire [IDXWIDTH - 1 : 0]    idx,
    output wire                       active);

  generate
    if (IDXWIDTH == 1) begin : abortRec

      assign active = src[0] | src[1];
      assign idx[0] = src[1];

    end else begin : stepRec

      wire                    lActive, rActive;
      wire [IDXWIDTH - 2 : 0] leftIdx, rightIdx;

      // Generate a priority encoder for the upper half of src
      prienc #(.IDXWIDTH(IDXWIDTH - 1))
        leftEnc (.src(src[2**IDXWIDTH - 1 : 2**(IDXWIDTH - 1)]),
                 .idx(leftIdx), .active(lActive));

      // Generate a priority encoder for the lower half of src
      prienc #(.IDXWIDTH(IDXWIDTH - 1))
        rightEnc (.src(src[2**(IDXWIDTH - 1) - 1 : 0]),
                  .idx(rightIdx), .active(rActive));

      // Calculate if at least one bit is set
      assign active = lActive | rActive;

      // Set MSB if upper half contains a 1
      assign idx[IDXWIDTH - 1] = lActive;

      // Set the lower index bits
      assign idx[IDXWIDTH - 2 : 0] = lActive ? leftIdx : rightIdx;

    end
  endgenerate

endmodule
