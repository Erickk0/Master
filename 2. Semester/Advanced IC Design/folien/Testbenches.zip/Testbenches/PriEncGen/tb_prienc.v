// Selbstpruefende Testbench fuer prienc (IDXWIDTH = 5, 32 Bit):
// Referenzmodell: Index des hoechsten gesetzten Bits, active = |src.
//   1. src = 0 (active = 0) und alle 32 Einer-Muster.
//   2. Alle Muster "1 an Stelle k, darunter alles 1" (Prioritaet).
//   3. 5000 Zufallsmuster (LFSR), auch duenn besetzte.
module tb_prienc;

  localparam IW = 5, N = 1 << IW;

  reg  [N - 1 : 0]  src;
  wire [IW - 1 : 0] idx;
  wire              active;
  reg  [31 : 0]     lfsr = 32'hACE1_2345;
  integer           i, k, expIdx, errors = 0;

  prienc #(.IDXWIDTH(IW)) dut (.src(src), .idx(idx), .active(active));

  task check;
    begin
      expIdx = 0;
      for (k = 0; k < N; k = k + 1) if (src[k]) expIdx = k;
      #1;
      if (active !== (|src) || (|src && idx !== expIdx)) begin
        if (errors < 10)
          $display("FEHLER: src=%h idx=%0d active=%b erwartet %0d", src, idx, active, expIdx);
        errors = errors + 1;
      end
    end
  endtask

  initial begin
    $dumpfile("tb_prienc.vcd");       // laeuft im Verzeichnis build/
    $dumpvars(0, tb_prienc);

    src = 0; check;
    for (i = 0; i < N; i = i + 1) begin src = 1 << i; check; end
    $display("ok     src = 0 und alle %0d Einer-Muster", N);

    for (i = 0; i < N; i = i + 1) begin src = (1 << (i + 1)) - 1; check; end
    $display("ok     Prioritaet: 1 an Stelle k, darunter alles 1");

    for (i = 0; i < 5000; i = i + 1) begin
      lfsr = {lfsr[30 : 0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
      src  = (i % 3 == 0) ? lfsr & {lfsr[15 : 0], lfsr[31 : 16]} : lfsr;  // auch duenn
      check;
    end
    $display("ok     5000 Zufallsmuster");

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
