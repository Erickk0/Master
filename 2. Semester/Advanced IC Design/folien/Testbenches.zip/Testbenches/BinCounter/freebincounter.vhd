-- Frei laufender Binaerzaehler aus Teil 5 (VHDL), teil5.typ, Folien
-- "Register & Counter" (Entity) und "Free-running counter" (Architecture).
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity freeBinCounter is

  generic(N : integer := 8);

  port (clk   : in  std_logic;
        reset : in  std_logic;
        value : out std_logic_vector(N - 1 downto 0));

end entity;

architecture Behavioral of freeBinCounter is

signal cnt_reg  : std_logic_vector(N - 1 downto 0);
signal cnt_next : std_logic_vector(N - 1 downto 0);

begin
 process (clk, reset)
 begin
   -- Asynchronous reset
   if (reset = '1') then
     cnt_reg <= (others => '0');
   elsif (rising_edge(clk)) then
     cnt_reg <= cnt_next; -- Change state on rising edge
   end if;
 end process;

 -- Next state logic
 cnt_next <= std_logic_vector(unsigned(cnt_reg) + 1);

 -- Output logic
 value <= cnt_reg;
end architecture;
