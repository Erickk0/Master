// Selbstprüfende Testbench für freecnt (WIDTH = 8):
//   1. Reset über eine Taktflanke halten, danach muss value = 0 sein.
//   2. 300 Takte zählen, inkl. Überlauf 255 -> 0, gegen ein Referenzmodell.
//   3. Synchroner Reset: wird reset zwischen zwei Flanken gesetzt, bleibt
//      value bis zur nächsten steigenden Flanke unverändert.
// Geprüft wird immer an der fallenden Flanke, damit es keine Races gibt.

module tb_freecnt;

  localparam W = 8;

  reg            clk   = 1'b0;
  reg            reset = 1'b1;
  wire [W-1 : 0] value;
  reg  [W-1 : 0] expected;
  integer        cycle;
  integer        errors = 0;

  freecnt #(.WIDTH(W)) dut (.value(value), .clk(clk), .reset(reset));

  always #5 clk = ~clk;

  task check(input [W-1 : 0] exp, input [8*24 : 1] what);
    if (value !== exp) begin
      $display("FEHLER (%0s): t=%0t  value=%0d  erwartet=%0d", what, $time, value, exp);
      errors = errors + 1;
    end
  endtask

  initial begin
    $dumpfile("tb_freecnt.vcd");          // läuft im Verzeichnis build/
    $dumpvars(0, tb_freecnt);

    // 1. Reset über zwei steigende Flanken halten
    @(negedge clk); @(negedge clk);
    check(0, "nach Reset");
    reset    = 1'b0;
    expected = 0;

    // 2. Zählen inkl. Überlauf
    for (cycle = 0; cycle < 300; cycle = cycle + 1) begin
      @(negedge clk);
      expected = expected + 1;
      check(expected, "Zaehlen");
    end
    $display("ok     300 Takte gezaehlt, value=%0d (Ueberlauf bei 255)", value);

    // 3. Synchroner Reset: wirkt erst mit der nächsten Flanke
    #1 reset = 1'b1;
    #1 check(expected, "Reset vor Flanke");
    @(negedge clk);
    check(0, "Reset nach Flanke");
    $display("ok     synchroner Reset wirkt erst mit der Taktflanke");

    reset    = 1'b0;
    expected = 0;
    repeat (5) begin
      @(negedge clk);
      expected = expected + 1;
      check(expected, "nach Reset");
    end

    if (errors == 0) $display("PASS");
    else             $display("FAIL (%0d Fehler)", errors);
    $finish;
  end

endmodule
