-- Selbstpruefende Testbench fuer freeBinCounter (VHDL-93, N = 8):
--   1. Reset ueber eine Taktflanke halten, danach muss value = 0 sein.
--   2. 300 Takte zaehlen, inkl. Ueberlauf 255 -> 0, gegen ein Referenzmodell.
--   3. Asynchroner Reset: wird reset zwischen zwei Flanken gesetzt, ist
--      value sofort 0, ohne auf die naechste Taktflanke zu warten.
-- Geprueft wird immer an der fallenden Flanke. Ein Fehler beendet die
-- Simulation mit failure.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_freeBinCounter is
end tb_freeBinCounter;

architecture Test of tb_freeBinCounter is
  constant N : integer := 8;

  signal clk   : std_logic := '0';
  signal reset : std_logic := '1';
  signal value : std_logic_vector(N - 1 downto 0);
  signal done  : boolean := false;
begin
  dut : entity work.freeBinCounter
    generic map (N => N)
    port map (clk => clk, reset => reset, value => value);

  -- Takt mit 10 ns Periode, haelt an, sobald der Test fertig ist
  clock : process
  begin
    while not done loop
      clk <= '0'; wait for 5 ns;
      clk <= '1'; wait for 5 ns;
    end loop;
    wait;
  end process;

  stimulus : process
    variable expected : unsigned(N - 1 downto 0);
  begin
    -- 1. Reset ueber zwei steigende Flanken halten
    wait until falling_edge(clk);
    wait until falling_edge(clk);
    assert unsigned(value) = 0 report "FEHLER: nach Reset" severity failure;
    reset    <= '0';
    expected := (others => '0');

    -- 2. Zaehlen inkl. Ueberlauf
    for i in 1 to 300 loop
      wait until falling_edge(clk);
      expected := expected + 1;
      assert unsigned(value) = expected
        report "FEHLER beim Zaehlen, Takt " & integer'image(i)
        severity failure;
    end loop;
    report "ok: 300 Takte gezaehlt (Ueberlauf bei 255)" severity note;

    -- 3. Asynchroner Reset: wirkt sofort
    wait for 1 ns;
    reset <= '1';
    wait for 1 ns;
    assert unsigned(value) = 0
      report "FEHLER: asynchroner Reset wirkt nicht sofort" severity failure;
    report "ok: asynchroner Reset wirkt sofort" severity note;

    wait until falling_edge(clk);
    reset    <= '0';
    expected := (others => '0');
    for i in 1 to 5 loop
      wait until falling_edge(clk);
      expected := expected + 1;
      assert unsigned(value) = expected
        report "FEHLER nach Reset, Takt " & integer'image(i)
        severity failure;
    end loop;

    report "PASS" severity note;
    done <= true;
    wait;
  end process;
end architecture;
